OUTPUT_DIR=$PWD/

runlqnverif() {
#   echo rm -f $OUTPUT_DIR/$1/$2/delay.out
#   rm -f $OUTPUT_DIR/$1/$2/delay.out

#   echo timeout 900 /root/lqn_results/V5/lqns/lqns --pragma=mva=one-step --pragma=multiserver=rolia --pragma=interlocking=none -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn
#   timeout 900 /root/lqn_results/V5/lqns/lqns --pragma=mva=one-step --pragma=multiserver=rolia --pragma=interlocking=none -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn

#   echo timeout 1800 /root/lqn_results/V5/lqns/lqns --pragma=mva=schweitzer --pragma=multiserver=rolia --pragma=interlocking=no -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn
#   timeout 1800 /root/lqn_results/V5/lqns/lqns --pragma=mva=schweitzer --pragma=multiserver=rolia --pragma=interlocking=no -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn

#   echo 3 > /proc/sys/vm/drop_caches && swapoff -a && swapon -a && printf '\n%s\n' 'Ram-cache and Swap Cleared'
#   sleep 15

   if [ -f $OUTPUT_DIR/$1/$2/mcad_delay.out ]; then
      echo EXISTS $OUTPUT_DIR/$1/$2/mcad_delay.out
   else
      echo /root/lqn_results/V5/lqns/lqns --pragma=mva=schweitzer --pragma=multiserver=rolia --pragma=interlocking=no -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn
      /root/lqn_results/V5/lqns/lqns --pragma=mva=schweitzer --pragma=multiserver=rolia --pragma=interlocking=no -o $OUTPUT_DIR/$1/$2/mcad_delay.out $OUTPUT_DIR/$1/$2/mcad_delay.lqn

      echo 3 > /proc/sys/vm/drop_caches && swapoff -a && swapon -a && printf '\n%s\n' 'Ram-cache and Swap Cleared'
      sleep 15
   fi
}

/root/lqn_results/V5/lqns/lqns --version

runlqnverif model_A12_case01_-1 random_53_hem
runlqnverif model_A12_case02_-1 random_9_hem
runlqnverif model_A12_case03_-1 random_10_hem
runlqnverif model_A12_case04_-1 random_76_hem
runlqnverif model_A12_case05_-1 random_73_hem
runlqnverif model_A12_case06_-1 random_5_hem
runlqnverif model_A12_case07_-1 random_22_hem
runlqnverif model_A12_case08_-1 random_42_hem
runlqnverif model_A12_case09_-1 random_21_hem
runlqnverif model_A12_case10_-1 random_179_hem
runlqnverif model_A12_case11_-1 random_19_hem
runlqnverif model_A12_case12_-1 random_38_hem
runlqnverif model_A12_case13_-1 random_34_hem
runlqnverif model_A12_case14_-1 hbfmemdec_hem
runlqnverif model_A12_case15_-1 random_73_hem
runlqnverif model_A18_case01_-1 random_21_hem
runlqnverif model_A18_case02_-1 random_195_hem
runlqnverif model_A18_case03_-1 random_18_hem
runlqnverif model_A18_case05_-1 random_13_hem
runlqnverif model_A18_case07_-1 random_21_hem
runlqnverif model_A18_case08_-1 hbfprocinc_hem
runlqnverif model_A18_case09_-1 random_51_hem
runlqnverif model_A18_case10_-1 random_33_hem
runlqnverif model_A18_case11_-1 random_40_hem
runlqnverif model_A18_case12_-1 random_261_hem
runlqnverif model_A18_case13_-1 random_1117_hem
runlqnverif model_A18_case14_-1 random_264_hem
runlqnverif model_A18_case15_-1 random_36_hem
runlqnverif model_A18_case16_-1 random_315_hem
runlqnverif model_A18_case17_-1 random_85_hem
runlqnverif model_A18_case18_-1 random_22_hem
runlqnverif model_A18_case19_-1 random_53_hem
runlqnverif model_A18_case21_-1 random_1068_hem
runlqnverif model_A24_case01_-1 ruaeeprocdec_hem
runlqnverif model_A24_case02_-1 random_33_hem
runlqnverif model_A24_case03_-1 random_43_hem
runlqnverif model_A24_case05_-1 random_32_hem
runlqnverif model_A24_case06_-1 random_26_hem
runlqnverif model_A24_case07_-1 random_148_hem
runlqnverif model_A24_case08_-1 random_55_hem
runlqnverif model_A24_case09_-1 random_22_hem
runlqnverif model_A24_case12_-1 random_98_hem
runlqnverif model_A24_case13_-1 random_163_hem
runlqnverif model_A24_case14_-1 random_63_hem
runlqnverif model_A24_case15_-1 random_9_hem
runlqnverif model_A24_case17_-1 random_92_hem
runlqnverif model_A24_case18_-1 random_9_hem
runlqnverif model_A24_case19_-1 hbfprocinc_hem
runlqnverif model_A24_case20_-1 random_22_hem
runlqnverif model_A24_case21_-1 random_101_hem
runlqnverif model_A30_case01_-1 random_47_hem
runlqnverif model_A30_case03_-1 random_31_hem
runlqnverif model_A30_case04_-1 random_74_hem
runlqnverif model_A30_case05_-1 random_7_hem
runlqnverif model_A30_case06_-1 random_257_hem
runlqnverif model_A30_case08_-1 random_20_hem
runlqnverif model_A30_case09_-1 random_14_hem
runlqnverif model_A30_case10_-1 random_984_hem
runlqnverif model_A30_case11_-1 random_16_hem
runlqnverif model_A30_case13_-1 random_10_hem
runlqnverif model_A30_case15_-1 random_226_hem
runlqnverif model_A30_case16_-1 random_67_hem
runlqnverif model_A30_case18_-1 random_419_hem
runlqnverif model_A30_case20_-1 random_10_hem
runlqnverif model_A4_case01_-1 random_133_hem
runlqnverif model_A4_case01_115000.0 random_116_hem
runlqnverif model_A4_case01_125000.0 random_119_hem
runlqnverif model_A4_case01_145000.0 random_152_hem
runlqnverif model_A4_case01_165000.0 random_188_hem
runlqnverif model_A4_case01_185000.0 random_28_hem
runlqnverif model_A4_case02_-1 random_28_hem
runlqnverif model_A4_case04_-1 random_160_hem
runlqnverif model_A4_case04_105000.0 random_232_hem
runlqnverif model_A4_case04_125000.0 random_243_hem
runlqnverif model_A4_case04_650000.0 random_236_hem
runlqnverif model_A4_case04_750000.0 random_226_hem
runlqnverif model_A4_case04_850000.0 random_200_hem
runlqnverif model_A4_case05_-1 random_186_hem
runlqnverif model_A4_case06_-1 random_19_hem
runlqnverif model_A4_case07_-1 random_935_hem
runlqnverif model_A4_case08_-1 random_185_hem
runlqnverif model_A4_case09_-1 random_337_hem
runlqnverif model_A4_case10_-1 random_462_hem
runlqnverif model_A4_case11_-1 random_78_hem
runlqnverif model_A4_case12_-1 random_36_hem
runlqnverif model_A4_case12_240000.0 random_12_hem
runlqnverif model_A4_case12_255000.0 random_18_hem
runlqnverif model_A4_case12_270000.0 random_4_hem
runlqnverif model_A4_case12_285000.0 random_49_hem
runlqnverif model_A4_case12_300000.0 random_23_hem
runlqnverif model_A4_case13_-1 random_311_hem
runlqnverif model_A4_case14_-1 random_209_hem
runlqnverif model_A4_case15_-1 random_72_hem
runlqnverif model_A4_case16_-1 random_37_hem
runlqnverif model_A4_case16_100000.0 random_52_hem
runlqnverif model_A4_case16_400000.0 random_44_hem
runlqnverif model_A4_case16_550000.0 random_88_hem
runlqnverif model_A4_case16_700000.0 random_76_hem
runlqnverif model_A4_case16_850000.0 random_106_hem
runlqnverif model_A4_case17_-1 random_560_hem
runlqnverif model_A4_case17_150000.0 random_134_hem
runlqnverif model_A4_case17_170000.0 random_13_hem
runlqnverif model_A4_case17_190000.0 random_181_hem
runlqnverif model_A4_case17_210000.0 random_393_hem
runlqnverif model_A4_case17_230000.0 random_366_hem
runlqnverif model_A4_case18_-1 random_31_hem
runlqnverif model_A4_case19_-1 random_21_hem
runlqnverif model_A4_case20_-1 random_223_hem
runlqnverif model_A4_case21_-1 random_168_hem
runlqnverif model_A8_case02_-1 random_520_hem
runlqnverif model_A8_case03_-1 random_46_hem
runlqnverif model_A8_case04_-1 random_147_hem
runlqnverif model_A8_case05_-1 random_960_hem
runlqnverif model_A8_case06_-1 random_38_hem
runlqnverif model_A8_case07_-1 random_114_hem
runlqnverif model_A8_case08_-1 random_41_hem
runlqnverif model_A8_case09_-1 random_2_hem
runlqnverif model_A8_case10_-1 random_94_hem
runlqnverif model_A8_case11_-1 random_159_hem
runlqnverif model_A8_case12_-1 random_52_hem
runlqnverif model_A8_case13_-1 random_1887_hem
runlqnverif model_A8_case14_-1 random_266_hem
runlqnverif model_A8_case15_-1 random_83_hem
runlqnverif model_A8_case16_-1 random_267_hem
runlqnverif model_A8_case17_-1 random_101_hem
runlqnverif model_A8_case18_-1 random_336_hem
runlqnverif model_A8_case19_-1 random_102_hem
runlqnverif model_A8_case20_-1 random_25_hem
runlqnverif model_A8_case21_-1 random_10_hem
