package ca.carleton.partioner;

import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.HashMap;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerEfficiency;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.partioner.CloudInfo.ServerResource;
import ca.carleton.perf.AppPerfModel;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

/**
 * Deployment is an abstract class. We want to explore different deployment
 * strategies. In this abstract class, methods such as initialDeployment(),
 * partition() and stopCondition() are abstract/unimplemented. The class that
 * extends Deployment will need to implement these abstract methods in order
 * to specify the deployment strategy.
 */
public abstract class Deployment implements Serializable {
	/* Key is the cloud; values are the nodes assigned to the specific cloud */
	Multimap<CloudInfo, Node> partitions;
	
	/* Modifiable information about clouds */
	List<CloudInfo> cloudInfoList;
	
	/* Map LQN task to a list of ServerInfo */
	Map<Node, PowerServerResourcesPair> lqnTaskToServerMap;
	
	DirectedGraph<Node, Arc> graph;
	Node root;
	
	User user;
	
	double cutWeight;
	
	double NETWORK_DELAY_THRESHOLD;
	
	long MAX_MOVES_PER_LQN_TASK;
	
	/* Keep track of deployment's power requirement.
	 * Three primary methods to track power are:
	 * 1) addNode, 2) removeNode and 3) moveNode.
	 */
	double power;
	
	long attemptedTries;
	
	long numMovesTaken;
	
	long numMovesTakenOld;

	int numLqnTasks;
	
	double currentCutWeight;
	
	/* Time taken for initial deployment (milliseconds). */
	double initDeplTime;
	
	/* Time taken during the partitioning phase (milliseconds). */
	double partitionTime;
	
	long windowSize;
	
	int nodesListSize;
	
	@Override
	public boolean equals(Object obj) {
		Deployment depl = (Deployment)obj;
		if (partitions.equals(depl.partitions)
				&& cloudInfoList.equals(depl.cloudInfoList)
				&& lqnTaskToServerMap.equals(depl.lqnTaskToServerMap)
				&& graph.equals(depl.graph)
				&& (nodesListSize == depl.nodesListSize)
				&& (windowSize == depl.windowSize)
				&& (initDeplTime == depl.initDeplTime)
				&& (currentCutWeight == depl.currentCutWeight)
				&& (numLqnTasks == depl.numLqnTasks)
				&& (numMovesTakenOld == depl.numMovesTakenOld)
				&& (numMovesTaken == depl.numMovesTaken)
				&& (attemptedTries == depl.attemptedTries)
				&& (power == depl.power)
				&& (MAX_MOVES_PER_LQN_TASK == depl.MAX_MOVES_PER_LQN_TASK)
				&& (NETWORK_DELAY_THRESHOLD == depl.NETWORK_DELAY_THRESHOLD)
				&& (cutWeight == depl.cutWeight)
		) {
			return true;
		}
		return false;
	}
	
	/* Constructor */
	public Deployment(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay) {
		this.partitions = HashMultimap.create();
		
		this.lqnTaskToServerMap = new HashMap<>();
		
		this.cutWeight = 0.0;
		
		this.currentCutWeight = 0;
		
		this.attemptedTries = 0;
		
		this.numMovesTaken = 0;
		
		this.numMovesTakenOld = 0;
		
		this.numLqnTasks = graph.getVertexCount();
		
		this.graph = graph;
		
		this.root = root;
		
		this.cloudInfoList = new ArrayList<>();
		for (Cloud cloud : clouds) {
			if (cloud != null) {
				CloudInfo cloudInfo = new CloudInfo(cloud);
				cloudInfo.createServerInfoList(servers, PowerEfficiency.DECREASING);
				cloudInfoList.add(cloudInfo);
			}
		}
		
		this.user = user;
		
		this.NETWORK_DELAY_THRESHOLD = user.getResponseTime() - executionDelay;
		Debug.log("deployment_network_delay_threshold: " + this.NETWORK_DELAY_THRESHOLD);
		if (this.NETWORK_DELAY_THRESHOLD <= 0) {
			throw new RuntimeException("insufficient_network_delay_threshold");
		}
		
		this.MAX_MOVES_PER_LQN_TASK = user.getMaxMovesPerLqnTask();
		
		/* If the windowSize value given to the constructor is positive and non-zero, then use this as the window size.
		 * If the windowSize value given to the constructor is zero or negative, then use the user provided value of windowSize.
		 */
		if (windowSize <= 0) {
			this.windowSize = user.getWindowSize();
			if ((this.windowSize == -1) || (this.windowSize >= this.numLqnTasks)) {
				this.windowSize = this.numLqnTasks - 1;
			}
		} else {
			this.windowSize = windowSize;
		}
		
		Debug.log("deployment_window_size: " + this.windowSize);
		if ((this.windowSize >= this.numLqnTasks) || (this.windowSize <= 0)) {
			throw new RuntimeException("Window size can't be > numLqnTasks or <= 0: ");
		}
		
		createOrderedCloudInfoList();
	}
	
	public Map<Node, PowerServerResourcesPair> getResourceDistribution() {
		return lqnTaskToServerMap;
	}
	
	public Multimap<CloudInfo, Node> getPartitions() {
		return partitions;
	}
	
	public List<CloudInfo> getCloudInfoList() {
		return cloudInfoList;
	}
	
	/* Order clouds closest to each other. */
	private void createOrderedCloudInfoList() {
//		Debug.log("OrderedCloudInfoList START: " + cloudInfoList);
		
		ArrayList<CloudInfo> orderCloudInfoList = new ArrayList<>();
		int numClouds = cloudInfoList.size();
		
		double minDelayFromUser = Double.MAX_VALUE;
		CloudInfo closestToUser = null;
		
		/* First, find cloud closest to the user */
		for (CloudInfo cloudInfo : cloudInfoList) {
			double delay = user.getDelay(cloudInfo.cloudRef);
			if (delay < minDelayFromUser) {
				minDelayFromUser = delay;
				closestToUser = cloudInfo;
			}
		}
		
		orderCloudInfoList.add(closestToUser);
		cloudInfoList.remove(closestToUser);
		
		CloudInfo nextCloud = closestToUser;
		
		/* Incrementally, keep on finding clouds closest to the nextCloud. */
		while (numClouds != orderCloudInfoList.size()) {
			double minDelayFromNextCloud = Double.MAX_VALUE;
			CloudInfo closestCloud = null;
			for (CloudInfo cloudInfo : cloudInfoList) {
				double delay = nextCloud.getDelay(cloudInfo);
				if (delay < minDelayFromNextCloud) {
					minDelayFromNextCloud = delay;
					closestCloud = cloudInfo;
				}
			}
			if (closestCloud != null) {
				orderCloudInfoList.add(closestCloud);
				cloudInfoList.remove(closestCloud);
				nextCloud = closestCloud;
			}
		}
		
		/* Replace the cloudInfoList with the ordered list. */
		cloudInfoList = orderCloudInfoList;
		
//		Debug.log("OrderedCloudInfoList END: " + cloudInfoList);
	}

	/**
	 * Implement the initial deployment strategy before the partitioning phase.
	 */
	public abstract int initialDeployment();
	
	/**
	 * Implement the partitioning strategy. Executed after the deployment phase.
	 */
//	public abstract int partition();
	
	/**
	 * Implement the stop condition to stop the partitioning phase.
	 */
//	public abstract boolean stopCondition();
	
	/* Assign a graph node to a cloud */
	public boolean addNode(CloudInfo cloud, PowerServerResourcesPair pwrServerRes, Node node) {
		lqnTaskToServerMap.put(node, pwrServerRes);
		cloud.assignTask(node, pwrServerRes.serverResources);
		
//		When assigning a LQN task to a server, the power cached in PowerServerResourcesPair
//		will represent the top power profile of the server.
		double powerAdd = pwrServerRes.power;
		power += powerAdd;

		/* Power can't be negative */
		if ((power < 0) || (powerAdd < 0)) {
			throw new RuntimeException("addNode total power: " + power + " add power: " + powerAdd);
		}
		
		return partitions.put(cloud, node);
	}
	
	/* Disassociate a graph node from a cloud */
	public boolean removeNode(CloudInfo cloud, Node node) {
		PowerServerResourcesPair pwrServerRes = lqnTaskToServerMap.get(node);
		if (pwrServerRes != null) {
//			A LQN task can't be assigned to multiple servers. So, serverResources
//			in PowerServerResourcesPair will only have one element. This element
//			will represent the server assigned to the LQN task.
			ServerResource currentResource = pwrServerRes.serverResources.get(0);
			ServerInfo currentServerInfo = currentResource.serverInfoRef;
			double reservedSsjOps = currentResource.getSsjOps();
			
//			Power removed needs to represent the top power profile. If multiple LQN
//			tasks are assigned to a server, then the power cached in PowerServerResourcesPair
//			may not represent the top power profile. LQN task needs to unassigned after the
//			power calculation. Otherwise, the server will unreserve the ssj_ops needed for
//			the LQN task.
			double powerRemove = currentServerInfo.getPowerRemove(reservedSsjOps);
			power -= powerRemove;
			
			cloud.unAssignTask(node, pwrServerRes.serverResources);
			lqnTaskToServerMap.remove(node);
			
			/* Power can't be negative */
			if ((power < 0) || (powerRemove < 0)) {
				throw new RuntimeException("removeNode total power: " + power + " remove power: " + powerRemove);
			}
			
			return partitions.remove(cloud, node);
		}
		return false;
	}
	
	/* Move a node from cloud1 to cloud2 */
	public boolean moveNode(CloudInfo cloud1, CloudInfo cloud2, PowerServerResourcesPair pwrServerResCloud2, Node node) {
		PowerServerResourcesPair pwrServerResCloud1 = lqnTaskToServerMap.get(node);
		if (pwrServerResCloud1 != null) {
//			When assigning a LQN task to a server, the power cached in PowerServerResourcesPair
//			will represent the top power profile of the server.
			double powerAdd = pwrServerResCloud2.power;
			
//			A LQN task can't be assigned to multiple servers. So, serverResources
//			in PowerServerResourcesPair will only have one element. This element
//			will represent the server assigned to the LQN task.
			ServerResource currentResource = pwrServerResCloud1.serverResources.get(0);
			ServerInfo currentServerInfo = currentResource.serverInfoRef;
			double reservedSsjOps = currentResource.getSsjOps();
			
//			Power removed needs to represent the top power profile. If multiple LQN
//			tasks are assigned to a server, then the power cached in PowerServerResourcesPair
//			may not represent the top power profile. LQN task needs to unassigned after the
//			power calculation. Otherwise, the server will unreserve the ssj_ops needed for
//			the LQN task.
			double powerRemove = currentServerInfo.getPowerRemove(reservedSsjOps);
			
			power -= powerRemove;
			power += powerAdd;
			
			cloud1.unAssignTask(node, pwrServerResCloud1.serverResources);
			cloud2.assignTask(node, pwrServerResCloud2.serverResources);
			
			/* Power can't be negative */
			if ((power < 0) || (powerAdd < 0) || (powerRemove < 0)) {
				throw new RuntimeException("moveNode total power: " + power + " add power: " + powerAdd + " remove power: " + powerRemove);
			}
			
			if (pwrServerResCloud1 != lqnTaskToServerMap.put(node, pwrServerResCloud2)) {
				throw new IllegalArgumentException("node: " + node + " was not assigned to servers: " + pwrServerResCloud1 + " previously.");
			}
			return partitions.remove(cloud1, node) && partitions.put(cloud2, node);
		}
		return false;
	}
	
	/* Find the cloud to which node is assigned; otherwise, return null */
	public CloudInfo findNode(Node nodeToSearch) {
		for (CloudInfo cloud : cloudInfoList) {
			for (Node node : partitions.get(cloud)) {
				if (node == nodeToSearch) {
					return cloud;
				}
			}
		}
		return null;
	}
	
	/* Returns true if node is assigned to cloud */
	public boolean hasNode(CloudInfo cloud, Node node) {
		for (Node n : partitions.get(cloud)) {
			if (n == node) {
				return true;
			}
		}
		return false;
	}
	
	public void printDeployment(HashMap<Node, Node> oldNewMap) {
		for (CloudInfo cloud : partitions.keySet()) {
			Debug.log("\tCloud: " + cloud.getCloudRef().getCloudName());
			for (Node node : partitions.get(cloud)) {
				PowerServerResourcesPair pwrSerResPair = lqnTaskToServerMap.get(node);
				Debug.log("\t\tLQN Task: " + node);
				if (pwrSerResPair == null) {
					if (oldNewMap == null) {
						Debug.log("[ERROR] printDeployment: pwrSerResPair is null and oldNewMap is null.");
						continue;
					}
					Debug.log("\t\t\tNode was merged during partitioning.");
					pwrSerResPair = lqnTaskToServerMap.get(oldNewMap.get(node));
				}
				List<ServerResource> serverResources = pwrSerResPair.serverResources;
				for (ServerResource serverResource : serverResources) {
					ServerInfo info = serverResource.getServerInfo();
					double totalRAM = info.availableRam;
					double totalSsjOps = info.availableSsjOps;
					String serverInfo = "\t\t\t" + serverResource.getServerInfo().getName() + " - "
									+ "Reserved RAM: " + serverResource.getRAM() + " - Available RAM: " + totalRAM
									+ " - Reserved ssjOps: " + serverResource.getSsjOps() + " - Available ssjOps: " + totalSsjOps;
					Debug.log(serverInfo);
				}
			}
		}
	}
	
	/* Calculates gain for moving node from cloud1 to cloud2 */
	public double calculateGain(Node node, CloudInfo cloud1, CloudInfo cloud2) {
		double gain = 0.0;
		
		double weightBeforeMove = 0.0;
		double weightAfterMove = 0.0;
		
		if (root == node) {
			throw new RuntimeException("Ref task shouldn't be moved during deployment");
		}
		
		for (Arc arc: graph.getIncidentEdges(node)) {
			Node src = graph.getSource(arc);
			Node dest = graph.getDest(arc);
			
			CloudInfo otherCloud = null;
			
//			Debug.log("calculateGain - " + "source: " + src + " - dest: " + dest + " - node: " + node);
			
			if ((src == root) || (dest == root)) {
				weightBeforeMove += (arc.getCallsPerUserReq() * user.getDelay(cloud1.getCloudRef()));
//				Debug.log("calculateGain - " + "weightBefore += " + arc.getCallsPerUserReq() + " * " + user.getDelay(cloud1.getCloudRef()) + " = " + arc.getCallsPerUserReq() * user.getDelay(cloud1.getCloudRef()));
				
				weightAfterMove += (arc.getCallsPerUserReq() * user.getDelay(cloud2.getCloudRef()));
//				Debug.log("calculateGain - " + "weightAfterMove += " + arc.getCallsPerUserReq() + " * " + user.getDelay(cloud2.getCloudRef()) + " = " + arc.getCallsPerUserReq() * user.getDelay(cloud2.getCloudRef()));
			} else {
				if (src == node) {
					otherCloud = findNode(dest);
				} else {
					otherCloud = findNode(src);
				}
				
//				Debug.log("calculateGain - " + "cloud1: " + cloud1.cloudRef.getCloudName() + " - cloud2: " + cloud2.cloudRef.getCloudName() + " - otherCloud: " + otherCloud.cloudRef.getCloudName());
				
				if (otherCloud != cloud1) {
					weightBeforeMove += (arc.getCallsPerUserReq() * cloud1.getDelay(otherCloud));
//					Debug.log("calculateGain - " + "weightBefore += " + arc.getCallsPerUserReq() + " * " + cloud1.getDelay(otherCloud) + " = " + arc.getCallsPerUserReq() * cloud1.getDelay(otherCloud));
				}
				if (otherCloud != cloud2) {
					weightAfterMove += (arc.getCallsPerUserReq() * cloud2.getDelay(otherCloud));
//					Debug.log("calculateGain - " + "weightAfterMove += " + arc.getCallsPerUserReq() + " * " + cloud2.getDelay(otherCloud) + " = " + arc.getCallsPerUserReq() * cloud2.getDelay(otherCloud));
	
				}
			}
		}
		
		gain = weightBeforeMove - weightAfterMove;
		
//		Debug.log("calculateGain - " + "gain: " + gain);
		
		return gain;
	}

	/* Find the sum of edges that cross between two clouds. */
	public double calculateCutWeight() {
		Collection<Arc> arcs = graph.getEdges();
		ArrayList<Arc> arcsList = new ArrayList<>(arcs);
		double cutWeightLocal = 0;
		
		for (Arc arc : arcsList) {
			Node dest = graph.getDest(arc);
			Node source = graph.getSource(arc);
			
			if (dest == root) {
//				CloudInfo sourceCloud = findNode(source);
//				Debug.log("calcCutWeight - " + "cloud1: " + sourceCloud.cloudRef.getCloudName() + " - user");
//				Debug.log("calcCutWeight - dest (root): " + dest + " - source: " + source + " - arc: " + arc + " - delay: " + user.getDelay(sourceCloud.getCloudRef()));
//				cutWeightLocal += arc.getCallsPerUserReq() * user.getDelay(sourceCloud.getCloudRef());
				throw new RuntimeException("Not possible to call a reference task");
			} else if (source == root) {
				CloudInfo destCloud = findNode(dest);
//				Debug.log("calcCutWeight - " + "user - cloud2: " + destCloud.cloudRef.getCloudName());
//				Debug.log("calcCutWeight - " + "dest: " + dest + " - source (root): " + source + " - arc: " + arc + " - delay: " + user.getDelay(destCloud.getCloudRef()));
				cutWeightLocal += arc.getCallsPerUserReq() * user.getDelay(destCloud.getCloudRef());
			} else {
				CloudInfo destCloud = findNode(dest);
				CloudInfo sourceCloud = findNode(source);
				
				if (destCloud != sourceCloud) {
//					Debug.log("calcCutWeight - " + "cloud1: " + sourceCloud.cloudRef.getCloudName() + " - cloud2: " + destCloud.cloudRef.getCloudName());
//					Debug.log("calcCutWeight - " + "dest: " + dest + " - source: " + source + " - arc: " + arc + " - delay: " + sourceCloud.getDelay(destCloud));
					cutWeightLocal += arc.getCallsPerUserReq() * sourceCloud.getDelay(destCloud);
				}
			}
		}
		
		this.cutWeight = cutWeightLocal;
		return cutWeightLocal;
	}
	
	/* Comparator to sort Nodes in descending order of processing requirement (CPU demand per user-request)  */
	class NodeSortDescendingProcReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in descending order -- highest CPU demand per user-request first */
			Double node1Proc = node1.getCpuDemandPerUserReq() * node1.getCallsPerUserReq();
			Double node2Proc = node2.getCpuDemandPerUserReq() * node2.getCallsPerUserReq();
			return node2Proc.compareTo(node1Proc);
		}
	}

	/* Comparator to sort Nodes in ascending order of processing requirement (CPU demand per user-request)  */
	class NodeSortAscendingProcReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in ascending order -- lowest CPU demand per user-request first */
			Double node1Proc = node1.getCpuDemandPerUserReq() * node1.getCallsPerUserReq();
			Double node2Proc = node2.getCpuDemandPerUserReq() * node2.getCallsPerUserReq();
			return node1Proc.compareTo(node2Proc);
		}
	}
	
	class NodeSortDescendingMemReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in descending order -- highest memory tasks are placed first */
			Double node1Mem = node1.getMemory();
			Double node2Mem = node2.getMemory();
			return node2Mem.compareTo(node1Mem);
		}
	}
	
	class NodeSortAscendingMemReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in descending order -- highest memory tasks are placed first */
			Double node1Mem = node1.getMemory();
			Double node2Mem = node2.getMemory();
			return node1Mem.compareTo(node2Mem);
		}
	}
	
	/* The partitioning strategy - executed after the deployment phase. */
//	public int partition() {
//		int rc = 0;
//		long startTime = System.nanoTime();
//		
//		currentCutWeight = calculateCutWeight();
//		Debug.log("Partition Cut-weight START: " + currentCutWeight);
//		Debug.log("Partition Power START: " + this.power);
//		
//		Collection<Node> nodes = graph.getVertices();
//		List<Node> nodesList = new ArrayList<>(nodes);
//		Collections.sort(nodesList, new NodeSortAscendingProcReq());
//
////		Debug.log("Partition - LQN tasks: " + nodesList);
//
//		while (true) {
//			for (Node lqnTask : nodesList) {
//				if (root == lqnTask) {
//					continue;
//				}
//				
//				CloudInfo cloudAssigned = findNode(lqnTask);
//				double currentPower = lqnTaskToServerMap.get(lqnTask).power;
//				
//				double maxGain = 0;
//				double minPower = currentPower;
//				double gainFromBestPower = 0;
//				CloudInfo cloudToMovePower = null;
//				CloudInfo cloudToMoveGain = null;
//				PowerServerResourcesPair pwrServerResGain = null;
//				PowerServerResourcesPair pwrServerResPower = null;
//				
//				for (CloudInfo toCloud : cloudInfoList) {
//					if ((toCloud != cloudAssigned) && (toCloud.hasEnoughResources(lqnTask))) {
//						double gain = calculateGain(lqnTask, cloudAssigned, toCloud);
//						PowerServerResourcesPair pwrServerRes = toCloud.findAssignableServers(lqnTask);
//						if (pwrServerRes != null) {
//							double power = pwrServerRes.power;
//							double nextCutWeight = currentCutWeight - gain;
//							
//							if (nextCutWeight <= NETWORK_DELAY_THRESHOLD) {
//								if (power < minPower) {
//									/* Only record the best power move if SLA is satisfied. */
//									pwrServerResPower = pwrServerRes;
//									minPower = pwrServerRes.power;
//									gainFromBestPower = gain;
//									cloudToMovePower = toCloud;
//								}
//							}
//							
//							/* Always record the best gain move. */
//							if (gain > maxGain) {
//								pwrServerResGain = pwrServerRes;
//								maxGain = gain;
//								cloudToMoveGain = toCloud;
//							}
//						}
//					}
//				}
//				
//				if (cloudToMovePower != null) {
//					/* Select the best power move that satisfies SLA. */
//					movesTaken++;
//					currentCutWeight -= gainFromBestPower;
//					moveNode(cloudAssigned, cloudToMovePower, pwrServerResPower, lqnTask);
////					Debug.log("GainPower: " + gainFromBestPower + " - Current-Cut-weight: " + currentCutWeight + " - Cut-weight-Complete: " + calculateCutWeight());
////				} else if ((cloudToMoveGain != null) && (maxGain > 0)) { /* If no power move found, then select the best move that reduce cut-weight. */
//				} else if ((cloudToMoveGain != null) && (maxGain > 0) && (currentCutWeight > NETWORK_DELAY_THRESHOLD)) {
//					/* If no power move found, then only select the best gain move if SLA is violated. */
//					movesTaken++;
//					currentCutWeight -= maxGain;
//					moveNode(cloudAssigned, cloudToMoveGain, pwrServerResGain, lqnTask);
////					Debug.log("GainMax: " + maxGain + " - Current-Cut-weight: " + currentCutWeight + " - Cut-weight-Complete: " + calculateCutWeight());
//				} else {
//					/* No power move or gain move found. */
////					Debug.log("Gain: no move");
//				}
//				
//				attemptedTries++;
//			}
//			
////			Debug.log("Partition - attemptedTries: " + attemptedTries + " - moves taken: " + movesTaken + " - num LQN tasks: " + numLqnTasks + " - max moves: " + MAX_MOVES_PER_LQN_TASK);
//			if (stopCondition()) {
//				break;
//			}
//		}
//		
//		Debug.log("Partition Cut-weight END: " + currentCutWeight);
//		Debug.log("Partition Power END: " + this.power);
//		
//		/* this method updates field cutWeight */
//		calculateCutWeight();
//		if ((int)currentCutWeight != (int)this.cutWeight) {
//			//throw new RuntimeException("cut-weight or gain calculation is not done properly. currentCutWeight: " + currentCutWeight + "; (int)calculatedCutWeight: " + this.cutWeight);
//			Debug.log("cut-weight or gain calculation is not done properly. currentCutWeight: " + currentCutWeight + "; (int)calculatedCutWeight: " + this.cutWeight);
//			rc = -1;
//		}
//		
//		long endTime = System.nanoTime();
//		this.partitionTime = (endTime - startTime)/1000000;
//		return rc;
//	}

	/* The partitioning strategy - executed after the deployment phase. */
	public int partition() {
		int rc = 0;
		long startTime = System.nanoTime();
		boolean movesTaken = false;
		
		currentCutWeight = calculateCutWeight();
		Debug.log("mcad_delay_before_partition: " + currentCutWeight + " ms");
		Debug.log("mcad_power_before_partition: " + this.power + " W");
		
		Collection<Node> nodes = graph.getVertices();
		List<Node> nodesList = new ArrayList<>(nodes);
		nodesListSize = nodesList.size();
		Collections.sort(nodesList, new NodeSortAscendingProcReq());

		int nodesListIndex = 0;
		Debug.log("mcad nodes list size: " + nodesListSize);
		Debug.log("mcad num LQN tasks: " + numLqnTasks);
		Debug.log("mcad window size: " + windowSize);
//		Debug.log("Partition - LQN tasks: " + nodesList);
		
		double powerVerifyStart = verifyPower();
//		double powerVerifyStart = verifyPowerCplex();

		if (Math.floor(this.power) != Math.floor(powerVerifyStart)) {
			Debug.log("mcad_deployment_partition_failed: inconsistent_power_start; this.power = " + this.power + " power verify = " + powerVerifyStart);
			rc = -1;
		}
		
//		System.exit(0);
		
		while ((rc == 0) && true) {
			double maxGain = 0;
			double maxPowerReduction = 0;
			double gainFromBestPower = 0;
			CloudInfo cloudToMovePower = null;
			CloudInfo cloudToMoveGain = null;
			PowerServerResourcesPair pwrServerResGain = null;
			PowerServerResourcesPair pwrServerResPower = null;
			Node nodeToMovePower = null;
			Node nodeToMoveGain = null;
			CloudInfo cloudAssignedPower = null;
			CloudInfo cloudAssignedGain = null;
			
			for (int i = 0; i < windowSize; i++, nodesListIndex++) {
				/* Reset index to nodesList if index goes out of bounds */
				if (nodesListIndex >= nodesListSize) {
					nodesListIndex = 0;
				}

				Node lqnTask = nodesList.get(nodesListIndex);
				if (root == lqnTask) {
					continue;
				}
				
				CloudInfo cloudAssigned = findNode(lqnTask);
				
//				Multiple LQN tasks can be assigned to a server. The power value needs to
//				represent the power that will be shaved from the overall utilization
//				of the server. In such a case, the power value cached during the initial
//				assignment can't be used since it may represent the middle power profile.
//				double currentPower = lqnTaskToServerMap.get(lqnTask).power;
				
//				A LQN task is assigned to only one server. Assigning a LQN task to multiple servers
//				is ignored.
				ServerResource currentResource = lqnTaskToServerMap.get(lqnTask).serverResources.get(0);
				ServerInfo currentServerInfo = currentResource.serverInfoRef;
				double reservedSsjOps = currentResource.getSsjOps();
				double currentPower = currentServerInfo.getPowerRemove(reservedSsjOps);
				
				for (CloudInfo toCloud : cloudInfoList) {
					if ((toCloud != cloudAssigned) && (toCloud.hasEnoughResources(lqnTask))) {
						double gain = calculateGain(lqnTask, cloudAssigned, toCloud);
						PowerServerResourcesPair pwrServerRes = toCloud.findAssignableServers(lqnTask);
						if (pwrServerRes != null) {
//							The below represents the top power profile of a server
							double powerRes = pwrServerRes.power;
							double nextCutWeight = currentCutWeight - gain;
							
							if (nextCutWeight <= NETWORK_DELAY_THRESHOLD) {
								/* changeInPower will be positive if the move results in reduced power usage. 
								 * changeInPower will be negative if the move results in increased power usage.
								 */
								double changeInPower = currentPower - powerRes;
								if (changeInPower > maxPowerReduction) {
									/* Only record the best move which results in maximum power reduction if SLA is satisfied. */
									pwrServerResPower = pwrServerRes;
									maxPowerReduction = changeInPower;
									gainFromBestPower = gain;
									cloudToMovePower = toCloud;
									nodeToMovePower = lqnTask;
									cloudAssignedPower = cloudAssigned;
								}
							}
							
							/* Always record the best gain move. */
							if (gain > maxGain) {
								pwrServerResGain = pwrServerRes;
								maxGain = gain;
								cloudToMoveGain = toCloud;
								nodeToMoveGain = lqnTask;
								cloudAssignedGain = cloudAssigned;
							}
						}
					}
				}
			}
			
			if (cloudToMovePower != null) {
				/* Select the best power move that satisfies SLA. */
				numMovesTaken++;
				movesTaken = true;
				currentCutWeight -= gainFromBestPower;
				moveNode(cloudAssignedPower, cloudToMovePower, pwrServerResPower, nodeToMovePower);
//				Debug.log("GainPower: " + gainFromBestPower + " - Current-Cut-weight: " + currentCutWeight + " - Cut-weight-Complete: " + calculateCutWeight());
//			} else if ((cloudToMoveGain != null) && (maxGain > 0)) { /* If no power move found, then select the best move that reduce cut-weight. */
			} else if ((cloudToMoveGain != null) && (maxGain > 0) && (currentCutWeight > NETWORK_DELAY_THRESHOLD)) {
				/* If no power move found, then only select the best gain move if SLA is violated. */
				numMovesTaken++;
				movesTaken = true;
				currentCutWeight -= maxGain;
				moveNode(cloudAssignedGain, cloudToMoveGain, pwrServerResGain, nodeToMoveGain);
//				Debug.log("GainMax: " + maxGain + " - Current-Cut-weight: " + currentCutWeight + " - Cut-weight-Complete: " + calculateCutWeight());
			} else {
				/* No power move or gain move found. */
//				Debug.log("Gain: no move");
			}
			
			attemptedTries++;
			
//			Debug.log("Partition - attemptedTries: " + attemptedTries + " - moves taken: " + movesTaken + " - num LQN tasks: " + numLqnTasks + " - max moves: " + MAX_MOVES_PER_LQN_TASK);
			if (stopCondition()) {
				Debug.log("mcad_moves_taken: " + numMovesTaken);
				Debug.log("mcad_attempted_tries: " + attemptedTries);
				break;
			}
			
			movesTaken = false;
		}
		
		/* this method updates field cutWeight */
		calculateCutWeight();
		if ((int)currentCutWeight != (int)this.cutWeight) {
//			throw new RuntimeException("cut-weight or gain calculation is not done properly. currentCutWeight: " + currentCutWeight + "; (int)calculatedCutWeight: " + this.cutWeight);
			Debug.log("mcad_deployment_partition_failed: inconsistent_cutweight");
			rc = -1;
		}
		
		double powerVerifyEnd = verifyPower();
		
		if (Math.floor(this.power) != Math.floor(powerVerifyEnd)) {
			Debug.log("mcad_deployment_partition_failed: inconsistent_power_end; this.power = " + this.power + " power verify = " + powerVerifyEnd);
			rc = -1;
		}
		
		if (currentCutWeight > this.NETWORK_DELAY_THRESHOLD) {
//			throw new RuntimeException("deployment_response_time_not_met: " + currentCutWeight);
			Debug.log("macd_deployment_partition_failed: response_time_constraint_not_met; cut-weight = " + currentCutWeight + "; threshold = " + this.NETWORK_DELAY_THRESHOLD);
			rc = -1;
		}
		
		if (rc == 0) {
			Debug.log("mcad_delay_after_partition: " + currentCutWeight + " ms");
			Debug.log("mcad_power_after_partition: " + powerVerifyEnd + " W");
		}
		
		long endTime = System.nanoTime();
		this.partitionTime = (endTime - startTime)/1000000;
		return rc;
	}
	
	
	public int partitionMinDelay() {
		int rc = 0;
		long startTime = System.nanoTime();
		boolean movesTaken = false;
		boolean firstDelaySatisfyRecord = false;
		
		currentCutWeight = calculateCutWeight();
		Debug.log("delay_delay_before_partition: " + currentCutWeight + " ms");
		Debug.log("delay_power_before_partition: " + this.power + " W");
		
		Collection<Node> nodes = graph.getVertices();
		List<Node> nodesList = new ArrayList<>(nodes);
		nodesListSize = nodesList.size();
		Collections.sort(nodesList, new NodeSortAscendingProcReq());

		int nodesListIndex = 0;
		Debug.log("delay nodes list size: " + nodesListSize);
		Debug.log("delay num LQN tasks: " + numLqnTasks);
		Debug.log("delay window size: " + windowSize);
//		Debug.log("Partition - LQN tasks: " + nodesList);
		
		double powerVerifyStart = verifyPower();
		
		if (Math.floor(this.power) != Math.floor(powerVerifyStart)) {
			Debug.log("delay_deployment_partition_failed: inconsistent_power_start; this.power = " + this.power + " power verify = " + powerVerifyStart);
			rc = -1;
		}
		
		while ((rc == 0) && true) {
			double maxGain = 0;
			double maxPowerReduction = 0;
			double gainFromBestPower = 0;
			CloudInfo cloudToMovePower = null;
			CloudInfo cloudToMoveGain = null;
			PowerServerResourcesPair pwrServerResGain = null;
			PowerServerResourcesPair pwrServerResPower = null;
			Node nodeToMovePower = null;
			Node nodeToMoveGain = null;
			CloudInfo cloudAssignedPower = null;
			CloudInfo cloudAssignedGain = null;
			
			if (!firstDelaySatisfyRecord && (currentCutWeight <= NETWORK_DELAY_THRESHOLD)) {
				Debug.log("delay_delay_first_satisfy_partition: " + currentCutWeight + " ms");
				Debug.log("delay_power_first_satisfy_partition: " + verifyPower() + " W");
				Debug.log("delay_moves_first_satisfy_partition: " + numMovesTaken);
				firstDelaySatisfyRecord = true;
			}
			
			for (int i = 0; i < windowSize; i++, nodesListIndex++) {
				/* Reset index to nodesList if index goes out of bounds */
				if (nodesListIndex >= nodesListSize) {
					nodesListIndex = 0;
				}

				Node lqnTask = nodesList.get(nodesListIndex);
				if (root == lqnTask) {
					continue;
				}
				
				CloudInfo cloudAssigned = findNode(lqnTask);
				
//				Multiple LQN tasks can be assigned to a server. The power value needs to
//				represent the power that will be shaved from the overall utilization
//				of the server. In such a case, the power value cached during the initial
//				assignment can't be used since it may represent the middle power profile.
//				double currentPower = lqnTaskToServerMap.get(lqnTask).power;
				
//				A LQN task is assigned to only one server. Assigning a LQN task to multiple servers
//				is ignored.
				ServerResource currentResource = lqnTaskToServerMap.get(lqnTask).serverResources.get(0);
				ServerInfo currentServerInfo = currentResource.serverInfoRef;
				double reservedSsjOps = currentResource.getSsjOps();
				double currentPower = currentServerInfo.getPowerRemove(reservedSsjOps);
				
				for (CloudInfo toCloud : cloudInfoList) {
					if ((toCloud != cloudAssigned) && (toCloud.hasEnoughResources(lqnTask))) {
						double gain = calculateGain(lqnTask, cloudAssigned, toCloud);
						PowerServerResourcesPair pwrServerRes = toCloud.findAssignableServers(lqnTask);
						if (pwrServerRes != null) {
//							The below represents the top power profile of a server
							double powerRes = pwrServerRes.power;
							double nextCutWeight = currentCutWeight - gain;
							
							if (nextCutWeight <= NETWORK_DELAY_THRESHOLD) {
								/* changeInPower will be positive if the move results in reduced power usage. 
								 * changeInPower will be negative if the move results in increased power usage.
								 */
								double changeInPower = currentPower - powerRes;
								if (changeInPower > maxPowerReduction) {
									/* Only record the best move which results in maximum power reduction if SLA is satisfied. */
									pwrServerResPower = pwrServerRes;
									maxPowerReduction = changeInPower;
									gainFromBestPower = gain;
									cloudToMovePower = toCloud;
									nodeToMovePower = lqnTask;
									cloudAssignedPower = cloudAssigned;
								}
							}
							
							/* Always record the best gain move. */
							if (gain > maxGain) {
								pwrServerResGain = pwrServerRes;
								maxGain = gain;
								cloudToMoveGain = toCloud;
								nodeToMoveGain = lqnTask;
								cloudAssignedGain = cloudAssigned;
							}
						}
					}
				}
			}
				
			if ((cloudToMoveGain != null) && (maxGain > 0)) {
				/* Reduce gain (network delay) until no move is found. */
				numMovesTaken++;
				movesTaken = true;
				currentCutWeight -= maxGain;
				moveNode(cloudAssignedGain, cloudToMoveGain, pwrServerResGain, nodeToMoveGain);
//				Debug.log("GainMax: " + maxGain + " - Current-Cut-weight: " + currentCutWeight + " - Cut-weight-Complete: " + calculateCutWeight());
			} else {
				/* No power move or gain move found. */
//				Debug.log("Gain: no move");
			}
			
			attemptedTries++;
			
//			Debug.log("Partition - attemptedTries: " + attemptedTries + " - moves taken: " + movesTaken + " - num LQN tasks: " + numLqnTasks + " - max moves: " + MAX_MOVES_PER_LQN_TASK);
			if (stopCondition()) {
				Debug.log("delay_moves_taken: " + numMovesTaken);
				Debug.log("delay_attempted_tries: " + attemptedTries);
				break;
			}
			
			movesTaken = false;
		}
		
		/* this method updates field cutWeight */
		calculateCutWeight();
		if ((int)currentCutWeight != (int)this.cutWeight) {
//			throw new RuntimeException("cut-weight or gain calculation is not done properly. currentCutWeight: " + currentCutWeight + "; (int)calculatedCutWeight: " + this.cutWeight);
			Debug.log("delay_deployment_partition_failed: inconsistent_cutweight");
			rc = -1;
		}
		
		double powerVerifyEnd = verifyPower();
		
		if (Math.floor(this.power) != Math.floor(powerVerifyEnd)) {
			Debug.log("delay_deployment_partition_failed: inconsistent_power_end; this.power = " + this.power + " power verify = " + powerVerifyEnd);
			rc = -1;
		}
		
		if (currentCutWeight > this.NETWORK_DELAY_THRESHOLD) {
//			throw new RuntimeException("deployment_response_time_not_met: " + currentCutWeight);
			Debug.log("delay_deployment_partition_failed: response_time_constraint_not_met; cut-weight = " + currentCutWeight + "; threshold = " + this.NETWORK_DELAY_THRESHOLD);
			rc = -1;
		}
		
		if (rc == 0) {
			Debug.log("delay_delay_after_partition: " + currentCutWeight + " ms");
			Debug.log("delay_power_after_partition: " + powerVerifyEnd + " W");
		}
		
		long endTime = System.nanoTime();
		this.partitionTime = (endTime - startTime)/1000000;
		return rc;
	}
	
	double verifyPower() {
		double powerVerify = 0;
		HashMap<ServerInfo, Integer> duplicates = new HashMap<>();
//		Debug.log("=== Servers available ===");
		for (CloudInfo cloud : cloudInfoList) {
			for (ServerInfo serverInfo : cloud.serversAvailable) {
				if (!duplicates.containsKey(serverInfo) && (Math.floor(serverInfo.usedSsjOps) > 0)) {
					powerVerify += serverInfo.getPower(serverInfo.usedSsjOps);
//					Debug.log(serverInfo.getName() + " used ssj_ops = " + serverInfo.usedSsjOps + " power = " + serverInfo.getPower(serverInfo.usedSsjOps) + " tasks: " + serverInfo.assignedTasks);
				}
				duplicates.put(serverInfo, 0);
			}
		}
		
//		Debug.log("=== Servers used ===");
		for (CloudInfo cloud : cloudInfoList) {
			for (ServerInfo serverInfo : cloud.serversUsed) {
				if (!duplicates.containsKey(serverInfo) && (Math.floor(serverInfo.usedSsjOps) > 0)) {
					powerVerify += serverInfo.getPower(serverInfo.usedSsjOps);
//					Debug.log(serverInfo.getName() + " used ssj_ops = " + serverInfo.usedSsjOps + " power = " + serverInfo.getPower(serverInfo.usedSsjOps) + " tasks: " + serverInfo.assignedTasks);
				}
				duplicates.put(serverInfo, 0);
			}
		}
		
		return powerVerify;
	}
	
	double verifyPowerCplex() {
		double powerVerify = 0;
		HashMap<ServerInfo, Integer> duplicates = new HashMap<>();
//		Debug.log("=== Servers available ===");
		for (CloudInfo cloud : cloudInfoList) {
			for (ServerInfo serverInfo : cloud.serversAvailable) {
				if (!duplicates.containsKey(serverInfo) && (Math.floor(serverInfo.usedSsjOps) > 0)) {
					powerVerify += serverInfo.getPowerCplex(serverInfo.usedSsjOps);
//					Debug.log(serverInfo.getName() + " used ssj_ops = " + serverInfo.usedSsjOps + " power = " + serverInfo.getPower(serverInfo.usedSsjOps) + " tasks: " + serverInfo.assignedTasks);
				}
				duplicates.put(serverInfo, 0);
			}
		}
		
//		Debug.log("=== Servers used ===");
		for (CloudInfo cloud : cloudInfoList) {
			for (ServerInfo serverInfo : cloud.serversUsed) {
				if (!duplicates.containsKey(serverInfo) && (Math.floor(serverInfo.usedSsjOps) > 0)) {
					powerVerify += serverInfo.getPowerCplex(serverInfo.usedSsjOps);
//					Debug.log(serverInfo.getName() + " used ssj_ops = " + serverInfo.usedSsjOps + " power = " + serverInfo.getPower(serverInfo.usedSsjOps) + " tasks: " + serverInfo.assignedTasks);
				}
				duplicates.put(serverInfo, 0);
			}
		}
		
		return powerVerify;
	}
	
	/* Stop condition to stop the partitioning phase. */
	public boolean stopCondition() {
		/* If no move is taken after evaluating all graph nodes, then stop. */
		if ((attemptedTries > 0) 
			&& ((((attemptedTries - numMovesTaken) * windowSize) % (nodesListSize - 1)) == 0)
		) {
			if (numMovesTakenOld == numMovesTaken) {
				Debug.log("stop_condition: no_moves_found");
				return true;
			} else {
				this.numMovesTakenOld = numMovesTaken;
			}
		}
		
		/* For MAX_MOVES_PER_LQN_TASK <= 0 values, ignore the below stop condition. */
		if (MAX_MOVES_PER_LQN_TASK > 0) {
			/* If we are able to move LQN tasks, then try moving each LQN task at-least
			 * MAX_MOVES_PER_LQN_TASK times before stopping.
			 */
			if ((numMovesTaken != 0) && (attemptedTries >= (MAX_MOVES_PER_LQN_TASK * numLqnTasks))) {
				Debug.log("stop_condition: max_moves_reached");
				return true;
			}
		}
		
		return false;
	}
	
	public double getInitDeploymentTime() {
		return initDeplTime;
	}
	
	public double getPartitionTime() {
		return partitionTime;
	}
	
	@Override
	public Deployment clone() throws CloneNotSupportedException {
		Deployment deployment = null;
		try {
			deployment = (Deployment)super.clone();
		} catch (CloneNotSupportedException ex) {
			throw ex;
		}
		return deployment;
	}
}