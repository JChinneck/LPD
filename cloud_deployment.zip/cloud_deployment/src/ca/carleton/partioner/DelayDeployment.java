package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class DelayDeployment extends Deployment {
	public DelayDeployment(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay) {
		super(clouds, servers, user, graph, root, windowSize, executionDelay);
	}

	@Override
	public int initialDeployment() {
		int result = 0;
		long startTime = System.nanoTime();

		List<Node> nodesList = new ArrayList<>(graph.getVertices());
		Collections.sort(nodesList, new NodeSortDescendingProcReq());
		
//		Debug.log("InitDepl - LQN tasks: " + nodesList);
		Debug.log("power_before_initdeployment: " + this.power + " W");
		
		PowerServerResourcesPair pwrServerRes = null;
		CloudInfo selectedCloud = null;
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}
			
			ResourceCloudTuple resourceCloud = null;
			if ((selectedCloud == null) || (!cloudClosestToUser(selectedCloud))) {
				/* Assigning first LQN task - so find cloud with minimum delay from the user
				 * that can handle LQN task.
				 */
				resourceCloud = findCloudClosestToUser(node);
				if (resourceCloud == null) {
					result = -1;
					break;
				}
				selectedCloud = resourceCloud.cloud;
				pwrServerRes = resourceCloud.resource;
			} else {
				PowerServerResourcesPair resultPwrResource = selectedCloud.findAssignableServers(node);
				if (resultPwrResource == null) {
					/* selectedCloud doesn't have enough resources to allocate LQN task.
					 * So, find cloud with minimum delay from selectedCloud that can handle LQN task. 
					 */
					resourceCloud = findClosestCloud(node, selectedCloud);
					if (resourceCloud == null) {
						result = -1;
						break;
					}
					selectedCloud = resourceCloud.cloud;
					pwrServerRes = resourceCloud.resource;
				} else {
					pwrServerRes = resultPwrResource;
				}
			}
			
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (result == 0) {
			Debug.log("power_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return result;
	}
	
//	@Override
//	public void initialDeployment() {
//		long startTime = System.nanoTime();
//		
//		List<Node> nodesList = new ArrayList<>(graph.getVertices());
//		Collections.sort(nodesList, new NodeSortDescendingProcReq());
//		
//		Debug.log("InitDepl - LQN tasks: " + nodesList);
//		Debug.log("power_before_initdeployment: " + this.power + " W");
//		
//		PowerServerResourcesPair pwrServerRes = null;
//		CloudInfo selectedCloud = null;
//		
//		for (Node node : nodesList) {
//			if (root == node) {
//				continue;
//			}
//			
//			ResourceCloudTuple resourceCloud = null;
//			if (selectedCloud == null) {
//				/* Assigning first LQN task - so find cloud with minimum delay from the user
//				 * that can handle LQN task.
//				 */
//				resourceCloud = findCloudClosestToUser(node);
//				selectedCloud = resourceCloud.cloud;
//				pwrServerRes = resourceCloud.resource;
//			} else {
//				PowerServerResourcesPair result = selectedCloud.findAssignableServers(node);
//				if (result == null) {
//					/* selectedCloud doesn't have enough resources to allocate LQN task.
//					 * So, find cloud with minimum delay from selectedCloud that can handle LQN task. 
//					 */
//					resourceCloud = findClosestCloud(node, selectedCloud);
//					selectedCloud = resourceCloud.cloud;
//					pwrServerRes = resourceCloud.resource;
//				} else {
//					pwrServerRes = result;
//				}
//			}
//			
//			addNode(selectedCloud, pwrServerRes, node);
//		}
//		
//		Debug.log("power_after_initdeployment: " + this.power + " W");
//		long endTime = System.nanoTime();
//		this.initDeplTime = (endTime - startTime)/1000000;
//	}
	
	/* Check if the specified cloud is closest to the user. */
	public boolean cloudClosestToUser(CloudInfo selectedCloud) {
		boolean rc = false;
		double selectedCloudDelay = user.getDelay(selectedCloud.cloudRef);
		
		for (CloudInfo cloudInfo : cloudInfoList) {
			if (cloudInfo != selectedCloud) {
				double cloudDelay = user.getDelay(cloudInfo.cloudRef);
				if (cloudDelay < selectedCloudDelay) {
					rc = false;
					break;
				}
			}
		}
		
		return rc;
	}
	
	/* Find cloud with minimum delay from the user which can accommodate node (LQN task) */
	public ResourceCloudTuple findCloudClosestToUser(Node node) {
		double minDelayFromUser = Double.MAX_VALUE;
		CloudInfo closestToUser = null;
		PowerServerResourcesPair resource = null;
		
		for (CloudInfo cloudInfo : cloudInfoList) {
			double delay = user.getDelay(cloudInfo.cloudRef);
			if (cloudInfo.hasEnoughResources(node)) {
				PowerServerResourcesPair result = cloudInfo.findAssignableServers(node);
//				Debug.log("cloud user: " + cloudInfo.cloudRef.getCloudName() + " node: " + node + " " + node.getCpuDemandPerUserReq());
				if ((delay < minDelayFromUser) && (result != null)) {
					minDelayFromUser = delay;
					resource = result;
					closestToUser = cloudInfo;
				}
			}
		}
		
		if ((resource == null) || (closestToUser == null)) {
//			throw new RuntimeException("Failed to assign LQN task to a cloud. " + node);
			Debug.log("delay_init_deployment_failed: to assign LQN task to a cloud. " + node);
			return null;
		}
		
		return new ResourceCloudTuple(resource, closestToUser);
	}
	
	/* Find cloud with minimum delay from selectedCloud which can accommodate node (LQN task) */
	public ResourceCloudTuple findClosestCloud(Node node, CloudInfo selectedCloud) {
		double minDelay = Double.MAX_VALUE;
		CloudInfo closestCloud = null;
		PowerServerResourcesPair resource = null;
		
		for (CloudInfo cloudInfo : cloudInfoList) {
			if (cloudInfo != selectedCloud) {
				double delay = selectedCloud.getDelay(cloudInfo);
				if (cloudInfo.hasEnoughResources(node)) {
					PowerServerResourcesPair result = cloudInfo.findAssignableServers(node);
					if ((delay < minDelay) && (result != null)) {
						minDelay = delay;
						resource = result;
						closestCloud = cloudInfo;
					}
				}
			}
		}
		
		if ((resource == null) || (closestCloud == null)) {
//			throw new RuntimeException("Failed to assign LQN task to a cloud. " + node);
			Debug.log("delay_init_deployment_failed: to assign LQN task to a cloud. " + node);
			return null;
		}
		
		return new ResourceCloudTuple(resource, closestCloud);
	}
	
	class ResourceCloudTuple {
		PowerServerResourcesPair resource;
		CloudInfo cloud;
		
		ResourceCloudTuple(PowerServerResourcesPair resource, CloudInfo cloud) {
			this.resource = resource;
			this.cloud = cloud;
		}
	}
}
