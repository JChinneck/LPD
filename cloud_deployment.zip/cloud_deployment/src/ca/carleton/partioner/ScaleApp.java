package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.HashMap;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.lqn.TupleGraphRoot;
import ca.carleton.testcases.TestCase;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;

public class ScaleApp {
	/* key - original node; value - list of replica nodes */
	HashMap<Node, ArrayList<Node>> scalingInfo;

	double throughput;
	
	double scaleTime;
	
	TupleGraphRoot graphRoot;
	
	public ScaleApp(TupleGraphRoot graphRoot, double throughput) {
		this.throughput = throughput;
		if (throughput <= 0) {
			throw new RuntimeException("[ERROR] throughput should be greater than 0 - throughput: " + throughput);
		}
		
		this.graphRoot = graphRoot;
	}
	
	public TupleGraphRoot scale() {
		double startTime = System.nanoTime();
		
		DirectedGraph<Node, Arc> originalGraph = graphRoot.getGraph();
		Node originalGraphRoot = graphRoot.getRoot();
		ArrayList<Node> lqnTasks = new ArrayList<>(originalGraph.getVertices());
		
		DirectedGraph<Node, Arc> scaledGraph = new DirectedSparseMultigraph<>();
		Node scaledGraphRoot = null;
		scalingInfo = new HashMap<>();
		
		for (Node lqnTask : lqnTasks) {
			int replicas = 1;
			if (lqnTask != originalGraphRoot) {
				replicas = numReplicasNeeded(lqnTask, throughput);
			}
			
			ArrayList<Node> replicaList = new ArrayList<>();
			
			double cpuDemandPerInvocation = lqnTask.getCpuDemandPerInvocation();
			double memory = lqnTask.getMemory();
//			double callsPerUserReqScaledDown = lqnTask.getCallsPerUserReq() / replicas;
			
			for (int i = 0; i < replicas; i++) {
				String newNodeName = lqnTask.getName();
				if (replicas > 1) {
					newNodeName += "_" + (i + 1);
				}
				Node node = new Node(cpuDemandPerInvocation, memory, newNodeName);
//				node.setCallsPerUserReq(callsPerUserReqScaledDown);
				if (lqnTask == originalGraphRoot) {
					if (scaledGraphRoot == null) {
						scaledGraphRoot = node;
					} else {
//						throw new RuntimeException("[ERROR] second attempt to set scaled graph root; only one root possible.");
						Debug.log("scale_app_failed: second attempt to set scaled graph root; only one root possible.");
						return null;
					}
				}
				
				replicaList.add(node);
				scaledGraph.addVertex(node);
			}
			
			scalingInfo.put(lqnTask, replicaList);
			
//			Debug.log("ScaleApp - node: " + lqnTask + " - replicas: " + replicas + " - replica list: " + replicaList);
		}
		
		if (scaledGraphRoot == null) {
//			throw new RuntimeException("[ERROR] scaled graph root not set.");
			Debug.log("scale_app_failed: scaled graph root not set.");
			return null;
		}
		
		for (Arc arc : originalGraph.getEdges()) {
			Node source = originalGraph.getSource(arc);
			Node dest = originalGraph.getDest(arc);
			
			ArrayList<Node> sourceReplicaList = scalingInfo.get(source);
			ArrayList<Node> destReplicaList = scalingInfo.get(dest);
			
			if ((sourceReplicaList == null) || (destReplicaList == null)) {
//				throw new RuntimeException("[ERROR] replica list not set.");
				Debug.log("scale_app_failed: replica list not set.");
				return null;
			}
			
//			Scale down factor is equivalent to number of destination replicas; not
//			a product of number of source replicas and number of destination replicas.
//			int scaleDownFactor = sourceReplicaList.size() * destReplicaList.size();
			int scaleDownFactor = destReplicaList.size();
			double scaledDownCalls = arc.getNumCalls() / scaleDownFactor;
//			double callsPerUserReqScaledDown = arc.getCallsPerUserReq() / scaleDownFactor;
			
			for (Node sourceReplica : sourceReplicaList) {
				for (Node destReplica : destReplicaList) {
					Arc replicaArc = new Arc(scaledDownCalls);
//					replicaArc.setCallsPerUserReq(callsPerUserReqScaledDown);
					scaledGraph.addEdge(replicaArc, sourceReplica, destReplica);
//					Debug.log("ScaleApp - add edge: " + replicaArc + " between " + sourceReplica + " and " + destReplica);
				}
			}
		}
		
		scaledGraphRoot.setCallsPerUserReq(1.0);
		TestCase.evaluateTaskCallsPerUserReq(scaledGraph, scaledGraphRoot);
		TestCase.evaluateArcCallsPerUserReq(scaledGraph, scaledGraphRoot);
		
		double endTime = System.nanoTime();
		this.scaleTime = (endTime - startTime)/1000000;
		
		return new TupleGraphRoot(scaledGraph, scaledGraphRoot);
	}
	
	public boolean isScalingNeeded() {
		boolean rc = false;
		ArrayList<Node> lqnTasks = new ArrayList<>(graphRoot.getGraph().getVertices());
		Node root = graphRoot.getRoot();
		
		for (Node lqnTask : lqnTasks) {
			if (lqnTask == root) {
				continue;
			}
			int replicas = numReplicasNeeded(lqnTask, throughput);
			if (replicas > 1) {
				rc = true;
				break;
			}
		}
		
		return rc;
	}
	
	public static int numReplicasNeeded(Node lqnTask, double throughput) {
		int replicas = (int)Math.ceil((throughput * lqnTask.getCallsPerUserReq() * lqnTask.getCpuDemandPerInvocation()) / Cloud.UtilNorm);
		if (replicas < 1) {
			throw new RuntimeException("[ERROR] Number of replicas can't be less than 1 - replicas: " + replicas);
		}
		return replicas;
	}
	
	public double getScaleTime() {
		return scaleTime;
	}
}
