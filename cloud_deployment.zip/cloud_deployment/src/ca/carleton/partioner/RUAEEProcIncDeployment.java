package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.partioner.CloudInfo.ServerResource;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class RUAEEProcIncDeployment extends Deployment {
	public RUAEEProcIncDeployment(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay) {
		super(clouds, servers, user, graph, root, windowSize, executionDelay);
	}

	@Override
	public int initialDeployment() {
		int rc = 0;
		long startTime = System.nanoTime();
		
		List<Node> nodesList = new ArrayList<>(graph.getVertices());
		Collections.sort(nodesList, new NodeSortAscendingProcReq());

//		Debug.log("InitDepl - LQN tasks: " + nodesList);
		
		PowerServerResourcesPair pwrServerRes = null;
		
		Debug.log("power_before_initdeployment: " + this.power + " W");
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}
			
			double bestScore = -1.0;
			CloudInfo selectedCloud = null;
			
//			double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
			double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
			double ramRequired = node.getMemory();
			double power = 0;
			ServerInfo bestServer = null;
			List<ServerResource> serverResources = null;
			
			for (CloudInfo cloudInfo : cloudInfoList) {
				if ((cloudInfo.totalAvailableSsjOpsCloud >= ssjOpsRequired) && (cloudInfo.totalAvailableRamCloud >= ramRequired)) {
					List<ServerInfo> availableServers = cloudInfo.serversAvailable;
					for (int i = availableServers.size() - 1; i >= 0; i--) {
						ServerInfo server = availableServers.get(i);
//					for (ServerInfo server : cloudInfo.serversAvailable) {
						double serverAvailableSsjOps =  server.availableSsjOps;
						double serverAvailableRAM = server.availableRam;
						if ((ssjOpsRequired <= serverAvailableSsjOps) && (ramRequired <= serverAvailableRAM)) {
							double serverUsedSsjOps = server.usedSsjOps;
							double serverUsedRAM = server.usedRam;
							double procU = (serverUsedSsjOps + ssjOpsRequired) / (serverUsedSsjOps + serverAvailableSsjOps);
							double memU = (serverUsedRAM + ramRequired) / (serverUsedRAM + serverAvailableRAM);
							double score = CloudInfo.calculateScoreRUAEE(procU, memU);
							if (score > bestScore) {
								bestScore = score;
								bestServer = server;
								selectedCloud = cloudInfo;
							}
						}
					}
				}
			}
			
			if ((selectedCloud == null) || (bestServer == null)) {
//				throw new RuntimeException("Failed to assign LQN task to a machine. " + node);
				Debug.log("ruaeeprocinc_init_deployment_failed: to assign LQN task to a machine. " + node);
				rc = -1;
				return rc;
			}
			
			
			serverResources = new ArrayList<>();
			power = bestServer.getPowerAdd(ssjOpsRequired);
			if (power <= 0) {
				Debug.log("ruaeeprocinc_init_deployment_failed: negative power " + power + " when assigned to " + node);
				rc = -1;
				return rc;
			}
			serverResources.add(selectedCloud.new ServerResource(bestServer, ramRequired, ssjOpsRequired));
			pwrServerRes = selectedCloud.new PowerServerResourcesPair(serverResources, power);
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (rc == 0) {
			Debug.log("power_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return rc;
	}
}
