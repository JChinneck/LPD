package ca.carleton.partioner;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import ca.carleton.cloud.Cloud;
import ca.carleton.common.CommandLineUtilities;
import ca.carleton.debug.Debug;
import ca.carleton.lqn.LqnGraph;
import ca.carleton.lqn.Template;
import ca.carleton.partioner.CloudInfo;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.partioner.CloudInfo.ServerResource;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class Verifier {

	/* Key is the cloud; values are the nodes assigned to the specific cloud */
	Multimap<CloudInfo, Node> partitions;

	/* Map LQN task to a list of ServerInfo */
	Map<Node, PowerServerResourcesPair> lqnTaskToServerMap;

	DirectedGraph<Node, Arc> graph;

	Node root;

	User user;

	LqnGraph lqnGraphVerification;

	StringBuilder processorInfo;

	StringBuilder taskInfo;
	
	StringBuilder taskInfoWithDelay;

	StringBuilder entryInfo;

	StringBuilder entryInfoWithoutDelay;

	StringBuilder entryInfoWithDelay;

	Map<Server, Double> speedRatios;

	Map<String, String> processorToLqnTask;

	static int serverCount = 1;

	Multimap<Node, String> nodeToProcessor;

	Map<Node, Node> oldNewMap;
	
	Deployment deployment;
	
	String delayProcessor = "delayP";
	
	/* Response time per user request for the original scaled LQN
	 * model.
	 */
	double executionDelaySpeedUp;
	double executionDelayNoSpeedUp;
	
	/* Output directory where the original and delay LQN models will 
	 * be stored along with their results from the solver.
	 */
	String outputDir;

	double timeToCreateAndSolveOriginalLQNModel;

	double timeToCreateAndSolveDelayLQNModel;
	
	int numUsers;
	
	public Verifier(String outputDir, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root,
			Multimap<CloudInfo, Node> partitions, Map<Node, PowerServerResourcesPair> lqnTaskToServerMap,
			Map<Node, Node> oldNewMap, Deployment deployment) {
		this.partitions = partitions;

		this.lqnTaskToServerMap = lqnTaskToServerMap;

		this.graph = graph;

		this.root = root;

		this.user = user;

		this.speedRatios = generateSpeedRatios(servers);

		this.nodeToProcessor = HashMultimap.create();

		this.processorToLqnTask = new HashMap<>();

		this.oldNewMap = oldNewMap;
		
		this.deployment = deployment;
		
		findExecutionDelay();
		
		this.outputDir = outputDir;
		
		this.numUsers = (int)Math.ceil(user.getThroughput() * executionDelaySpeedUp);
		
		Debug.log("verifier_execution_delay_speedup: " + executionDelaySpeedUp);
		Debug.log("verifier_execution_delay_no_speedup: " + executionDelayNoSpeedUp);
	}

	private Map<Server, Double> generateSpeedRatios(ArrayList<Server> servers) {
		Map<Server, Double> ratios = new HashMap<>();
		Server baselineServer = null;
		Double baselineServerSpeed = 0.0;

		for (Server server : servers) {
			if (baselineServer == null) {
				baselineServer = server;
				baselineServerSpeed = serverSpeed(server);
				ratios.put(server, 1.0);
			} else {
				if (server != baselineServer) {
					Double speedRatio = serverSpeed(server) / baselineServerSpeed;
					ratios.put(server, speedRatio);
				} else {
					throw new RuntimeException("Duplicate of baseline server found.");
				}
			}
		}

		return ratios;
	}

	/* serverSpeed returns ssj_ops per CPU */
	private Double serverSpeed(Server server) {
		ArrayList<Long> ssjOps = server.getSsjOps();
		Long maxSpeed = ssjOps.get(ssjOps.size() - 1);
		double numCpus = server.getHardwareThreads();
		return (maxSpeed / numCpus);
	}

	private String addProcessor(StringBuilder processorInfo, ServerResource server) {
		ServerInfo serverInfo = server.getServerInfo();
		Server serverProfile = serverInfo.serverRef;

		String processorName = serverInfo.getName() + "_" + serverCount++;
		
		int numCpus = (int)Math.ceil(server.reservedSsjOps/serverSpeed(serverProfile));
		
		double speedRatio = speedRatios.get(serverProfile);

		Debug.log("Adding Processor: name = " + processorName + " cpus = " + numCpus + " speed = " + speedRatio);
		processorInfo.append(Template.lqnMultiProcessor(processorName, numCpus, speedRatio));

		return processorName;
	}

	private void addNormalProcessorsAndTasks(StringBuilder processorInfo, StringBuilder taskInfo,
			StringBuilder entryInfo) {
		for (CloudInfo cloud : partitions.keySet()) {
			for (Node node : partitions.get(cloud)) {
				if (root == node) {
					continue;
				}
				PowerServerResourcesPair resource = lqnTaskToServerMap.get(node);

				if (resource == null) {
					if (oldNewMap == null) {
						Debug.log("[ERROR] Creating LQN: PowerServerResourcesPair is null and oldNewMap is null.");
						continue;
					}
					resource = lqnTaskToServerMap.get(oldNewMap.get(node));
				}

				List<ServerResource> servers = resource.serverResources;
				int numServers = servers.size();

				if (numServers <= 0) {
					throw new RuntimeException("No servers assigned to a LqnTask: num_servers = " + numServers);
				} else {
					for (int i = 0; i < numServers; i++) {
						ServerResource server = servers.get(i);
						String processorName = addProcessor(processorInfo, server);

						double cpuDemand = node.getCpuDemandPerInvocation();
						// double cpuDemand = server.reservedSsjOps * Cloud.UtilNorm / Cloud.CpuDemandToSsjOpsConversion;

						String lqnTaskName = node.getName();
						if (numServers > 1) {
							lqnTaskName += "_" + (i + 1);
						}

						taskInfo.append(Template.normalTask(lqnTaskName, lqnTaskName, processorName, numUsers));

						entryInfo.append(Template.entryDemand(lqnTaskName, cpuDemand));

						nodeToProcessor.put(node, processorName);
						processorToLqnTask.put(processorName, lqnTaskName);
					}
				}
			}
		}

	}

	private void addReferenceProcessorAndTask(StringBuilder processorInfo, StringBuilder taskInfo) {
		String ref = root.getName();

//		processorInfo.append(Template.referenceProcessor(ref, numUsers));
		processorInfo.append(Template.delayCenterProcessor(ref));
		taskInfo.append(Template.referenceTask(ref, ref, ref, numUsers));

		processorInfo.append(Template.delayCenterProcessor(delayProcessor));
		
		nodeToProcessor.put(root, ref);
		processorToLqnTask.put(ref, ref);
	}

	private void addEntryCallWithoutDelay(StringBuilder entryInfo) {
		for (Arc arc : graph.getEdges()) {
			Node source = graph.getSource(arc);
			Node dest = graph.getDest(arc);
			double calls = arc.getNumCalls();
			
			entryInfo.append(Template.entryCall(source.getName(), dest.getName(), calls));
		}
	}

	private void addEntryCallWithDelay(StringBuilder taskInfo, StringBuilder entryInfo) {
		for (Arc arc : graph.getEdges()) {
			Node source = graph.getSource(arc);
			Node dest = graph.getDest(arc);
			
			CloudInfo sourceCloud = null;
			CloudInfo destCloud = null;
			
			String sourceName = null;
			String destName = null;
			
			double delay = 0.0;
			
			if (dest == root) {
				throw new RuntimeException("Not possible to call a reference task");
			} else if (source == root) {
				destCloud = deployment.findNode(dest);
				
				sourceName = root.getName();
				destName = dest.getName();
				
				delay = user.getDelay(destCloud.getCloudRef());
			} else {
				sourceCloud = deployment.findNode(source);
				destCloud = deployment.findNode(dest);
	
				sourceName = source.getName();
				destName = dest.getName();
				
				if (sourceCloud != destCloud) {
					delay = sourceCloud.getDelay(destCloud);
				}
			}
			
			if ((sourceName == null) || (destName == null)) {
				throw new RuntimeException("Source or Destination LQN task name can't be null.");
			}
			
			double calls = arc.getNumCalls();
			if (sourceCloud == destCloud) {
				entryInfo.append(Template.entryCall(sourceName, destName, calls));
			} else {
				if (delay == 0) {
					throw new RuntimeException("Delay can't be zero");
				}
				
				String delayTaskName = "delay_" + sourceName + "_" + destName;
				
				taskInfo.append(Template.delayTask(delayTaskName, delayTaskName, delayProcessor));
				
//				entryInfo.append(Template.delayEntry(delayTaskName, delay));
				entryInfo.append(Template.entryDemand(delayTaskName, delay));
//				entryInfo.append(Template.entryDemand(delayTaskName, 0.0));
				
				entryInfo.append(Template.entryCall(sourceName, delayTaskName, calls));
				entryInfo.append(Template.entryCall(delayTaskName, destName, 1));
			}
			entryInfo.append("\n");
		}
	}

	private void generateCommonLQNSections() {
		processorInfo = new StringBuilder();
		taskInfo = new StringBuilder();
		entryInfo = new StringBuilder();

		processorInfo.append(Template.lqnProcessorsHeader);
		taskInfo.append(Template.taskHeader);
		entryInfo.append(Template.entriesHeader);

		addReferenceProcessorAndTask(processorInfo, taskInfo);
		addNormalProcessorsAndTasks(processorInfo, taskInfo, entryInfo);

	}

	private void generateNonDelayLQNSections() {
		entryInfoWithoutDelay = new StringBuilder();
		addEntryCallWithoutDelay(entryInfoWithoutDelay);
	}

	private void generateWithDelayLQNSections() {
		entryInfoWithDelay = new StringBuilder();
		taskInfoWithDelay = new StringBuilder();
		addEntryCallWithDelay(taskInfoWithDelay, entryInfoWithDelay);
	}

	private String createOriginalLqn() {
		generateCommonLQNSections();
		generateNonDelayLQNSections();
		
		processorInfo.append(Template.lqnProcessorsFooter);
		taskInfo.append(Template.taskFooter);
		
		StringBuilder lqn = new StringBuilder();

		lqn.append(Template.lqnHeader);

		lqn.append(processorInfo.toString());
		lqn.append(taskInfo.toString());
		lqn.append(entryInfo.toString());
		lqn.append("\n");
		lqn.append(entryInfoWithoutDelay.toString());
		lqn.append(Template.entriesFooter);

		lqn.append(Template.lqnFooter);

		String originalLQNModel = lqn.toString();
		
		Debug.log("\n" + originalLQNModel);
		
		return originalLQNModel;
	}
	
	private String createDelayLqn() {
		generateCommonLQNSections();
		generateWithDelayLQNSections();
		
		processorInfo.append(Template.lqnProcessorsFooter);
		
		StringBuilder lqn = new StringBuilder();

		lqn.append(Template.lqnHeader);

		lqn.append(processorInfo.toString());
		
		lqn.append(taskInfo.toString());
		lqn.append("\n");
		lqn.append(taskInfoWithDelay.toString());
		lqn.append(Template.taskFooter);
		
		lqn.append(entryInfo.toString());
		lqn.append("\n");
		lqn.append(entryInfoWithDelay.toString());
		lqn.append(Template.entriesFooter);

		
		lqn.append(Template.lqnFooter);

		String delayLQNModel = lqn.toString();
		
		Debug.log("\n" + delayLQNModel);
		
		return delayLQNModel;
	}
	
	private void findExecutionDelay() {
		double utilNorm = Cloud.UtilNorm;
		executionDelaySpeedUp = 0.0;
		executionDelayNoSpeedUp = 0.0;
		
		for (Node node : graph.getVertices()) {
			if (node == root) {
				continue;
			}
			PowerServerResourcesPair resource = lqnTaskToServerMap.get(node);

			if (resource == null) {
				if (oldNewMap == null) {
					Debug.log("[ERROR] Creating LQN: PowerServerResourcesPair is null and oldNewMap is null.");
					continue;
				}
				resource = lqnTaskToServerMap.get(oldNewMap.get(node));
			}

			List<ServerResource> servers = null;
			try {
				servers = resource.serverResources;
			} catch (NullPointerException ex) {
				System.out.println("node: " + node.getName() + " resource: " + resource);
			}
			int numServers = servers.size();

			if (numServers <= 0) {
				throw new RuntimeException("No servers assigned to a LqnTask: num_servers = " + numServers);
			} else if (numServers > 1) {
				throw new RuntimeException("More than one server assigned to the LQN task. This is currently not allowed.");
			}
			
			ServerResource server = servers.get(0);
			ServerInfo serverInfo = server.getServerInfo();
			Server serverProfile = serverInfo.serverRef;
			double speedRatio = speedRatios.get(serverProfile);
			
			executionDelaySpeedUp += ((1/speedRatio)*(node.getCpuDemandPerUserReq()/(1 - utilNorm)));
			executionDelayNoSpeedUp += (node.getCpuDemandPerUserReq()/(1 - utilNorm));
		}
		
	}
	
	private void solveLqnModel(String lqnModel, String modelName) {
		Path lqnInputFile = Paths.get(outputDir + "/" + modelName + ".lqn");
		Path lqnOutputFile = Paths.get(outputDir + "/" + modelName + ".out");
		
		if (Files.isDirectory(lqnInputFile)) {
			throw new IllegalArgumentException("lqnInputFile is a directory.");
		}
		if (Files.isDirectory(lqnOutputFile)) {
			throw new IllegalArgumentException("lqnOutputFile is a directory.");
		}

		try {
			BufferedWriter lqnFileWriter;
			if (Files.exists(lqnInputFile)) {
				Files.delete(lqnInputFile);
			}
			if (Files.exists(lqnOutputFile)) {
				Files.delete(lqnOutputFile);
			}
			lqnFileWriter = Files.newBufferedWriter(lqnInputFile, StandardOpenOption.CREATE_NEW);
			lqnFileWriter.write(lqnModel);
			lqnFileWriter.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

//		CommandLineUtilities.bash("lqns", "-o", lqnOutputFile.toString(), lqnInputFile.toString());
	}
	
	/* This method will generate the original and delay-added LQN models and solve them. */
	public void verify(String prefix) {
		long startTime = 0;
		long endTime = 0;
		
		startTime = System.nanoTime();
		String originalLQNModel = createOriginalLqn();
		solveLqnModel(originalLQNModel, prefix + "original");
		endTime = System.nanoTime();
		this.timeToCreateAndSolveOriginalLQNModel = (endTime - startTime)/1000000;
		
		startTime = System.nanoTime();
		String delayLQNModel = createDelayLqn();
		solveLqnModel(delayLQNModel, prefix + "delay");
		endTime = System.nanoTime();
		this.timeToCreateAndSolveDelayLQNModel = (endTime - startTime)/1000000;
	}
}
