package ca.carleton.partioner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CPlexParser implements Serializable {
	String inputFile;
	
	String hostDataStr[];
	int hostDataStrIndex = 0;
	int maxHosts;
	HostData hostData[][];

	/* "num_clouds x num_tasks" elements */
	String objectiveStr[];

	int objectiveStrIndex = 0;
	
	/* [tasks][clouds][hosts] */
	boolean objective[][][];
	
	String cloudNames[];
	String taskNames[];
	
	Map<String, Assignment> deployment;
	
	public CPlexParser(String inputFile) {
		this.inputFile = inputFile;
	}

	public static void main(String[] args) throws IOException {
		//String sampleInputFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_configs/model_A8_v3/cplex_output.txt";
		String sampleInputFile = "/home/computer/Downloads/cplexmcadfiles/combined_dat_mcad_output/model_A8_case21_model_A8_v4_-1_all.log";
		
		CPlexParser cplexOutput = new CPlexParser(sampleInputFile);
		cplexOutput.process();
		
		for (String taskName : cplexOutput.taskNames) {
			System.out.println("task: " + taskName
							+ " cloud: " + cplexOutput.findCloud(taskName)
							+ " host: " + cplexOutput.findHost(taskName));
		}
		
		System.out.println();
		
		for (int i = 0; i < cplexOutput.taskNames.length; i++) {
			System.out.println("task: " + cplexOutput.taskNames[i]
							+ " cloud: " + cplexOutput.findCloud(i)
							+ " host: " + cplexOutput.findHost(i));
		}
	}
	
	public String findCloud(int task) {
		if (task >= taskNames.length) {
			throw new IllegalArgumentException("invalid task provided.");
		}
		
		return deployment.get(taskNames[task]).cloudName;
	}
	
	public String findHost(int task) {
		if (task >= taskNames.length) {
			throw new IllegalArgumentException("invalid task provided.");
		}
		
		return deployment.get(taskNames[task]).hostName;
	}
	
	public String findCloud(String taskName) {
		Assignment assignment = null;
		for (String key : deployment.keySet()) {
			if (key.matches(".*" + taskName + ".*")) {
				assignment = deployment.get(key);
			}
		}
		String cloudName = null;
		if (assignment == null) {
			throw new NullPointerException("assignment is null");
		}
		cloudName = assignment.cloudName;
		if (cloudName == null) {
			throw new NullPointerException("cloud assignment not found.");
		}
		return cloudName;
	}
	
	public String findHost(String taskName) {
		Assignment assignment = null;
		for (String key : deployment.keySet()) {
			if (key.matches(".*" + taskName + ".*")) {
				assignment = deployment.get(key);
			}
		}
		String hostName = null;
		if (assignment == null) {
			throw new NullPointerException("assignment is null");
		}
		hostName = assignment.hostName;
		if (hostName == null) {
			throw new NullPointerException("host assignment not found.");
		}
		return hostName;
	}
	
	public boolean process() {
		boolean rc = true;
		boolean appendHostData = false;
		boolean appendObjectiveData = false;
		
		try {
			File myObj = new File(inputFile);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				if (data.matches(".*max_hosts = .*")) {
					processMaxHosts(data);
				}
				if (data.matches(".*cloud_names = .*")) {
					processCloudNames(data);
					continue;
				}
				if (data.matches(".*task_names = .*")) {
					processTaskNames(data);
					continue;
				}
				if (data.matches(".*cloud_hosts = .*")) {
					hostDataStr = new String[cloudNames.length];
					hostDataStr[hostDataStrIndex] = data;
					hostDataStrIndex += 1;
					appendHostData = true;
					continue;
				}
				if (appendHostData) {
					hostDataStr[hostDataStrIndex] = data;
					hostDataStrIndex += 1;
					if (data.matches(".*\\]\\];*")) {
						appendHostData = false;
						processHostData();
					}
					continue;
				}
				if (data.matches(".*d_ikl = .*")) {
					objectiveStr = new String[cloudNames.length * taskNames.length];
					objectiveStr[objectiveStrIndex] = data;
					objectiveStrIndex += 1;
					appendObjectiveData = true;
					continue;
				}
				if (appendObjectiveData) {
					objectiveStr[objectiveStrIndex] = data;
					objectiveStrIndex += 1;
					if (data.matches(".*\\]\\]\\];*")) {
						appendObjectiveData = false;
						processObjectiveData();
					}
					continue;
				}
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		
		return rc;
	}
	
	private void printObjectiveArray() {
		System.out.println("d_ikl = [");
		for (int task = 0; task < objective.length; task++) {
			System.out.println("[");
			for (int cloud = 0; cloud < objective[task].length; cloud++) {
				System.out.print("[");
				for (int host = 0; host < objective[task][cloud].length; host++) {
					if (objective[task][cloud][host]) {
						System.out.print("1 ");
					} else {
						System.out.print("0 ");
					}
				}
				System.out.println("]");
			}
			System.out.println("]");
		}
		System.out.println("];");
	}

	private void processObjectiveData() {
		objective = new boolean[taskNames.length][cloudNames.length][this.maxHosts];
		deployment = new HashMap<String, Assignment>();
		
		int taskIndex = 0;
		
		for (int i = 0; i < objectiveStr.length; i++) {
			String updated = objectiveStr[i].replaceAll("d_ikl = |\\[|\\s\\s+|;|\\]", "");
//			System.out.println(updated);
			
			String split[] = updated.split("\\s");
			if (split.length != this.maxHosts) {
				throw new IllegalArgumentException("task can only be assigned to one of " + this.maxHosts + " hosts.");
			}
			
			int hostIndex = -1;
			for (int j = 0; j < split.length; j++) {
				if (split[j].matches(".*1.*")) {
					hostIndex = j;
				}
			}
			
			/* Task <-> Host assignment found. */
			if (hostIndex != -1) {
				int cloudIndex = i % cloudNames.length;
				
//				System.out.println("objectiveStrIndex: " + i);
//				System.out.println("taskIndex: " + taskIndex + " cloudIndex: " + cloudIndex + " hostIndex: " + hostIndex);
//				System.out.println(taskNames[taskIndex] + " -- " + cloudNames[cloudIndex]);
				
				objective[taskIndex][cloudIndex][hostIndex] = true;
				
				Assignment assignment = new Assignment(cloudNames[cloudIndex], hostData[cloudIndex][hostIndex].hostName);
				deployment.put(taskNames[taskIndex], assignment);
				
				taskIndex += 1;
			}
		}
		
//		printObjectiveArray();
	}

	private void processMaxHosts(String data) {
		String maxHosts = data.replaceAll("max_hosts = |;", "");
		this.maxHosts = Integer.parseInt(maxHosts);
		
//		System.out.println("max_hosts = " + maxHosts);
	}

	private void processHostData() {
		hostData = new HostData[cloudNames.length][maxHosts];
		if (hostDataStr.length != cloudNames.length) {
			throw new IllegalArgumentException("host info unavailable for all clouds.");
		}
		
		for (int i = 0; i < hostDataStr.length; i++) {
			String updated = hostDataStr[i].replaceAll("cloud_hosts = |;|\"|\"|<|\\[|\\]", "");
			
//			System.out.println(updated);
			
			String hostsInfo[] = updated.split(">, ");
			
			if (hostsInfo.length != this.maxHosts) {
				throw new IllegalArgumentException("number of hosts != " + this.maxHosts);
			}
			
			for (int j = 0; j < hostsInfo.length; j++) {
				String infoFiltered = hostsInfo[j].replaceAll(">|\\s+", "");
//				System.out.println(infoFiltered);
				
				String infoSplit[] = infoFiltered.split(",");
				if (infoSplit.length != 7) {
					throw new IllegalArgumentException("host info incomplete. 7 elements expected per host.");
				}
				
				String hostName = infoSplit[0];
				float h_M = Float.parseFloat(infoSplit[1]);
				float h_s = Float.parseFloat(infoSplit[2]);
				float h_o = Float.parseFloat(infoSplit[3]);
				float h_ptot = Float.parseFloat(infoSplit[4]);
				float h_mtot = Float.parseFloat(infoSplit[5]);
				float h_sf = Float.parseFloat(infoSplit[6]);
				
				hostData[i][j] = new HostData(hostName, h_M, h_s, h_o, h_ptot, h_mtot, h_sf);
//				System.out.println(hostData[i][j].toString());
			}
		}
		
//		System.out.println();
	}
	
	private void processCloudNames(String data) {
		String justCloudNames = data.replaceAll("cloud_names = |;|,|\"|\"|\\[|\\]", "");
		cloudNames = justCloudNames.split(" ");
		
//		for (String cloudName : cloudNames) {
//			System.out.println(":" + cloudName + ": length = " + cloudName.length());
//		}
//		System.out.println();
	}

	private void processTaskNames(String data) {
		String justTaskNames = data.replaceAll("task_names = |;|,|\"|\"|\\[|\\]", "");
		taskNames = justTaskNames.split(" ");
		
//		for (String taskName : taskNames) {
//			System.out.println(":" + taskName + ": length = " + taskName.length());
//		}
//		System.out.println();
	}
	
	class HostData implements Serializable {
		String hostName;
		float h_M;
		float h_s;
		float h_o;
		float h_ptot;
		float h_mtot;
		float h_sf;
		
		public HostData(String hostName, float h_M, float h_s, float h_o, float h_ptot, float h_mtot, float h_sf) {
			this.hostName = hostName;
			this.h_M = h_M;
			this.h_s = h_s;
			this.h_o = h_o;
			this.h_ptot = h_ptot;
			this.h_mtot = h_mtot;
			this.h_sf = h_sf;
		}
		
		@Override
		public String toString() {
			return hostName + ", " + h_M + ", " + h_s + ", " + h_o + ", " + h_ptot + ", " + h_mtot + ", " + h_sf;
		}
	}

	class Assignment implements Serializable {
		String cloudName;
		String hostName;
		
		public Assignment(String cloudName, String hostName) {
			this.cloudName = cloudName;
			this.hostName = hostName;
		}
		
		@Override
		public String toString() {
			return "cloud: " + this.cloudName + " host: " + this.hostName;
		}
	}
}