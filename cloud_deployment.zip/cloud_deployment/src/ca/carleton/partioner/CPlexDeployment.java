package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class CPlexDeployment extends Deployment {
	CPlexParser cplexOutput;
	public CPlexDeployment(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay, String cplexOutputFile) {
		super(clouds, servers, user, graph, root, windowSize, executionDelay);
		cplexOutput = new CPlexParser(cplexOutputFile);
		cplexOutput.process();
	}

	@Override
	public int initialDeployment() {
		int rc = 0;
		long startTime = System.nanoTime();
		
		List<Node> nodesList = new ArrayList<>(graph.getVertices());
//		Collections.sort(nodesList, new NodeSortDescendingProcReq());

//		Debug.log("InitDepl - LQN tasks: " + nodesList);
		
		Debug.log("cplex_before_initdeployment: " + this.power + " W");
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}
			
			String nodeName = node.getName();
//			Debug.log("cplex node name: " + nodeName);
			String cloudName = cplexOutput.findCloud(nodeName);
			String hostName = cplexOutput.findHost(nodeName);
			
			Debug.log("cloud: " + cloudName + " host: " + hostName);
			
			double minPower = Double.MAX_VALUE;
			CloudInfo selectedCloud = null;
			
			for (CloudInfo cloudInfo : cloudInfoList) {
				if (cloudInfo.cloudRef.getCloudName().matches(cloudName)) {
//					Debug.log(cloudName);
					selectedCloud = cloudInfo;
				}
			}
			
			if (selectedCloud == null) {
				// throw new RuntimeException("Failed to assign LQN task to a machine. " + node);
				Debug.log("power_init_deployment_failed: to assign LQN task to a machine. " + node);
				rc = -1;
				break;
			}
			
			PowerServerResourcesPair pwrServerRes = selectedCloud.assignToHost(node, hostName);
			
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (rc == 0) {
			Debug.log("cplex_after_initdeployment: " + this.power + " W");
			Debug.log("CPLEX power: " + this.verifyPowerCplex() + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return rc;
	}
}
