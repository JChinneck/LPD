package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.common.collect.Collections2;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.partioner.CloudInfo.ServerComparatorDecreasingPowerEfficient;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.partioner.CloudInfo.ServerResource;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class PowerBound extends DeploymentBound {
	public PowerBound(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay) {
		super(clouds, servers, user, graph, root, windowSize, executionDelay);
	}
	
	/* This comparator will sort servers in decreasing order of power efficiency */
	class ServerComparatorDecreasingPowerEfficient implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double perfToPowerS1 = server1.serverRef.getOverallPerfToPower();
			Double perfToPowerS2 = server2.serverRef.getOverallPerfToPower();
			
			return perfToPowerS2.compareTo(perfToPowerS1);
		}
	}

	/* This comparator will sort servers in increasing order of power efficiency */
	class ServerComparatorIncreasingPowerEfficient implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double perfToPowerS1 = server1.serverRef.getOverallPerfToPower();
			Double perfToPowerS2 = server2.serverRef.getOverallPerfToPower();
			
			return perfToPowerS1.compareTo(perfToPowerS2);
		}
	}
	
	/* This comparator will sort servers in decreasing order of processing capacity */
	class ServerComparatorDecreasingProcCap implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double availableSsjOpsS1 = server1.availableSsjOps;
			Double availableSsjOpsS2 = server2.availableSsjOps;
			
			return availableSsjOpsS2.compareTo(availableSsjOpsS1);
		}
	}
	
	/* This comparator will sort servers in increasing order of processing capacity */
	class ServerComparatorIncreasingProcCap implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double availableSsjOpsS1 = server1.availableSsjOps;
			Double availableSsjOpsS2 = server2.availableSsjOps;
			
			return availableSsjOpsS1.compareTo(availableSsjOpsS2);
		}
	}
	
	/* This comparator will sort servers in decreasing order of server's maximum ssj_ops to power ratio */
	class ServerComparatorDecreasingMaxPerfToPower implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double availableSsjOpsS1 = server1.serverRef.getMaxPerfToPower();
			Double availableSsjOpsS2 = server2.serverRef.getMaxPerfToPower();
			
			return availableSsjOpsS2.compareTo(availableSsjOpsS1);
		}
	}
	
	@Override
	public int findBound1(double appTotalSsjOps, double appTotalRAM) {
		Debug.log("appTotalSsjOps: " + appTotalSsjOps + " appTotalRAM: " + appTotalRAM);
		int rc = 0;
		
		long startTime = System.nanoTime();
		
		ArrayList<ServerInfo> allAvailableServers = new ArrayList<>();
		for (CloudInfo cloudInfo : cloudInfoList) {
			allAvailableServers.addAll(cloudInfo.serversAvailable);
		}
		
		ArrayList<ServerInfo> allAvailableServersMaxPPDec = new ArrayList<>(allAvailableServers);
		Collections.sort(allAvailableServersMaxPPDec, new ServerComparatorDecreasingMaxPerfToPower());
//		for (ServerInfo server : allAvailableServers) {
//			Debug.log("server name: " + server.serverRef.getServerName());
//		}
		
//		double ssjOpsRequired = appTotalSsjOps / Cloud.UtilNorm;
		double ssjOpsRequired = appTotalSsjOps;
		double ramRequired = appTotalRAM;
		double localPower = 0;
		
		for (ServerInfo server : allAvailableServersMaxPPDec) {
			Debug.log("server name: " + server.serverRef.getServerName());
			double maxPerfToPower = server.serverRef.getMaxPerfToPower();
			double maxPerfToPowerUtil = server.serverRef.getMaxPerfToPowerUtil();
			
			double totalSsjOps = server.totalSsjOps;
			double maxPerfToPowerSsjOps = totalSsjOps * maxPerfToPowerUtil / 100;
			
//			double availableSsjOps = server.availableSsjOps;
//			
//			/* skip very large servers if they are not sufficiently utilized */
//			 / Cloud.UtilNormif (totalSsjOps >= 3000000) {
//				if (ssjOpsRequired < availableSsjOps) {
//					double usedSsjOps = server.usedSsjOps;
//					double utilAfterAssignment = (usedSsjOps + ssjOpsRequired)*100/totalSsjOps;
//					/* don't fill large servers if we can't achieve utilization > maxPerfToPowerUtil - 30% */
//					if ((maxPerfToPowerUtil - utilAfterAssignment) < 30) {
//					} else {
//						continue;
//					}
//				}
//			}
			
//			if (server.availableSsjOps <= maxPerfToPowerSsjOps) {
//				maxPerfToPowerSsjOps = server.availableSsjOps;
//			}
			
			if (ssjOpsRequired <= maxPerfToPowerSsjOps) {
				/* If a task fits on a server, we have allocated enough resources to support the 
				 * task on the cloud. 
				 */
				double tempPower = ssjOpsRequired/maxPerfToPower;
//				double tempPower = server.getPower(ssjOpsRequired);
				ssjOpsRequired -= ssjOpsRequired;
				ramRequired -= ramRequired;
				localPower += tempPower;
//				Debug.logNoNewLine(" power: " + tempPower);
//				Debug.logNoNewLine("\n");
				break;
			} 
//			This allows a LQN task to be assigned to multiple servers. It is difficult to handle such
//			a scenario in the LQN verification stage. So, we avoid assigning a LQN to multiple servers.
			else {
				/* If a task doesn't fit on a server, we assign the entire server to it.
				 * We keep on assigning servers to a task until we have satisfied its resource requirements.
				 * By assigning multiple servers, we have duplicated the task on each server.
				 */
				double tempPower = maxPerfToPowerSsjOps/maxPerfToPower;
//				double tempPower = server.getPower(maxPerfToPowerSsjOps);
				ssjOpsRequired -= maxPerfToPowerSsjOps;
				ramRequired -= server.availableRam;
				localPower += tempPower;
//				Debug.logNoNewLine(" power: " + tempPower);
//				Debug.logNoNewLine("\n");
			}
		}
		
		if (ssjOpsRequired > 0) {
			Debug.log("power_bound_failed: remaining ssj_ops = " + ssjOpsRequired);
			rc = -1;
			return rc;
		}
		
		this.power = localPower;
		
		if (rc == 0) {
			Debug.log("power_bound_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;

		return rc;
	}
	
	@Override
	public int findBound(double appTotalSsjOps, double appTotalRAM) {
		Debug.log("appTotalSsjOps: " + appTotalSsjOps + " appTotalRAM: " + appTotalRAM);
		int rc = 0;
		
		long startTime = System.nanoTime();
		
		ArrayList<ServerInfo> allAvailableServers = new ArrayList<>();
		for (CloudInfo cloudInfo : cloudInfoList) {
			allAvailableServers.addAll(cloudInfo.serversAvailable);
		}
//		
//		ArrayList<ServerInfo> allAvailableServersPEDec = new ArrayList<>(allAvailableServers);
//		Collections.sort(allAvailableServersPEDec, new ServerComparatorDecreasingPowerEfficient());
////		for (ServerInfo server : allAvailableServers) {
////			Debug.log("server name: " + server.serverRef.getServerName());
////		}
//		
//		ArrayList<ServerInfo> allAvailableServersPEInc = new ArrayList<>(allAvailableServers);
//		Collections.sort(allAvailableServersPEInc, new ServerComparatorIncreasingPowerEfficient());
//		
//		ArrayList<ServerInfo> allAvailableServersPCDec = new ArrayList<>(allAvailableServers);
//		Collections.sort(allAvailableServersPCDec, new ServerComparatorDecreasingProcCap());
//		
//		ArrayList<ServerInfo> allAvailableServersPCInc = new ArrayList<>(allAvailableServers);
//		Collections.sort(allAvailableServersPCInc, new ServerComparatorIncreasingProcCap());
//		
		Collection<List<ServerInfo>> serverListPerms = Collections2.permutations(allAvailableServers);
		
//		ArrayList<ArrayList<ServerInfo>> serverListPerms = new ArrayList<ArrayList<ServerInfo>>(Arrays.asList(allAvailableServersPEDec, allAvailableServersPEInc, allAvailableServersPCDec, allAvailableServersPCInc));
		
		
		ArrayList<Double> powerValues = new ArrayList<>();
//		ArrayList<Float> serverMaxCaps = new ArrayList<>(Arrays.asList(1.0f, 0.975f, 0.95f, 0.925f, 0.9f, 0.875f, 0.85f, 0.825f, 0.8f, 0.775f, 0.75f, 0.725f, 0.7f, 0.675f, 0.65f, 0.625f, 0.6f));
		Debug.log("permuations: " + serverListPerms.size());
		
//		for (Float serverMaxCap : serverMaxCaps) {
		for (List<ServerInfo> serverListPerm : serverListPerms) {
			for (float serverMaxCap = 1.0f; serverMaxCap >= 0.75; serverMaxCap -= 0.025f) {
				ArrayList<ServerInfo> allAvailableServersCopy = new ArrayList<>(serverListPerm);
//				Debug.log("Server capacity: " + serverMaxCap);
				while (true) {
//					double ssjOpsRequired = appTotalSsjOps / Cloud.UtilNorm;
					double ssjOpsRequired = appTotalSsjOps;
					double ramRequired = appTotalRAM;
					double localPower = 0;
					
					for (ServerInfo server : allAvailableServersCopy) {
//						Debug.logNoNewLine("server name: " + server.serverRef.getServerName());
						if (ssjOpsRequired <= server.availableSsjOps) {
							/* If a task fits on a server, we have allocated enough resources to support the 
							 * task on the cloud. 
							 */
							double tempPower = server.getPowerAdd(ssjOpsRequired);
							ssjOpsRequired -= ssjOpsRequired;
							ramRequired -= ramRequired;
							localPower += tempPower;
//							Debug.logNoNewLine(" power: " + tempPower);
//							Debug.logNoNewLine("\n");
							break;
						} 
			//					This allows a LQN task to be assigned to multiple servers. It is difficult to handle such
			//					a scenario in the LQN verification stage. So, we avoid assigning a LQN to multiple servers.
						else {
							/* If a task doesn't fit on a server, we assign the entire server to it.
							 * We keep on assigning servers to a task until we have satisfied its resource requirements.
							 * By assigning multiple servers, we have duplicated the task on each server.
							 */
							double tempPower = server.getPowerAdd(server.availableSsjOps * serverMaxCap);
							ssjOpsRequired -= (server.availableSsjOps * serverMaxCap);
							ramRequired -= server.availableRam;
							localPower += tempPower;
//							Debug.logNoNewLine(" power: " + tempPower);
//							Debug.logNoNewLine("\n");
						}
					}
//					Debug.logNoNewLine("total power: " + localPower + "\n");
					if (ssjOpsRequired != 0) {
						break;
					}
					allAvailableServersCopy.remove(0);
					powerValues.add(localPower);
				}
			}
		}
		
		this.power = Collections.min(powerValues);
		
		if (rc == 0) {
			Debug.log("power_bound_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;

		return rc;
	}
	
	@Override
	public int initialDeployment(double appTotalSsjOps, double appTotalRAM) {
		Debug.log("appTotalSsjOps: " + appTotalSsjOps + " appTotalRAM: " + appTotalRAM);
		int rc = 0;
		long startTime = System.nanoTime();
		
		double minSsjOpsPerNode = 450000;
		double remainingSsjOps = appTotalSsjOps;

		List<Node> nodesList = new ArrayList<>();
		int numLargeNodes = (int) Math.ceil(appTotalSsjOps/minSsjOpsPerNode);
		Debug.log("numLargeNodes: " + numLargeNodes);
		for (int i = 0; i < numLargeNodes; i++) {
			Node newNode= null;
			if (remainingSsjOps > minSsjOpsPerNode) {
				double ram = minSsjOpsPerNode/appTotalSsjOps*appTotalRAM;
				newNode = new Node(minSsjOpsPerNode/Cloud.CpuDemandToSsjOpsConversion, ram, "node_" + i);
				remainingSsjOps -= minSsjOpsPerNode;
			} else {
				double ram = remainingSsjOps/appTotalSsjOps*appTotalRAM;
				newNode = new Node(remainingSsjOps/Cloud.CpuDemandToSsjOpsConversion, ram, "node_" + i);
				remainingSsjOps -= remainingSsjOps;
			}
			nodesList.add(newNode);
			Debug.log(newNode.toString());
		}
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}

			PowerServerResourcesPair pwrServerRes = null;
			double minPower = Double.MAX_VALUE;
			CloudInfo selectedCloud = null;
			
			for (CloudInfo cloudInfo : cloudInfoList) {
				if (cloudInfo.hasEnoughResources(node)) {
					PowerServerResourcesPair result = cloudInfo.findAssignableServersBound(node);
					if (result != null) {
						double tmpPower = result.power;
						Debug.logNoNewLine("cloud name: " + cloudInfo.getCloudRef().getCloudName() + " power: " + tmpPower + " servers: ");
						for (ServerResource svrResr : result.serverResources) {
							Debug.logNoNewLine(svrResr.serverInfoRef.getName() + " ");
						}
						System.out.println();
						if (tmpPower < minPower) {
							minPower = tmpPower;
							pwrServerRes = result;
							selectedCloud = cloudInfo;
						}
					}
				}
			}
			
			if (selectedCloud == null) {
//				throw new RuntimeException("Failed to assign LQN task to a machine. " + node);
				Debug.log("power_bound_init_deployment_failed: to assign LQN task to a machine. " + node);
				rc = -1;
				break;
			}
			
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (rc == 0) {
			Debug.log("power_bound_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return rc;
	}
	
	@Override
	public int initialDeployment() {
		int rc = 0;
		long startTime = System.nanoTime();
		
		List<Node> nodesList = new ArrayList<>(graph.getVertices());
		Collections.sort(nodesList, new NodeSortDescendingProcReq());

//		Debug.log("InitDepl - LQN tasks: " + nodesList);
		
		PowerServerResourcesPair pwrServerRes = null;
		
		Debug.log("power_bound_before_initdeployment: " + this.power + " W");
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}
			
			double minPower = Double.MAX_VALUE;
			CloudInfo selectedCloud = null;
			
			for (CloudInfo cloudInfo : cloudInfoList) {
				if (cloudInfo.hasEnoughResources(node)) {
					PowerServerResourcesPair result = cloudInfo.findAssignableServersBound(node);
					if (result != null) {
						double tmpPower = result.power;
						if (tmpPower < minPower) {
							minPower = tmpPower;
							pwrServerRes = result;
							selectedCloud = cloudInfo;
						}
					}
				}
			}
			
			if (selectedCloud == null) {
//				throw new RuntimeException("Failed to assign LQN task to a machine. " + node);
				Debug.log("power_bound_init_deployment_failed: to assign LQN task to a machine. " + node);
				rc = -1;
				break;
			}
			
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (rc == 0) {
			Debug.log("power_bound_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return rc;
	}
}
