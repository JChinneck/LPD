package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Multimap;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerEfficiency;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.partioner.CloudInfo.ProcessingCapacity;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.partioner.CloudInfo.ServerResource;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Node;

public class BinPackHBFRAM {
	/* Key is the cloud; values are the nodes assigned to the specific cloud */
	Multimap<CloudInfo, Node> partitions;
	
	/* New instances of CloudInfo are created to allocate resources during bin packing.
	 * Mapping is created between CloudInfo instances of partitioning and CloudInfo
	 * instances of bin packing.
	 */
	HashMap<CloudInfo, CloudInfo> oldToNewCloudInfo;
	
	/* Modifiable information about clouds */
	List<CloudInfo> cloudInfoList;
	
	double power;
	
	/* Map LQN task to a list of ServerInfo */
	Map<Node, PowerServerResourcesPair> lqnTaskToServerMap;
	
	/* Time taken to bin-pack in milli-seconds */
	double binPackTime;
	
	public BinPackHBFRAM (ArrayList<Cloud> clouds, ArrayList<Server> servers, Multimap<CloudInfo, Node> partitions) {
		this.partitions = partitions;
		this.power = 0.0;
		this.cloudInfoList = new ArrayList<>();
		this.lqnTaskToServerMap =  new HashMap<>();
		
		for (Cloud cloud : clouds) {
			if (cloud != null) {
				CloudInfo cloudInfo = new CloudInfo(cloud);
//				cloudInfo.createServerInfoListProc(servers, ProcessingCapacity.DECREASING);
				cloudInfo.createServerInfoList(servers, PowerEfficiency.DECREASING);
				cloudInfoList.add(cloudInfo);
			}
		}
		
		createOldToNewCloudInfoMap(partitions);
	}
	
	public void createOldToNewCloudInfoMap(Multimap<CloudInfo, Node> partitions) {
		this.oldToNewCloudInfo = new HashMap<>();
		
		for (CloudInfo cloud : partitions.keySet()) {
			CloudInfo cloudForBinPack = findBinPackCloud(cloud);
			oldToNewCloudInfo.put(cloud, cloudForBinPack);
		}
	}
	
	class NodeSortDescendingProcReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in descending order -- highest CPU demand per user-request first */
			Double node1Proc = node1.getCpuDemandPerUserReq() * node1.getCallsPerUserReq();
			Double node2Proc = node2.getCpuDemandPerUserReq() * node2.getCallsPerUserReq();
			return node2Proc.compareTo(node1Proc);
		}
	}
	
	class NodeSortDescendingMemReq implements Comparator<Node> {
		@Override
		public int compare(Node node1, Node node2) {
			/* Sort Nodes in descending order -- highest memory tasks are placed first */
			Double node1Mem = node1.getMemory();
			Double node2Mem = node2.getMemory();
			return node2Mem.compareTo(node1Mem);
		}
	}
	
	public CloudInfo findBinPackCloud(CloudInfo inputCloud) {
		String inputName = inputCloud.getCloudRef().getCloudName();
		for (CloudInfo cloud : cloudInfoList) {
			String cloudName = cloud.getCloudRef().getCloudName();
			if (cloudName.equals(inputName)) {
				return cloud;
			}
		}
		return null;
	}
	
	public CloudInfo getBinPackCloud(CloudInfo cloud) {
		return oldToNewCloudInfo.get(cloud);
	}
	
	public void printBinPackAllocation(HashMap<Node, Node> oldNewMap) {
		for (CloudInfo cloud : partitions.keySet()) {
			Debug.log("\tCloud: " + cloud.getCloudRef().getCloudName());
			for (Node node : partitions.get(cloud)) {
				PowerServerResourcesPair pwrSerResPair = lqnTaskToServerMap.get(node);
				Debug.log("\t\tLQN Task: " + node);
				if (pwrSerResPair == null) {
					if (oldNewMap == null) {
						Debug.log("[ERROR] printBinPack: pwrSerResPair is null and oldNewMap is null.");
						continue;
					}
					Debug.log("\t\t\tNode was merged during partitioning.");
					pwrSerResPair = lqnTaskToServerMap.get(oldNewMap.get(node));
				}
				List<ServerResource> serverResources = pwrSerResPair.serverResources;
				for (ServerResource serverResource : serverResources) {
					ServerInfo info = serverResource.getServerInfo();
					double totalRAM = info.availableRam;
					double totalSsjOps = info.availableSsjOps;
					String serverInfo = "\t\t\t" + serverResource.getServerInfo().getName() + " - "
									+ "Reserved RAM: " + serverResource.getRAM() + " - Available RAM: " + totalRAM
									+ " - Reserved ssjOps: " + serverResource.getSsjOps() + " - Available ssjOps: " + totalSsjOps;
					Debug.log(serverInfo);
				}
			}
		}
	}
	
	/**
	 * Hybrid best-fit (two-phase) bin pack algorithm.
	 * 
	 * In the first phase, best fit decreasing height strategy is adopted. The first
	 * phase focuses on a single dimension while considering the other dimension to be
	 * infinite. LQN tasks are sorted in decreasing order of processing requirement.
	 * Processing requirement directly influences power consumption. Since servers are
	 * sorted in decreasing order of power efficiency, the LQN tasks with large
	 * processing requirement must be assigned to the most power efficient servers in
	 * order to reduce power consumption.
	 * 
	 * In the second phase, best fit decreasing algorithm is adopted, which assigns
	 * a LQN task to a server with the smallest processing/memory space left.
	 */
	public int binPack() {
		int result = 0;
		long startTime = System.nanoTime();
		
		for (CloudInfo cloud : partitions.keySet()) {
			List<Node> nodes = new ArrayList<>(partitions.get(cloud));
			
			/* Sort nodes depending upon decreasing processing requirement 
			 */
			Collections.sort(nodes, new NodeSortDescendingMemReq());
			
			CloudInfo cloudForBinPack = getBinPackCloud(cloud);
			for (Node node : nodes) {
				PowerServerResourcesPair resource = cloudForBinPack.findAssignableServersBinPackHBF(node);
				if (resource == null) {
					Debug.log("bin_pack_hbfram_failed: resource not found for " + node + " on " + cloudForBinPack.cloudRef.getCloudName());
					result = -1;
					break;
				}
				cloudForBinPack.assignTask(node, resource.serverResources);
				power += resource.power;
				lqnTaskToServerMap.put(node, resource);
			}
		}
		
		long endTime = System.nanoTime();
		this.binPackTime = (endTime - startTime)/1000000;
		return result;
	}

	public double getPower() {
		return power;
	}
	
	public double getBinPackTime() {
		return binPackTime;
	}
}
