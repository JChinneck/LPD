package ca.carleton.partioner;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.math3.stat.regression.SimpleRegression;

import ca.carleton.cloud.Cloud;
import ca.carleton.cloud.ServerInventory;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.ServerInfo;
import ca.carleton.server.PolyTrendLine;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Node;

public class CloudInfo implements Serializable {

	List<ServerInfo> serversAvailable;
	
	List<ServerInfo> serversUsed;
	
	static int serverCount;
	
	double totalAvailableSsjOpsCloud;
	
	double totalAvailableRamCloud;
	
	double totalAvailableCpusCloud;
	
	double totalUsedSsjOpsCloud;
	
	double totalUsedRamCloud;
	
	double totalUsedCpusCloud;
	
	Cloud cloudRef;
	
	public CloudInfo (Cloud cloud) {
		cloudRef = cloud;
		
		serverCount = 1;
		
		totalAvailableSsjOpsCloud = cloud.totalSsjOps;
		
		totalAvailableRamCloud = cloud.totalRam;
		
		totalAvailableCpusCloud = cloud.totalCpus;
		
		totalUsedSsjOpsCloud = 0.0;
		
		totalUsedRamCloud = 0.0;
		
		totalUsedCpusCloud = 0.0;
	}
	
	/**
	 * Returns true if the cloud can accommodate the LQN task
	 *         false if the cloud can't accommodate the LQN task
	 */
	public boolean hasEnoughResources(Node node) {
//		double ssjOpsRequired = (node.getCpuDemandPerUserReq() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		
		if ((totalAvailableSsjOpsCloud > ssjOpsRequired) && (totalAvailableRamCloud > ramRequired)) {
			return true;
		}
		
		return false;
	}
	
	/* Find a server to schedule a task */
	public PowerServerResourcesPair findAssignableServers(Node node) {
//		double ssjOpsRequired = (node.getCpuDemandPerUserReq() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		double power = 0;
		
		List<ServerResource> serverResources = null;
		
		/* Since servers are ordered in decreasing order of power efficiency, the first server with enough resources
		 * should be the power efficient server.
		 * 
		 * Task can be assigned to multiple servers to satisfy CPU/ssjOp requirements.
		 * If task is assigned to more than one server/machine, then total RAM requirement 
		 * must be satisfied on each machine.
		 */
		if ((totalAvailableSsjOpsCloud >= ssjOpsRequired) && (totalAvailableRamCloud >= ramRequired)) {
			serverResources = new ArrayList<>();
			for (ServerInfo server : serversAvailable) {
//				Debug.log("cloud: " + this.cloudRef.getCloudName() + " - server: "+  server);
				if (ramRequired <= server.availableRam) {
					if (ssjOpsRequired <= server.availableSsjOps) {
						/* If a task fits on a server, we have allocated enough resources to support the 
						 * task on the cloud. 
						 */
						power += server.getPowerAdd(ssjOpsRequired);
						serverResources.add(new ServerResource(server, ramRequired, ssjOpsRequired));
						break;
					} 
//					This allows a LQN task to be assigned to multiple servers. It is difficult to handle such
//					a scenario in the LQN verification stage. So, we avoid assigning a LQN to multiple servers.
//					else {
//						/* If a task doesn't fit on a server, we assign the entire server to it.
//						 * We keep on assigning servers to a task until we have satisfied its resource requirements.
//						 * By assigning multiple servers, we have duplicated the task on each server.
//						 */
//						ssjOpsRequired -= server.availableSsjOps;
//						power += server.getPower(server.availableSsjOps);
//						serverResources.add(new ServerResource(server, ramRequired, server.availableSsjOps));
//					}
				}
			}
		}
		
		/* Power can't be 0 or negative */
		if (power <= 0) {
			return null;
		}
		return new PowerServerResourcesPair(serverResources, power);
	}
	
	/* Assign the task to the specified host. */
	public PowerServerResourcesPair assignToHost(Node node, String hostName) {
//		double ssjOpsRequired = (node.getCpuDemandPerUserReq() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		double power = 0;
		
		List<ServerResource> serverResources = null;
		
//		Debug.log("task: " + node.getName() + " host: " + hostName);
		for (ServerInfo server : serversAvailable) {
//			Debug.log(server.getName());
			if (server.getName().matches(hostName)) {
//				Debug.log("task: " + node.getName() + " host: " + hostName);
				if ((ramRequired <= server.availableRam)
					&& (ssjOpsRequired <= server.availableSsjOps)
					&& (totalAvailableSsjOpsCloud >= ssjOpsRequired)
					&& (totalAvailableRamCloud >= ramRequired)
				) {
					power += server.getPowerAdd(ssjOpsRequired);
					serverResources = new ArrayList<>();
					serverResources.add(new ServerResource(server, ramRequired, ssjOpsRequired));
				} else {
					throw new IllegalArgumentException("server has insufficient resources: " + hostName);
				}
				break;
			}
		}
		
		/* Power can't be 0 or negative */
		if (power <= 0) {
			return null;
		}
		return new PowerServerResourcesPair(serverResources, power);
	}
	
	/* Find a server to schedule a task */
	public PowerServerResourcesPair findAssignableServersBound(Node node) {
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		double power = 0;
		double ssjOpsRequiredUnchanged = ssjOpsRequired;
		double ramRequiredUnchanged = ramRequired;
		
		List<ServerResource> serverResources = null;
		
		/* Since servers are ordered in decreasing order of power efficiency, the first server with enough resources
		 * should be the power efficient server.
		 * 
		 * Task can be assigned to multiple servers to satisfy CPU/ssjOp requirements.
		 * If task is assigned to more than one server/machine, then total RAM requirement 
		 * must be satisfied on each machine.
		 */
		if ((totalAvailableSsjOpsCloud >= ssjOpsRequired) && (totalAvailableRamCloud >= ramRequired)) {
			serverResources = new ArrayList<>();
			for (ServerInfo server : serversAvailable) {
//				Debug.log("cloud: " + this.cloudRef.getCloudName() + " - server: "+  server);
//				if (ramRequired <= server.availableRam) {
//					if ((server.usedSsjOps + ssjOpsRequired) <= (server.totalSsjOps * 0.9)) {
						if (ssjOpsRequired <= server.availableSsjOps) {
							/* If a task fits on a server, we have allocated enough resources to support the 
							 * task on the cloud. 
							 */
							power += server.getPowerAdd(ssjOpsRequired);
							double reserveRAM = (ssjOpsRequired/ssjOpsRequiredUnchanged)*ramRequiredUnchanged;
							ramRequired -= reserveRAM;
							serverResources.add(new ServerResource(server, reserveRAM, ssjOpsRequired));
							break;
						} 
	//					This allows a LQN task to be assigned to multiple servers. It is difficult to handle such
	//					a scenario in the LQN verification stage. So, we avoid assigning a LQN to multiple servers.
						else {
							/* If a task doesn't fit on a server, we assign the entire server to it.
							 * We keep on assigning servers to a task until we have satisfied its resource requirements.
							 * By assigning multiple servers, we have duplicated the task on each server.
							 */
							ssjOpsRequired -= server.availableSsjOps;
							power += server.getPowerAdd(server.availableSsjOps);
							double reserveRAM = server.availableRam;
							ramRequired -= reserveRAM;
							serverResources.add(new ServerResource(server, reserveRAM, server.availableSsjOps));
						}
//					}
//				}
			}
		}
		
		/* Power can't be 0 or negative */
		if (power <= 0) {
			return null;
		}
		return new PowerServerResourcesPair(serverResources, power);
	}
	
	public PowerServerResourcesPair findAssignableServersBinPackHBF(Node node) {
//		double ssjOpsRequired = (node.getCpuDemandPerUserReq() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		double power = 0;
		ServerInfo bestServer = null;
		
		List<ServerResource> serverResources = null;
		
		if ((totalAvailableSsjOpsCloud >= ssjOpsRequired) && (totalAvailableRamCloud >= ramRequired)) {
			serverResources = new ArrayList<>();
			double bestScore = -1.0;
			for (int i = serversAvailable.size() - 1; i >= 0; i--) {
				ServerInfo server = serversAvailable.get(i);
//			for (ServerInfo server : serversAvailable) {
				double serverAvailableSsjOps =  server.availableSsjOps;
				double serverAvailableRAM = server.availableRam;
				if ((ssjOpsRequired <= serverAvailableSsjOps) && (ramRequired <= serverAvailableRAM)) {
					double serverUsedSsjOps = server.usedSsjOps;
					double serverUsedRAM = server.usedRam;
					double procU = (serverUsedSsjOps + ssjOpsRequired) / (serverUsedSsjOps + serverAvailableSsjOps);
					double memU = (serverUsedRAM + ramRequired) / (serverUsedRAM + serverAvailableRAM);
					double score = calculateScoreHBF(procU, memU);
					if (score > bestScore) {
						bestScore = score;
						bestServer = server;
					}
				}
			}
		}
		
		if (bestServer != null) {
			power = bestServer.getPowerAdd(ssjOpsRequired);
			serverResources.add(new ServerResource(bestServer, ramRequired, ssjOpsRequired));
		}
		
		/* Power can't be 0 or negative */
		if (power <= 0) {
			return null;
		}
		return new PowerServerResourcesPair(serverResources, power);
	}
	
	/**
	 * Hybrid best fit score is the average of processing capacity and memory
	 * utilization of the server.
	 */
	public static double calculateScoreHBF(double procU, double memU) {
		return (procU + memU) / 2;
	}
	
	public PowerServerResourcesPair findAssignableServersBinPackRUAEE(Node node) {
//		double ssjOpsRequired = (node.getCpuDemandPerUserReq() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
//		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion) / Cloud.UtilNorm;
		double ssjOpsRequired = (node.getCpuDemandPerInvocation() * Cloud.CpuDemandToSsjOpsConversion);
		double ramRequired = node.getMemory();
		double power = 0;
		ServerInfo bestServer = null;
		
		List<ServerResource> serverResources = null;
		
		if ((totalAvailableSsjOpsCloud >= ssjOpsRequired) && (totalAvailableRamCloud >= ramRequired)) {
			serverResources = new ArrayList<>();
			double bestScore = -1.0;
			for (int i = serversAvailable.size() - 1; i >= 0; i--) {
				ServerInfo server = serversAvailable.get(i);
//			for (ServerInfo server : serversAvailable) {
				double serverAvailableSsjOps =  server.availableSsjOps;
				double serverAvailableRAM = server.availableRam;
				if ((ssjOpsRequired <= serverAvailableSsjOps) && (ramRequired <= serverAvailableRAM)) {
					double serverUsedSsjOps = server.usedSsjOps;
					double serverUsedRAM = server.usedRam;
					double procU = (serverUsedSsjOps + ssjOpsRequired) / (serverUsedSsjOps + serverAvailableSsjOps);
					double memU = (serverUsedRAM + ramRequired) / (serverUsedRAM + serverAvailableRAM);
					double score = calculateScoreRUAEE(procU, memU);
					if (score > bestScore) {
						bestScore = score;
						bestServer = server;
					}
				}
			}
		}
		
		if (bestServer != null) {
			power = bestServer.getPowerAdd(ssjOpsRequired);
			serverResources.add(new ServerResource(bestServer, ramRequired, ssjOpsRequired));
		}
		
		/* Power can't be 0 or negative */
		if (power <= 0) {
			return null;
		}
		return new PowerServerResourcesPair(serverResources, power);
	}
	
	/* Calculate score for assigning LQN tasks to machines/servers
	 * 
	 * score = (((1 - (d * 2 / sqrt(2))) * P_cpu) +  ((1 + (d * 2 / sqrt(2))) * P_mem)) / 2
	 * 
	 * dist = sqrt(2) * abs(P_cpu - P_mem) / 2
	 * 
	 * d = +dist if P_cpu > P_mem
	 * d = 0 if P_cpu = P_mem
	 * d = -dist if P_cpu < P_mem
	 * 
	 * P_cpu - CPU utilization
	 * P_mem - Memory utilization
	 */
	public static double calculateScoreRUAEE(double procU, double memU) {
		double sign = 0;
		
		if (procU < memU) {
			sign = -1;
		} else if (procU > memU) {
			sign = 1;
		}
		
		// d = sign * sqrt(2) * abs(P_cpu - P_mem) / 2
		double d = sign*Math.sqrt(2)*Math.abs(procU - memU)/2;
		
		// procComp = (((1 - (d * 2 / sqrt(2))) * P_cpu)
		double procComp = (1 - (d*2/Math.sqrt(2))) * procU;
		
		// memComp = ((1 + (d * 2 / sqrt(2))) * P_mem))
		double memComp = (1 + (d*2/Math.sqrt(2))) * memU;
		
		// score = (procComp + memComp) / 2
		//       = (((1 - (d * 2 / sqrt(2))) * P_cpu) +  ((1 + (d * 2 / sqrt(2))) * P_mem)) / 2
		return ((procComp + memComp) / 2);
	}
	
	public enum PowerEfficiency {
		INCREASING, DECREASING
	}
	
	/* Create a list of available servers in the cloud in increasing or decreasing order of power efficiency */
	public void createServerInfoList(ArrayList<Server> servers, PowerEfficiency pe) {
		serversAvailable = new ArrayList<>();
		serversUsed = new ArrayList<>();
		
		for (ServerInventory item : cloudRef.inventory) {
			boolean serversAdded = false;
			for (Server server : servers) {
				if (item.getServerName().equals(server.getServerName())) {
					for (int i = 0; i < item.getNumAvailable(); i++) {
						serversAvailable.add(new ServerInfo(server));
					}
					serversAdded = true;
					break;
				}
			}
			if (!serversAdded) {
				throw new IllegalArgumentException(item.getServerName() + " not found.");
			}
		}
		
		if (pe == PowerEfficiency.DECREASING) {
			Collections.sort(serversAvailable, new ServerComparatorDecreasingPowerEfficient());
		} else if (pe == PowerEfficiency.INCREASING) {
			Collections.sort(serversAvailable, new ServerComparatorIncreasingPowerEfficient());
		} else {
			throw new RuntimeException("Unknown power efficiency category: " + pe);
		}
	}
	
	/* This comparator will sort servers in decreasing order of power efficiency */
	class ServerComparatorDecreasingPowerEfficient implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double perfToPowerS1 = server1.serverRef.getOverallPerfToPower();
			Double perfToPowerS2 = server2.serverRef.getOverallPerfToPower();
			
			return perfToPowerS2.compareTo(perfToPowerS1);
		}
	}
	
	/* This comparator will sort servers in increasing order of power efficiency */
	class ServerComparatorIncreasingPowerEfficient implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double perfToPowerS1 = server1.serverRef.getOverallPerfToPower();
			Double perfToPowerS2 = server2.serverRef.getOverallPerfToPower();
			
			return perfToPowerS1.compareTo(perfToPowerS2);
		}
	}
	
	public enum ProcessingCapacity {
		INCREASING, DECREASING
	}
	
	/* Create a list of available servers in the cloud in increasing or decreasing order of processing capacity */
	public void createServerInfoListProc(ArrayList<Server> servers, ProcessingCapacity pc) {
		serversAvailable = new ArrayList<>();
		serversUsed = new ArrayList<>();
		
		for (ServerInventory item : cloudRef.inventory) {
			for (Server server : servers) {
				if (item.getServerName().equals(server.getServerName())) {
					for (int i = 0; i < item.getNumAvailable(); i++) {
						serversAvailable.add(new ServerInfo(server));
					}
					break;
				}
			}
		}
		
		if (pc == ProcessingCapacity.DECREASING) {
			Collections.sort(serversAvailable, new ServerComparatorDecreasingProcCap());
		} else if (pc == ProcessingCapacity.INCREASING) {
			Collections.sort(serversAvailable, new ServerComparatorIncreasingProcCap());
		} else {
			throw new RuntimeException("Unknown processing capacity category: " + pc);
		}
	}
	
	/* This comparator will sort servers in decreasing order of processing capacity */
	class ServerComparatorDecreasingProcCap implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double availableSsjOpsS1 = server1.availableSsjOps;
			Double availableSsjOpsS2 = server2.availableSsjOps;
			
			return availableSsjOpsS2.compareTo(availableSsjOpsS1);
		}
	}
	
	/* This comparator will sort servers in increasing order of processing capacity */
	class ServerComparatorIncreasingProcCap implements Comparator<ServerInfo> {
		@Override
		public int compare(ServerInfo server1, ServerInfo server2) {
			Double availableSsjOpsS1 = server1.availableSsjOps;
			Double availableSsjOpsS2 = server2.availableSsjOps;
			
			return availableSsjOpsS1.compareTo(availableSsjOpsS2);
		}
	}
	
	@Override
	public String toString() {
		return "CloudInfo{name: " + cloudRef.getCloudName() + "}";
	}
	
	public Cloud getCloudRef() {
		return cloudRef;
	}
	
	public double getDelay(CloudInfo cloudInfo) {
		return cloudRef.getDelay(cloudInfo.getCloudRef());
	}
	
	public void assignTask(Node node, List<ServerResource> serverResources) {
		for (ServerResource serverResource : serverResources) {
			ServerInfo serverInfo = serverResource.getServerInfo();
			double ram = serverResource.getRAM();
			double ssjOps = serverResource.getSsjOps();
			serverInfo.assignTask(node, ram, ssjOps);
		}
	}
	
	public void unAssignTask(Node node, List<ServerResource> serverResources) {
		for (ServerResource serverResource : serverResources) {
			ServerInfo serverInfo = serverResource.getServerInfo();
			double ram = serverResource.getRAM();
			double ssjOps = serverResource.getSsjOps();
			serverInfo.unAssignTask(node, ram, ssjOps);
		}
	}
	
	class PowerServerResourcesPair implements Serializable {
		List<ServerResource> serverResources;
		double power;
		
		public PowerServerResourcesPair(List<ServerResource> serverResources, double power) {
			this.serverResources = serverResources;
			this.power = power;
		}
	}
	
	class ServerResource implements Serializable {
		ServerInfo serverInfoRef;
		double reservedRAM;
		double reservedSsjOps;
		double reservedCPUs;
		
		public ServerResource(ServerInfo serverInfoRef, double reservedRAM, double reservedSsjOps) {
			this.serverInfoRef = serverInfoRef;
			this.reservedCPUs = 0;
			this.reservedRAM = reservedRAM;
			this.reservedSsjOps = reservedSsjOps;
		}

		public ServerInfo getServerInfo() {
			return serverInfoRef;
		}

		public double getRAM() {
			return reservedRAM;
		}

		public double getSsjOps() {
			return reservedSsjOps;
		}
	}
	
	/* This class contains operating information about each server in the cloud */
	class ServerInfo implements Serializable {
		Server serverRef;
		
		String name;
		
		double availableRam;
		double usedRam;
		
		double availableCpus;
		double usedCpus;
		
		/* Total CPU demand supported - numCores * coreSpeed * demandFactor */
		double availableSsjOps;
		double usedSsjOps;
		double totalSsjOps;
		
		List<Node> assignedTasks;
		
		public double getPowerAdd(double ssjOpsRequired) {
			if (ssjOpsRequired <= 0) {
				return 0;
			}
			
			if (Math.floor(ssjOpsRequired + usedSsjOps) > totalSsjOps) {
				throw new RuntimeException("Add Power: SsjOps exceed server's total SsjOps: total ssj_ops = " + totalSsjOps + " ssj_ops estimated = " + (ssjOpsRequired + usedSsjOps));
			}
			
			double currentPower = 0;
			if (Math.floor(usedSsjOps) > 0) {
				currentPower = getPowerCplex(usedSsjOps);
			}
			double newPower = getPowerCplex(usedSsjOps + ssjOpsRequired);
			
			if (newPower <= currentPower) {
				throw new RuntimeException("Add Power: New power consump. can't be lower or equal to current power consump.");
			}
			
			return (newPower - currentPower);
		}
		
		public double getPowerAddOld(double ssjOpsRequired) {
			if (ssjOpsRequired <= 0) {
				return 0;
			}
			
			if (Math.floor(ssjOpsRequired + usedSsjOps) > totalSsjOps) {
				throw new RuntimeException("Add Power: SsjOps exceed server's total SsjOps: total ssj_ops = " + totalSsjOps + " ssj_ops estimated = " + (ssjOpsRequired + usedSsjOps));
			}
			
			PolyTrendLine loadToPowerModel = serverRef.getLoadtoPowerRegressionModel();
			
			double currentPower = 0;
			if (Math.floor(usedSsjOps) > 0) {
				currentPower = loadToPowerModel.predict(usedSsjOps);
			}
			double newPower = loadToPowerModel.predict(usedSsjOps + ssjOpsRequired);
			
			if (newPower <= currentPower) {
				throw new RuntimeException("Add Power: New power consump. can't be lower or equal to current power consump.");
			}
			
			return (newPower - currentPower);
		}
		
		public double getPowerOld(double ssjOpsUsed) {
			if (ssjOpsUsed <= 0) {
				return 0;
			}
			
			if (Math.floor(ssjOpsUsed) > Math.floor(totalSsjOps)) {
				throw new RuntimeException("input SsjOps exceed server's total SsjOps; ssj_ops used = " + ssjOpsUsed + " ssj_ops total = " + totalSsjOps);
			}
			
			PolyTrendLine loadToPowerModel = serverRef.getLoadtoPowerRegressionModel();
			
			double power = loadToPowerModel.predict(ssjOpsUsed);
			
			return power;
		}
		
		public double getPower(double ssjOpsUsed) {
			return getPowerCplex(ssjOpsUsed);
		}
		
		public double getPowerCplex(double ssjOpsUsed) {
			if (ssjOpsUsed <= 0) {
				return 0;
			}
			
			if (Math.floor(ssjOpsUsed) > Math.floor(totalSsjOps)) {
				throw new RuntimeException("input SsjOps exceed server's total SsjOps; ssj_ops used = " + ssjOpsUsed + " ssj_ops total = " + totalSsjOps);
			}
			
			double power = (ssjOpsUsed * serverRef.h_s) + serverRef.h_o;
			
			return power;
		}
		
		public double getPowerRemoveOld(double ssjOpsRemoved) {
			if (ssjOpsRemoved <= 0) {
				return 0;
			}
			
			if ((usedSsjOps - ssjOpsRemoved) < -0.0001) {
				throw new RuntimeException("Remove Power: SsjOps can't be less than 0 for a server." + (usedSsjOps - ssjOpsRemoved));
			}
			
			PolyTrendLine loadToPowerModel = serverRef.getLoadtoPowerRegressionModel();
			
			double currentPower = loadToPowerModel.predict(usedSsjOps);
			double newPower = 0;
			if (Math.floor(usedSsjOps - ssjOpsRemoved) > 0) {
				newPower = loadToPowerModel.predict(usedSsjOps - ssjOpsRemoved);
			}
			
			if (newPower >= currentPower) {
				throw new RuntimeException("Remove Power: New power consump. can't be higher or equal to current power consump.");
			}
			
			return (currentPower - newPower);
		}
		
		public double getPowerRemove(double ssjOpsRemoved) {
			if (ssjOpsRemoved <= 0) {
				return 0;
			}
			
			if ((usedSsjOps - ssjOpsRemoved) < -0.0001) {
				throw new RuntimeException("Remove Power: SsjOps can't be less than 0 for a server." + (usedSsjOps - ssjOpsRemoved));
			}
			
			double currentPower = getPowerCplex(usedSsjOps);
			double newPower = 0;
			if (Math.floor(usedSsjOps - ssjOpsRemoved) > 0) {
				newPower = getPowerCplex(usedSsjOps - ssjOpsRemoved);
			}
			
			if (newPower >= currentPower) {
				throw new RuntimeException("Remove Power: New power consump. can't be higher or equal to current power consump.");
			}
			
			return (currentPower - newPower);
		}
		
		public String getName() {
			return name;
		}
		
		public ServerInfo(Server server) {
			this.serverRef = server;
			this.name = server.getServerName() + "_" + serverCount++;
			
			this.availableRam = serverRef.getRam();
			this.usedRam = 0.0;
			
			totalAvailableRamCloud += this.availableRam;
			
			this.usedSsjOps = 0.0;
			this.totalSsjOps = server.getTotalSsjOps();
			this.availableSsjOps = this.totalSsjOps * Cloud.UtilNorm;
			
			totalAvailableSsjOpsCloud += this.availableSsjOps;
			
			this.availableCpus = server.getHardwareCores();
			this.usedCpus = 0.0;
			
			totalAvailableCpusCloud += this.availableCpus;
			
			this.assignedTasks = new ArrayList<>();
		}
		
		public void assignTask(Node node, double ramRequired, double ssjOpsRequired) {
			this.availableRam -= ramRequired;
			this.usedRam += ramRequired;
			totalAvailableRamCloud -= ramRequired;
			totalUsedRamCloud += ramRequired;
			
			this.availableSsjOps -= ssjOpsRequired;
			this.usedSsjOps += ssjOpsRequired;
			totalAvailableSsjOpsCloud -= ssjOpsRequired;
			totalUsedSsjOpsCloud += ssjOpsRequired;
			
			assignedTasks.add(node);
			
			if ((availableRam == 0) || (availableSsjOps == 0)) {
				serversAvailable.remove(this);
				serversUsed.add(this);
			}
		}
		
		public void unAssignTask(Node node, double ramUsed, double ssjOpsUsed) {
			this.availableRam += ramUsed;
			this.usedRam -= ramUsed;
			totalAvailableRamCloud += ramUsed;
			totalUsedRamCloud -= ramUsed;
			
			this.availableSsjOps += ssjOpsUsed;
			this.usedSsjOps -= ssjOpsUsed;
			totalAvailableSsjOpsCloud += ssjOpsUsed;
			totalUsedSsjOpsCloud -= ssjOpsUsed;
			
			assignedTasks.remove(node);
			
			if ((availableRam != 0) && (availableSsjOps != 0)) {
				serversAvailable.add(this);
				serversUsed.remove(this);
			}
		}
	}
}
