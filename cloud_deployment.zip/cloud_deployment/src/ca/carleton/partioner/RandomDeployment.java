package ca.carleton.partioner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.partioner.CloudInfo.PowerServerResourcesPair;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class RandomDeployment extends Deployment {
	public RandomDeployment(ArrayList<Cloud> clouds, ArrayList<Server> servers, User user, DirectedGraph<Node, Arc> graph, Node root, long windowSize, double executionDelay) {
		super(clouds, servers, user, graph, root, windowSize, executionDelay);
	}

	@Override
	public int initialDeployment() {
		int rc = 0;
		long startTime = System.nanoTime();
		
		List<Node> nodesList = new ArrayList<>(graph.getVertices());
		
		/* Randomly shuffle the order of cloud list and LQN task list. */
		Collections.shuffle(nodesList);
//		Collections.shuffle(cloudInfoList);
		Random rand = new Random();
		int numClouds = cloudInfoList.size();
		int numNodes = nodesList.size();
		
//		Debug.log("InitDepl - LQN tasks: " + nodesList);
//		Debug.log("InitDepl - Cloud list: " + cloudInfoList);
		
		PowerServerResourcesPair pwrServerRes = null;
		
		Debug.log("power_before_initdeployment: " + this.power + " W");
		
		for (Node node : nodesList) {
			if (root == node) {
				continue;
			}
			
			CloudInfo selectedCloud = null;
			
			while (true) {
				CloudInfo cloudInfo = cloudInfoList.get(rand.nextInt(numClouds));
				if (cloudInfo.hasEnoughResources(node)) {
					PowerServerResourcesPair result = cloudInfo.findAssignableServers(node);
					if (result != null) {
						pwrServerRes = result;
						selectedCloud = cloudInfo;
						break;
					}
				}
			}
			
			if (selectedCloud == null) {
//				throw new RuntimeException("Failed to assign LQN task to a machine. " + node);
				Debug.log("random_init_deployment_failed: to assign LQN task to a machine. " + node);
				rc = -1;
				break;
			}
			
			addNode(selectedCloud, pwrServerRes, node);
		}
		
		if (rc == 0) {
			Debug.log("power_after_initdeployment: " + this.power + " W");
		}
		
		long endTime = System.nanoTime();
		this.initDeplTime = (endTime - startTime)/1000000;
		return rc;
	}
	
	/* Returns a number - min <= number <= max. */
	static int getRandomNumber(int min, int max)
	{
	   int range = (max - min) + 1;     
	   return (int)(Math.random() * range) + min;
	}
}
