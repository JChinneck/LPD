package ca.carleton.debug;

public class Debug {
	public static boolean debug = true;
	public static String tag = "";
	
	public static void log(String message) {
		if (debug) {
			System.out.println(tag + message);
		}
	}
	
	public static void logNoNewLine(String message) {
		if (debug) {
			System.out.print(tag + message);
		}
	}
	
	public static void setTag(String label) {
		tag = "<" + label + "> ";
	}
}
