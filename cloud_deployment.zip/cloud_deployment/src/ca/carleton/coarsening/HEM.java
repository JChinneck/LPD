package ca.carleton.coarsening;

import com.google.common.collect.Multimap;

import ca.carleton.testcases.savi.Node;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import ca.carleton.cloud.Cloud;
import ca.carleton.debug.Debug;
import ca.carleton.lqn.TupleGraphRoot;
import ca.carleton.partioner.CloudInfo;
import ca.carleton.testcases.savi.Arc;

public class HEM {
	public DirectedGraph<Node, Arc> coarsenedGraph;
	
	/* Key is the new merged node and value points to the original two nodes */
	public HashMap<Node, MergeInfo> mergeRecord;
	
	/* Key is old node and value is the new merged node */
	public HashMap<Node, Node> oldNewMap;
	
	/* Key is node in originalGraph and value is node in coarsenedGraph */
//	public HashMap<Node, Node> duplicateMap;
	
	/* Average edge weight in the original graph */
	public double averageEdgeWeight;
	
	/* Multiplier factor (x averageEdgeWeight) to identify edges to contract */
	public long factor;
	
	/* Minimum vertex count (threshold) needed to perform coarsening */
	public long minVertexCount;
	
	/* Time taken to coarsen (milliseconds). */
	double coarsenTime;
	
	/* Time taken to uncoarsen (milliseconds). */
	double uncoarsenTime;
	
	public HEM (long factor, long minVertexCount) {
		this.coarsenedGraph = null;
		this.mergeRecord = new HashMap<>();
		this.oldNewMap = new HashMap<>();
//		this.duplicateMap = new HashMap<>();
		this.averageEdgeWeight = 0.0;
		this.factor = factor;
		this.minVertexCount = minVertexCount;
	}
	
	public HashMap<Node, Node> getOldNewMap() {
		return oldNewMap;
	}
	
	/* Replace merged nodes with the original graph nodes in the final
	 * deployment partition.
	 */
	public void unCoarsen(Multimap<CloudInfo, Node> partitions, List<CloudInfo> cloudInfoList) {
		long startTime = System.nanoTime();
		
		ArrayList<Node> removeList = new ArrayList<Node>();
		ArrayList<Node> addList = new ArrayList<Node>();
		for (CloudInfo cloud : cloudInfoList) {
			removeList.clear();
			addList.clear();
			
			for (Node node : partitions.get(cloud)) {
				if (mergeRecord.containsKey(node)) {
					MergeInfo info = mergeRecord.get(node);
					
					/* Remove merged node from the partition */
					removeList.add(node);
//					partitions.remove(cloud, node);
//					Debug.log("Uncoarsening: replacing merged node - " + node);
					
					/* Replace merged node with original graph nodes */
					replaceWithOriginalNode(partitions, info.node1, addList);
					replaceWithOriginalNode(partitions, info.node2, addList);
				}
			}
			
			for (Node addNode : addList) {
				partitions.put(cloud, addNode);
			}
			for (Node removeNode : removeList) {
				partitions.remove(cloud, removeNode);
			}
		}
		
		long endTime = System.nanoTime();
		this.uncoarsenTime = (endTime - startTime)/1000000;
	}
	
	/* If there are multiple levels of merged nodes, then recursively try to traverse through
	 * all the merged nodes to find the original graph node.
	 */
	private void replaceWithOriginalNode(Multimap<CloudInfo, Node> partitions, Node node, ArrayList<Node> addList) {
		if (mergeRecord.containsKey(node)) {
//			Debug.log("Uncoarsening: replacing merged node - " + node);
			
			MergeInfo info = mergeRecord.get(node);
			replaceWithOriginalNode(partitions, info.node1, addList);
			replaceWithOriginalNode(partitions, info.node2, addList);
		} else {
			/* If no merge info exists, then we have found an original node.
			 * Add original node to the partitions. 
			 */
			addList.add(node);
//			partitions.put(cloud, node);
//			Debug.log("Uncoarsening: found original node - " + node);
		}
	}
	
	private void updateOldNewMap(Node node, Node newNode) {
		if (mergeRecord.containsKey(node)) {
			MergeInfo info = mergeRecord.get(node);
			updateOldNewMap(info.node1, newNode);
			updateOldNewMap(info.node2, newNode);
//			Debug.log("updateOldNewMap -- Node1: " + info.node1 + " - Node2: " + info.node2);
		} else {
			oldNewMap.put(node, newNode);
		}
	}
	
	/* Generate a new graph where edges (> averageEdgeWeight * factor) have been contracted.
	 * The corresponding nodes connected the contracted edges have been merged.
	 */
	public TupleGraphRoot coarsen(TupleGraphRoot graphRoot) {
		long startTime = System.nanoTime();

		DirectedGraph<Node, Arc> originalGraph = graphRoot.getGraph();
		Node root = graphRoot.getRoot();
		int numNodes = originalGraph.getVertexCount();
		
		/* If the graph size is not large enough, no need to coarsen. Null is returned. */
		if (numNodes < this.minVertexCount) {
			Debug.log("Coarsening: graph size is not large enough - null is returned");
			return null;
		} else {
			this.coarsenedGraph = new DirectedSparseMultigraph<>();
		}
		
		Collection<Arc> arcs = originalGraph.getEdges();
		ArrayList<Arc> arcsList = new ArrayList<>(arcs);
		
		Collections.sort(arcsList, new ArcSortDescendingWeights());
		
		for (Arc arc : arcsList) {
			this.averageEdgeWeight += arc.getCallsPerUserReq();
		}
		this.averageEdgeWeight /= arcsList.size();
		
		double edgeThreshHold = this.averageEdgeWeight * this.factor;
		
//		Debug.log("Coarsening: Arc List=" + arcsList);
		Debug.log("Coarsening: Edge threshold=" + edgeThreshHold);
		
//		Iterator<Arc> iterator = arcsList.iterator();
		
		for (Arc arc : arcsList) {
//			Arc arc = iterator.next();
			Node dest = originalGraph.getDest(arc);
			Node source = originalGraph.getSource(arc);
			Node destMod = dest;
			Node sourceMod = source;
			
//			Node destMod = null;
//			Node sourceMod = null;
//			if (duplicateMap.containsKey(dest)) {
//				destMod = duplicateMap.get(dest);
//			} else {
//				destMod = new Node(dest);
//				duplicateMap.put(dest, destMod);
//			}
//			dest = destMod;
//			
//			if (duplicateMap.containsKey(source)) {
//				sourceMod = duplicateMap.get(source);
//			} else {
//				sourceMod = new Node(source);
//				duplicateMap.put(source, sourceMod);
//			}
//			source = sourceMod;
			
			if (oldNewMap.containsKey(dest)) {
				/* If dest is already merged, replace dest with the new merged node */
				destMod = oldNewMap.get(dest);
//				Debug.log("Coarsening: dest already merged - " + dest);
			}
			
			if (oldNewMap.containsKey(source)) {
				/* If source is already merged, replace source with the new merged node */
				sourceMod = oldNewMap.get(source);
//				Debug.log("Coarsening: source already merged - " + source);
			}
			
			if (source != dest) {
				/* Only merge nodes if number of nodes in coarsened graph is greater than 
				 * minimum allowed nodes, and edge weight (calls per user request) is greater
				 * than the specified edge weight threshold.
				 *
				 * Remove (source == sourceMod) && (dest == destMod) to allow merging of merged nodes.
				 * This will prevent to print the coarsened graph due to circular dependencies.
				 * 
				 * Avoid merging reference task (root) during coarsening.
				 */
//				double mergedCpuDemandPerUserReq = destMod.getCpuDemandPerUserReq() + sourceMod.getCpuDemandPerUserReq();
				double mergedCpuDemandPerUserReq = destMod.getCpuDemandPerInvocation() + sourceMod.getCpuDemandPerInvocation();
				double mergedMemory = destMod.getMemory() + sourceMod.getMemory();
				/* 1 CPU is approx. 50000 ssj ops */
				double mergedCpusApprox = (mergedCpuDemandPerUserReq * Cloud.CpuDemandToSsjOpsConversion)/50000;
				if ((numNodes > this.minVertexCount) 
						&& (arc.getCallsPerUserReq() > edgeThreshHold)
						&& (mergedMemory <= 4)
						&& (mergedCpusApprox <= 4)
						&& (source == sourceMod)
						&& (dest == destMod)
						&& (dest != root) 
						&& (source != root)
				) {
					/* Contract the edge, and replace source and dest with a new merged node */
					Node newNode = new Node(destMod.getCpuDemandPerInvocation() + sourceMod.getCpuDemandPerInvocation(),
											mergedMemory,
											mergedCpuDemandPerUserReq,
											destMod.getCallsPerUserReq() + sourceMod.getCallsPerUserReq(),
											destMod.getName() + "_" + sourceMod.getName());
					
					coarsenedGraph.addVertex(newNode);
					mergeRecord.put(newNode, new MergeInfo(destMod, sourceMod));
					
					if (coarsenedGraph.containsVertex(sourceMod)) {
						coarsenedGraph.removeVertex(sourceMod);
					}
					
					if (coarsenedGraph.containsVertex(destMod)) {
						coarsenedGraph.removeVertex(destMod);
					}
					
//					Debug.log("Coarsening: Merged nodes (" + arc + ") - " + destMod + ", " + sourceMod + " into " + newNode);
					
					updateOldNewMap(newNode, newNode);
					/* Reduce node count after each merge */
					numNodes--;
				} else {
					/* Just add source and dest to the coarsenedGraph along with the edge between them */
					if (!coarsenedGraph.containsVertex(destMod)) {
						coarsenedGraph.addVertex(destMod);
//						Debug.log("Coarsening: Add same dest - " + destMod);
					}
					
					if (!coarsenedGraph.containsVertex(sourceMod)) {
						coarsenedGraph.addVertex(sourceMod);
//						Debug.log("Coarsening: Add same source - " + sourceMod);
					}
					
					if (destMod != sourceMod) {
						Arc existingArc = coarsenedGraph.findEdge(sourceMod, destMod);
						if (existingArc == null) {
							coarsenedGraph.addEdge(new Arc(arc), sourceMod, destMod);
//							Debug.log("Coarsening: Add same edge between " + destMod + " and " + sourceMod + " - edge " + arc);
						} else {
							/* If there is an existing edge between source and dest in the coarsened graph, then
							 * update the edge weight of the existing arc.
							 */
							existingArc.setNumCalls(existingArc.getNumCalls() + arc.getNumCalls());
							existingArc.setCallsPerUserReq(existingArc.getCallsPerUserReq() + arc.getCallsPerUserReq());
//							Debug.log("Coarsening: Update existing edge between " + destMod + " and " + sourceMod + " - edge " + existingArc);
						}
					}
				}
			}
			
//			iterator.remove();
		}
		
		long endTime = System.nanoTime();
		this.coarsenTime = (endTime - startTime)/1000000;
		
//		return new TupleGraphRoot(coarsenedGraph, duplicateMap.get(root));
		return new TupleGraphRoot(coarsenedGraph, root);
	}
	
	public double getCoarsenTime() {
		return coarsenTime;
	}
	
	public double getUncoarsenTime() {
		return uncoarsenTime;
	}
	
	/* Comparator to sort Arcs in descending order */
	class ArcSortDescendingWeights implements Comparator<Arc> {
		@Override
		public int compare(Arc arc1, Arc arc2) {
			/* Sort Arcs in descending order -- process heavy edges first */
			Double arc1Weight = arc1.getCallsPerUserReq();
			Double arc2Weight = arc2.getCallsPerUserReq();
			return arc2Weight.compareTo(arc1Weight);
		}
	}
	
	static class MergeInfo {
		Node node1;
		Node node2;

		public MergeInfo(Node node1, Node node2) {
			this.node1 = node1;
			this.node2 = node2;
		}
	}
}
