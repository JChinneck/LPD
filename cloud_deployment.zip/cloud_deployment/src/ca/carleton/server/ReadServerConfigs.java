package ca.carleton.server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import ca.carleton.debug.Debug;

/**
 * Reads JSON files in server_configs/ directory.
 * 
 * Extracts server information from JSON files and generates a Server object
 * for each server configuration.
 * 
 * Only readServerConfigs is a public method. It returns a list of Server
 * objects. Each Server object corresponds to a configuration stored in a JSON file.
 * 
 * Add more JSON files under server/configs directory to add more server configurations.
 * 
 */

public class ReadServerConfigs {
	public static String server_config_dir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/git/babneet_thesis/cloud_deployment/server_configs/";
	
	public static void main(String[] args) {
		readServerConfigs();
	}
	
	private static ArrayList<String> getServerConfigs() {
		File folder = new File(server_config_dir);
		File[] server_configs = folder.listFiles();
		ArrayList<String> paths = new ArrayList<>();
		
		for (int i = 0; i < server_configs.length; i++) {
			if (server_configs[i].isFile()) {
				String path = server_configs[i].getPath();
				
				//Debug.log("File " + path);
				
				paths.add(path);
			} 
		}
		
		return paths;
	}
	
	private static ArrayList<Double> convertJSONArrayToListDouble(JSONArray jsonArray, String array_name) {
		ArrayList<Double> list = new ArrayList<>();
		int size = jsonArray.size();
		for (int i = 0; i < size; i++) {
			Double value = Double.parseDouble(jsonArray.get(i).toString());
			list.add(value);
			//Debug.log(array_name + ": " + value);
		}
		return list;
	}
	
	private static ArrayList<Long> convertJSONArrayToListLong(JSONArray jsonArray, String array_name) {
		ArrayList<Long> list = new ArrayList<>();
		int size = jsonArray.size();
		for (int i = 0; i < size; i++) {
			Long value = Long.parseLong(jsonArray.get(i).toString());
			list.add(value);
			//Debug.log(array_name + ": " + value);
		}
		return list;
	}
	
	private static Server generateServerInstance(JSONObject jsonObject) {
		Server server = new Server();
		
		String server_name = (String)jsonObject.get("server_name");
		server.setServerName(server_name);
		//Debug.log("server_name: " + server_name);
		
		String server_alias = (String)jsonObject.get("server_alias");
		server.setServerAlias(server_alias);
		//Debug.log("server_alias: " + server_alias);
		
		String processor_name = (String)jsonObject.get("processor_name");
		server.setProcessorName(processor_name);
		//Debug.log("processor_name: " + processor_name);
		
		long num_chips = (long)jsonObject.get("chips");
		server.setNumChips(num_chips);
		//Debug.log("chips: " + num_chips);
		
		long hardware_cores = (long)jsonObject.get("hardware_cores");
		server.setHardwareCores(hardware_cores);
		//Debug.log("hardware_cores: " + hardware_cores);
		
		long hardware_threads = (long)jsonObject.get("hardware_threads");
		server.setHardwareThreads(hardware_threads);
		//Debug.log("hardware_threads: " + hardware_threads);
		
		double cpu_speed = (double)jsonObject.get("cpu_speed");
		server.setCpuSpeed(cpu_speed);
		//Debug.log("cpu_speed: " + cpu_speed);
		
		double ram = (double)jsonObject.get("ram");
		server.setRam(ram);
		//Debug.log("ram: " + ram);
		
		double network_speed = (double)jsonObject.get("network_speed");
		server.setNetwork_speed(network_speed);
		//Debug.log("network_speed: " + network_speed);

		long cpu_arch = (long)jsonObject.get("cpu_arch");
		server.setCpuArch(cpu_arch);
		//Debug.log("cpu_arch: " + cpu_arch);
		
		double overallPerfToPower = (double)jsonObject.get("overall_perf_to_power");
		server.setOverallPerfToPower(overallPerfToPower);
		//Debug.log("overall_perf_to_power: " + overallPerfToPower);
		
		JSONArray actual_load = (JSONArray)jsonObject.get("actual_load");
		server.setActualLoad(convertJSONArrayToListDouble(actual_load, "actual_load"));
		
		JSONArray ssj_ops = (JSONArray)jsonObject.get("ssj_ops");
		server.setSsjOps(convertJSONArrayToListLong(ssj_ops, "ssj_ops"));
		
		JSONArray average_active_power = (JSONArray)jsonObject.get("average_active_power");
		server.setAverage_active_power(convertJSONArrayToListDouble(average_active_power, "average_active_power"));
		
		JSONArray perf_to_power = (JSONArray)jsonObject.get("perf_to_power");
		server.setPerfToPower(convertJSONArrayToListLong(perf_to_power, "perf_to_power"));
		
		JSONArray min_ambient_temp = (JSONArray)jsonObject.get("min_ambient_temp");
		server.setMinAmbientTemp(convertJSONArrayToListDouble(min_ambient_temp, "min_ambient_temp"));
		
		return server;
	}
			
	public static ArrayList<Server> readServerConfigs() {
		ArrayList<String> config_paths = getServerConfigs();
		JSONParser parser = new JSONParser();
		ArrayList<Server> serverList = new ArrayList<>();
		
		try {
			for (String config_path : config_paths) {
				Object obj = parser.parse(new FileReader(config_path));

				JSONObject jsonObject = (JSONObject)obj;
				
				if (jsonObject != null) {
					//Debug.log(jsonObject.toString());
					Server server = generateServerInstance(jsonObject);
					serverList.add(server);
				} else {
					throw new NullPointerException("JSON Object is NULL");
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return serverList;
	}
}
