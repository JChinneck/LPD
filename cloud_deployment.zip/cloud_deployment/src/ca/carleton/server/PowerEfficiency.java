package ca.carleton.server;

/**
 * This enum is used to characterize server's power efficiency.
 * Higher level represents higher power efficiency.
 */
public enum PowerEfficiency {
	LEVEL_1,
	LEVEL_2,
	LEVEL_3,
	LEVEL_4,
	LEVEL_5
}
