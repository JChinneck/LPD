package ca.carleton.server;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;

import ca.carleton.debug.Debug;

public class Server implements Serializable {
	
	private String serverName;
	
	private String serverAlias;
	
	private String processorName;
	
	private long numChips;
	
	private long hardwareCores;
	
	private long hardwareThreads;
	
	/* Units - MHz */
	private double cpuSpeed;
	
	/* Units - GB */
	private double ram;
	
	/* Units - Mbit */
	private double networkSpeed;

	/* 31-bit / 32-bit / 64-bit */
	private long cpuArch;
	
	public double overallPerfToPower;
	
	public double getOverallPerfToPower() {
		return overallPerfToPower;
	}

	public void setOverallPerfToPower(double overallPerfToPower) {
		this.overallPerfToPower = overallPerfToPower;
	}

	private final static long[] targetLoad = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
	
	private ArrayList<Double> actualLoad;
	
	private ArrayList<Long> ssjOps;
	
	private ArrayList<Double> averageActivePower;
		
	/* Performance to Power Ratio */
	private ArrayList<Long> perfToPower;
	
	/* Minimum Ambient Temperature; Units - Degrees C */
	private ArrayList<Double> minAmbientTemp;
	
	public PolyTrendLine ssjOpToPowerRegression = null;
	
	public double h_M;
	public double h_s;
	public double h_o;
	public double h_ptot;
	public double h_mtot;
	public double h_sf;
	public String hostData;
	
	public void setSolverData(double speedFactor) {
		h_o = averageActivePower.get(0);
		h_ptot = ssjOps.get(ssjOps.size() - 1);
		h_M = h_ptot + 1000;
		h_mtot = ram;
		h_s = ssjOpToPowerRegression.getLinearCoef();
		h_sf = speedFactor;
		
		DecimalFormat dfHS = new DecimalFormat("#.########");
		DecimalFormat dfHSF = new DecimalFormat("#.###");
		hostData = h_M + ", "
					+ dfHS.format(h_s) + ", "
					+ h_o + ", "
					+ h_ptot + ", "
					+ h_mtot + ", "
					+ dfHSF.format(h_sf) + ">";
	}
	
	public void generateLoadtoPowerRegressionModel() {
		/* Model ssj_ops (x-axis) and power (y-axis) relation as a polynomial (degree = 4) */
		ssjOpToPowerRegression = new PolyTrendLine(1);
		
		int ssjArraySize = ssjOps.size();
		int powerArraySize = averageActivePower.size();
		
		/* ssjOps and averageActivePower array size is always 11. */
		if ((ssjArraySize < 2) || (powerArraySize < 2)) {
			throw new IllegalArgumentException("load/power arrays are too small");
		} else if (ssjArraySize != powerArraySize) {
			throw new IllegalArgumentException("load/power array size not same");
		} else {
			double[] ssjops = new double[ssjArraySize];
			double[] power = new double[ssjArraySize];
			for (int i = 0; i < ssjArraySize; i++) {
				/* In the regression model, x-axis values are ssjOps and y-axis values
				 * are averageActivePower.
				 */
				ssjops[i] = ssjOps.get(i).doubleValue();
				power[i] = averageActivePower.get(i).doubleValue();
			}
			ssjOpToPowerRegression.setValues(power, ssjops);
		}
		
//		Debug.log(serverName);
		for (Long ssjOp : ssjOps) {
//			Debug.log("ssjops: " + ssjOp + " power: " + ssjOpToPowerRegression.predict(ssjOp));
		}
	}
	
	private double maxPerfToPower;
	private double maxPerfToPowerUtil;
	
	public void evaluateMaxPerfToPowerProperties() {
		double max = Double.MIN_VALUE;
		int arrSize = perfToPower.size();
		for(int i = 0; i < arrSize; i++) {
			double val = perfToPower.get(i);
			if (val > max) {
				maxPerfToPower = val;
				maxPerfToPowerUtil = i*10;
			}
		}
	}
	
	public double getMaxPerfToPower() {
		return maxPerfToPower;
	}
	
	public double getMaxPerfToPowerUtil() {
		return maxPerfToPowerUtil;
	}
	
	public PolyTrendLine getLoadtoPowerRegressionModel() {
		if (ssjOpToPowerRegression != null) {
			return ssjOpToPowerRegression;
		}
		return null;
	}
	
	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getProcessorName() {
		return processorName;
	}

	public void setProcessorName(String processorName) {
		this.processorName = processorName;
	}

	public long getNumChips() {
		return numChips;
	}

	public void setNumChips(long numChips) {
		this.numChips = numChips;
	}

	public long getHardwareCores() {
		return hardwareCores;
	}

	public void setHardwareCores(long hardwareCores) {
		this.hardwareCores = hardwareCores;
	}

	public long getHardwareThreads() {
		return hardwareThreads;
	}

	public void setHardwareThreads(long hardwareThreads) {
		this.hardwareThreads = hardwareThreads;
	}

	public double getCpuSpeed() {
		return cpuSpeed;
	}

	public void setCpuSpeed(double cpuSpeed) {
		this.cpuSpeed = cpuSpeed;
	}

	public double getRam() {
		return ram;
	}

	public void setRam(double ram) {
		this.ram = ram;
	}

	public double getNetwork_speed() {
		return networkSpeed;
	}

	public void setNetwork_speed(double network_speed) {
		this.networkSpeed = network_speed;
	}

	public long getCpuArch() {
		return cpuArch;
	}

	public void setCpuArch(long cpuArch) {
		this.cpuArch = cpuArch;
	}

	public ArrayList<Double> getActualLoad() {
		return actualLoad;
	}

	public void setActualLoad(ArrayList<Double> actualLoad) {
		this.actualLoad = actualLoad;
	}

	public ArrayList<Long> getSsjOps() {
		return ssjOps;
	}

	public void setSsjOps(ArrayList<Long> ssjOps) {
		this.ssjOps = ssjOps;
	}

	public long getTotalSsjOps() {
		return ssjOps.get(ssjOps.size() - 1);
	}
	
	public ArrayList<Double> getAverageActivePower() {
		return averageActivePower;
	}

	public void setAverage_active_power(ArrayList<Double> averageActivePpower) {
		this.averageActivePower = averageActivePpower;
	}

	public ArrayList<Long> getPerfToPower() {
		return perfToPower;
	}

	public void setPerfToPower(ArrayList<Long> perfToPower) {
		this.perfToPower = perfToPower;
	}

	public ArrayList<Double> getMinAmbientTemp() {
		return minAmbientTemp;
	}

	public void setMinAmbientTemp(ArrayList<Double> minAmbientTemp) {
		this.minAmbientTemp = minAmbientTemp;
	}
	
	public String getServerAlias() {
		return serverAlias;
	}

	public void setServerAlias(String serverAlias) {
		this.serverAlias = serverAlias;
	}
}
