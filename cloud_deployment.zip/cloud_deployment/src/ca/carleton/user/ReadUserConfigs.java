package ca.carleton.user;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import ca.carleton.debug.Debug;

public class ReadUserConfigs {
	public static String user_config_dir = "user_configs/";
	
	public static void main(String[] args) {
		readUserConfigs(null);
	}
	
	private static ArrayList<String> getUserConfigs(String userConfigDir) {
		File folder = null;
		if (userConfigDir == null) {
			folder = new File(user_config_dir);
		} else {
			folder = new File(userConfigDir);
		}
		File[] cloud_configs = folder.listFiles();
		ArrayList<String> paths = new ArrayList<>();
		
		for (int i = 0; i < cloud_configs.length; i++) {
			if (cloud_configs[i].isFile()) {
				String path = cloud_configs[i].getPath();
				
				//Debug.log("File " + path);
				
				paths.add(path);
			} 
		}
		
		return paths;
	}
	
	private static User generateUserInstance(JSONObject jsonObject) {
		User user = new User();
		
		String userGroup = (String)jsonObject.get("user_group");
		user.setUserGroup(userGroup);
		//Debug.log("userName: " + userGroup);

		double throughput = (double)jsonObject.get("deployment_throughput");
		user.setThroughput(throughput);
		//Debug.log("throughput: " + throughput);
		
		double responseTime = (double)jsonObject.get("deployment_responseTime");
		user.setResponseTime(responseTime);
		//Debug.log("app response time: " + responseTime);
		
		long maxMovesPerLqnTask = (long)jsonObject.get("deployment_maxMovesPerLqnTask");
		user.setMaxMovesPerLqnTask(maxMovesPerLqnTask);
		//Debug.log("max moves per Lqn task: " + maxMovesPerLqnTask);
		
		long windowSize = (long)jsonObject.get("deployment_windowSize");
		user.setWindowSize(windowSize);
		//Debug.log("deployment window size: " + windowSize);
		
		long hemFactor = (long)jsonObject.get("hem_factor");
		user.setHemFactor(hemFactor);
		//Debug.log("hemFactor: " + hemFactor);
		
		long hemMinVertexCount = (long)jsonObject.get("hem_minVertexCount");
		user.setHemMinVertexCount(hemMinVertexCount);
		//Debug.log("hemMinVertexCount: " + hemMinVertexCount);
		
		HashMap<String, Double> delayMap = new HashMap<>();
		JSONArray delays = (JSONArray)jsonObject.get("delays");
		for (int i = 0; i < delays.size(); i++) {
			JSONObject delay = (JSONObject) delays.get(i);
			
			String cloudName = (String) delay.get("cloud_name");
			Double delayMs = Double.parseDouble((String) delay.get("delay"));

			//Debug.log("cloudName: " + cloudName + ", delay: " + delayMs + "ms");
			
			delayMap.put(cloudName, delayMs);
		}
		user.setDelayMap(delayMap);
		
		return user;
	}
	
	public static ArrayList<User> readUserConfigs(String userConfigDir) {
		ArrayList<String> config_paths = getUserConfigs(userConfigDir);
		JSONParser parser = new JSONParser();
		ArrayList<User> cloudList = new ArrayList<>();
		
		try {
			for (String config_path : config_paths) {
				Object obj = parser.parse(new FileReader(config_path));

				JSONObject jsonObject = (JSONObject)obj;
				
				if (jsonObject != null) {
					//Debug.log(jsonObject.toString());
					User cloud = generateUserInstance(jsonObject);
					cloudList.add(cloud);
				} else {
					throw new NullPointerException("JSON Object is NULL");
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return cloudList;
	}
}
