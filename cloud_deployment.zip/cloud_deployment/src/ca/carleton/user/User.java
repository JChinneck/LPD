package ca.carleton.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import ca.carleton.cloud.Cloud;

public class User implements Serializable {
	private String userGroup;
	
	private HashMap<String, Double> delayMap;
	
	public HashMap<Cloud, Double> delayMapNoString;
	
	private long hemFactor;
	private long hemMinVertexCount;
	
	private double responseTime;
	private long maxMovesPerLqnTask;
	private double throughput;
	private long windowSize;
	
	public long getWindowSize() {
		return windowSize;
	}

	public void setWindowSize(long windowSize) {
		this.windowSize = windowSize;
	}

	public double getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(double responseTime) {
		this.responseTime = responseTime;
	}

	public long getMaxMovesPerLqnTask() {
		return maxMovesPerLqnTask;
	}

	public void setMaxMovesPerLqnTask(long maxMovesPerLqnTask) {
		this.maxMovesPerLqnTask = maxMovesPerLqnTask;
	}

	public double getThroughput() {
		return throughput;
	}

	public void setThroughput(double throughput) {
		this.throughput = throughput;
	}

	public long getHemFactor() {
		return hemFactor;
	}

	public void setHemFactor(long hemFactor) {
		this.hemFactor = hemFactor;
	}

	public long getHemMinVertexCount() {
		return hemMinVertexCount;
	}

	public void setHemMinVertexCount(long hemMinVertexCount) {
		this.hemMinVertexCount = hemMinVertexCount;
	}

	public HashMap<String, Double> getDelayMap() {
		return delayMap;
	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public void setDelayMap(HashMap<String, Double> delayMap) {
		this.delayMap = delayMap;
	}
	
	public double getDelay(Cloud cloud) {
		return this.delayMapNoString.get(cloud);
	}
	
	/* Generate a new HashMap without String keys since String comparison is expensive */
	public void generateDelayMapWithoutStringKeys(ArrayList<Cloud> clouds) {
		delayMapNoString = new HashMap<>(); 
		for(String cloudName : delayMap.keySet()) {
			for (Cloud cloud : clouds) {
				if (cloudName.equals(cloud.getCloudName())) {
					this.delayMapNoString.put(cloud, delayMap.get(cloudName));
					break;
				}
			}
		}
	}
}
