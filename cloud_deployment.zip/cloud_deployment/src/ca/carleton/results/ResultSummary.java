package ca.carleton.results;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ca.carleton.debug.Debug;

public class ResultSummary {
	String outputDir;
	String pathToOutputFile;
	HashMap<String, DataSet> data;
	double responseTimeConstraint;
	
	int goodRuns;
	int badRuns;
	
	String hemKey;
	
	double totalAlgorithmRuntime;
	
	Pattern tagPattern = Pattern.compile("<([\\w_]+)>(.*)");
	Pattern serviceTimePattern = Pattern.compile("\\w+\\s+\\w+\\s+(\\d+.\\d+)");
	
	Pattern runtimeScalePattern = Pattern.compile(" runtime_scale: (\\d+.\\d+) ms");
	Pattern runtimeCoarsenPattern = Pattern.compile(" runtime_coarsen: (\\d+.\\d+) ms");
	Pattern runtimeInitDeploymentPattern = Pattern.compile(" runtime_initdeployment: (\\d+.\\d+) ms");
	Pattern runtimePartitionPattern = Pattern.compile(" runtime_partition: (\\d+.\\d+) ms");
	Pattern runtimeUncoarsenPattern = Pattern.compile(" runtime_uncoarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackRUAEEPatternCoarsen = Pattern.compile(" runtime_binpack_ruaee_coarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackHBFProcPatternCoarsen = Pattern.compile(" runtime_binpack_hbfproc_coarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackHBFRAMPatternCoarsen = Pattern.compile(" runtime_binpack_hbfram_coarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackRUAEEPatternUncoarsen = Pattern.compile(" runtime_binpack_ruaee_uncoarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackHBFProcPatternUncoarsen = Pattern.compile(" runtime_binpack_hbfproc_uncoarsen: (\\d+.\\d+) ms");
	Pattern runtimeBinPackHBFRAMPatternUncoarsen = Pattern.compile(" runtime_binpack_hbfram_uncoarsen: (\\d+.\\d+) ms");
	
	Pattern delayBeforePartitionPattern = Pattern.compile(" delay_before_partition: (\\d+.\\d+) ms");
	Pattern delayAfterPartitionPattern = Pattern.compile(" delay_after_partition: (\\d+.\\d+) ms");
	
	Pattern powerBeforeInitDeploymentPattern = Pattern.compile(" power_before_initdeployment: (\\d+.\\d+) W");
	Pattern powerAfterInitDeploymentPattern = Pattern.compile(" power_after_initdeployment: (\\d+.\\d+) W");
	Pattern powerBeforePartitionPattern = Pattern.compile(" power_before_partition: (\\d+.\\d+) W");
	Pattern powerAfterPartitionPattern = Pattern.compile(" power_after_partition: (\\d+.\\d+) W");
	Pattern powerBinPackRUAEEPatternCoarsen = Pattern.compile(" power_binpack_ruaee_coarsen: (\\d+.\\d+) W");
	Pattern powerBinPackHBFProcPatternCoarsen = Pattern.compile(" power_binpack_hbfproc_coarsen: (\\d+.\\d+) W");
	Pattern powerBinPackHBFRAMPatternCoarsen = Pattern.compile(" power_binpack_hbfram_coarsen: (\\d+.\\d+) W");
	Pattern powerBinPackRUAEEPatternUncoarsen = Pattern.compile(" power_binpack_ruaee_uncoarsen: (\\d+.\\d+) W");
	Pattern powerBinPackHBFProcPatternUncoarsen = Pattern.compile(" power_binpack_hbfproc_uncoarsen: (\\d+.\\d+) W");
	Pattern powerBinPackHBFRAMPatternUncoarsen = Pattern.compile(" power_binpack_hbfram_uncoarsen: (\\d+.\\d+) W");
	
	Pattern stopConditionPattern = Pattern.compile(" stop_condition: (.*)");
	Pattern movesTakenPattern = Pattern.compile(" moves_taken: (\\d+)");
	Pattern attemptedTriesPattern = Pattern.compile(" attempted_tries: (\\d+)");
	
	Pattern windowSizePattern = Pattern.compile(" deployment_window_size: (\\d+)");
	
	Pattern executionDelayPattern = Pattern.compile(" verifier_execution_delay_speedup: (\\d+.\\d+)");
	Pattern executionDelayPatternNoSpeedUp = Pattern.compile(" verifier_execution_delay_no_speedup: (\\d+.\\d+)");

	public ResultSummary (String outputDir, String pathToOutputFile, double responseTimeConstraint, String hemKey) {
		this.outputDir = outputDir;
		this.pathToOutputFile = pathToOutputFile;
		data = new HashMap<String, DataSet>();
		this.responseTimeConstraint = responseTimeConstraint;
		this.hemKey = hemKey;
	}
	
	static class DataSet {
		double runtimeScale;
		double runtimeCoarsen;
		double runtimeInitDeployment;
		double runtimePartition;
		double runtimeUncoarsen;
		double runtimeBinPackRUAEECoarsen;
		double runtimeBinPackHBFProcCoarsen;
		double runtimeBinPackHBFRAMCoarsen;
		double runtimeBinPackRUAEEUncoarsen;
		double runtimeBinPackHBFProcUncoarsen;
		double runtimeBinPackHBFRAMUncoarsen;
		double delayBeforePartition;
		double delayAfterPartition;
		double lqnVerifRefServiceTimeNoDelay;
		double lqnVerifRefServiceTimeWithDelay;
		double powerBeforeInitDeployment;
		double powerAfterInitDeployment;
		double powerBeforePartition;
		double powerAfterPartition;
		double powerBinPackRUAEECoarsen;
		double powerBinPackHBFProcCoarsen;
		double powerBinPackHBFRAMCoarsen;
		double powerBinPackRUAEEUncoarsen;
		double powerBinPackHBFProcUncoarsen;
		double powerBinPackHBFRAMUncoarsen;
		String stopConditionPartition;
		long movesTakenPartition;
		long attemptedTriesPartition;
		long windowSizePartition;
		double executionDelayVerif;
		double executionDelayNoSpeedUp;
		
		public DataSet() {
			runtimeScale= -1.0;
			runtimeCoarsen= -1.0;
			runtimeInitDeployment= -1.0;
			runtimePartition= -1.0;
			runtimeUncoarsen= -1.0;
			runtimeBinPackRUAEECoarsen= -1.0;
			runtimeBinPackHBFProcCoarsen= -1.0;
			runtimeBinPackHBFRAMCoarsen= -1.0;
			runtimeBinPackRUAEEUncoarsen= -1.0;
			runtimeBinPackHBFProcUncoarsen= -1.0;
			runtimeBinPackHBFRAMUncoarsen= -1.0;
			delayBeforePartition= -1.0;
			delayAfterPartition= -1.0;
			lqnVerifRefServiceTimeNoDelay= -1.0;
			lqnVerifRefServiceTimeWithDelay= -1.0;
			powerBeforeInitDeployment= -1.0;
			powerAfterInitDeployment= -1.0;
			powerBeforePartition= -1.0;
			powerAfterPartition= -1.0;
			powerBinPackRUAEECoarsen= -1.0;
			powerBinPackHBFProcCoarsen= -1.0;
			powerBinPackHBFRAMCoarsen= -1.0;
			powerBinPackRUAEEUncoarsen= -1.0;
			powerBinPackHBFProcUncoarsen= -1.0;
			powerBinPackHBFRAMUncoarsen= -1.0;
			movesTakenPartition= -1;
			attemptedTriesPartition= -1;
			windowSizePartition= -1;
			executionDelayVerif = -1.0;
			executionDelayNoSpeedUp = -1.0;
		}
		
		@Override
		public String toString() {
			return delayBeforePartition 
				+ " " + delayAfterPartition
				+ " " + stopConditionPartition
				+ " " + movesTakenPartition
				+ " " + attemptedTriesPartition
				+ " " + windowSizePartition
				+ " " + executionDelayNoSpeedUp
				+ " " + executionDelayVerif
//				+ " " + lqnVerifRefServiceTimeNoDelay
				+ " " + lqnVerifRefServiceTimeWithDelay
				+ " " + (executionDelayNoSpeedUp + delayAfterPartition)
				+ " " + (executionDelayVerif + delayAfterPartition)
//				+ " " + (lqnVerifRefServiceTimeWithDelay - lqnVerifRefServiceTimeNoDelay)
//				+ " " + powerBeforeInitDeployment
//				+ " " + powerAfterInitDeployment
				+ " " + powerBeforePartition
				+ " " + powerAfterPartition
				+ " " + powerBinPackRUAEECoarsen
				+ " " + powerBinPackHBFProcCoarsen
				+ " " + powerBinPackHBFRAMCoarsen
				+ " " + powerBinPackRUAEEUncoarsen
				+ " " + powerBinPackHBFProcUncoarsen
				+ " " + powerBinPackHBFRAMUncoarsen
				+ " " + runtimeScale
				+ " " + runtimeCoarsen
				+ " " + runtimeInitDeployment
				+ " " + runtimePartition
				+ " " + runtimeUncoarsen
				+ " " + runtimeBinPackRUAEECoarsen
				+ " " + runtimeBinPackHBFProcCoarsen
				+ " " + runtimeBinPackHBFRAMCoarsen
				+ " " + runtimeBinPackRUAEEUncoarsen
				+ " " + runtimeBinPackHBFProcUncoarsen
				+ " " + runtimeBinPackHBFRAMUncoarsen;
		}
	}
	
	public void findLQNVerifServiceTimes(String tag, DataSet dSet) throws IOException {
		String lqnOutNoDelay = outputDir + "/" + tag + "/original.out";
		String lqnOutWithDelay = outputDir + "/" + tag + "/delay.out";
		
		dSet.lqnVerifRefServiceTimeNoDelay = getRefServiceTime(lqnOutNoDelay);
		dSet.lqnVerifRefServiceTimeWithDelay = getRefServiceTime(lqnOutWithDelay);
	}
	
	public double getRefServiceTime(String lqnOutputFile) throws IOException {
		Runtime rt = Runtime.getRuntime();
//		System.out.println(lqnOutputFile);
		String[] commands = {"/bin/sh", "-c", "grep -A3 'Service times:' " + lqnOutputFile + " | tail -n1"};
		Process proc = rt.exec(commands);
		double refServiceTime = 0.0;
		
		BufferedReader stdInput = new BufferedReader(new 
		     InputStreamReader(proc.getInputStream()));

		// read the output from the command
		String s = null;
		while ((s = stdInput.readLine()) != null) {
//			System.out.println(s);
			Matcher serviceTimeMatcher = serviceTimePattern.matcher(s);
			if (serviceTimeMatcher.find()) {
				refServiceTime = Double.parseDouble(serviceTimeMatcher.group(1));
//				System.out.println(refServiceTime);
				break;
			}
		}
		
		return refServiceTime;
	}
	
	public void processLine(String line) throws IOException {
		String tag = null;
		String content = null;
		Matcher tagMatcher = tagPattern.matcher(line);
		
		if (tagMatcher.matches()) {
			tag = tagMatcher.group(1);
			content = tagMatcher.group(2);
		} else {
			return;
		}
		
		if (!data.containsKey(tag)) {
			DataSet dNew = new DataSet();
			data.put(tag, dNew);
			findLQNVerifServiceTimes(tag, dNew);
		}
		
		Matcher runtimeScaleMatcher = runtimeScalePattern.matcher(content);
		if (runtimeScaleMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeScale = Double.parseDouble(runtimeScaleMatcher.group(1));
			//System.out.println("runtime scale: " + d.runtimeScale);
			return;
		}
		
		Matcher runtimeCoarsenMatcher = runtimeCoarsenPattern.matcher(content);
		if (runtimeCoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeCoarsen = Double.parseDouble(runtimeCoarsenMatcher.group(1));
			//System.out.println("runtime coarsen: " + d.runtimeCoarsen);
			return;
		}
		
		Matcher  runtimeInitDeploymentMatcher = runtimeInitDeploymentPattern.matcher(content);
		if (runtimeInitDeploymentMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeInitDeployment = Double.parseDouble(runtimeInitDeploymentMatcher.group(1));
			//System.out.println("runtime init deployment: " + d.runtimeInitDeployment);
			return;
		}
		
		Matcher runtimePartitionMatcher = runtimePartitionPattern.matcher(content);
		if (runtimePartitionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimePartition = Double.parseDouble(runtimePartitionMatcher.group(1));
			//System.out.println("runtime partition: " + d.runtimePartition);
			return;
		}
		
		Matcher runtimeUncoarsenMatcher = runtimeUncoarsenPattern.matcher(content);
		if (runtimeUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeUncoarsen = Double.parseDouble(runtimeUncoarsenMatcher.group(1));
			//System.out.println("runtime uncoarsen: " + d.runtimeUncoarsen);
			return;
		}
		
		Matcher runtimeBinPackRUAEECoarsenMatcher = runtimeBinPackRUAEEPatternCoarsen.matcher(content);
		if (runtimeBinPackRUAEECoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackRUAEECoarsen = Double.parseDouble(runtimeBinPackRUAEECoarsenMatcher.group(1));
			//System.out.println("runtime bin pack RUAEE coarsen: " + d.runtimeBinPackRUAEECoarsen);
			return;
		}
		
		Matcher runtimeBinPackHBFProcCoarsenMatcher = runtimeBinPackHBFProcPatternCoarsen.matcher(content);
		if (runtimeBinPackHBFProcCoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackHBFProcCoarsen = Double.parseDouble(runtimeBinPackHBFProcCoarsenMatcher.group(1));
			//System.out.println("runtime bin pack HBF Proc coarsen: " + d.runtimeBinPackHBFProcCoarsen);
			return;
		}
		
		Matcher runtimeBinPackHBFRAMCoarsenMatcher = runtimeBinPackHBFRAMPatternCoarsen.matcher(content);
		if (runtimeBinPackHBFRAMCoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackHBFRAMCoarsen = Double.parseDouble(runtimeBinPackHBFRAMCoarsenMatcher.group(1));
			//System.out.println("runtime bin pack HBF RAM coarsen: " + d.runtimeBinPackHBFRAMCoarsen);
			return;
		}
		
		Matcher runtimeBinPackRUAEEUncoarsenMatcher = runtimeBinPackRUAEEPatternUncoarsen.matcher(content);
		if (runtimeBinPackRUAEEUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackRUAEEUncoarsen = Double.parseDouble(runtimeBinPackRUAEEUncoarsenMatcher.group(1));
			//System.out.println("runtime bin pack RUAEE uncoarsen: " + d.runtimeBinPackRUAEEUncoarsen);
			return;
		}
		
		Matcher runtimeBinPackHBFProcUncoarsenMatcher = runtimeBinPackHBFProcPatternUncoarsen.matcher(content);
		if (runtimeBinPackHBFProcUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackHBFProcUncoarsen = Double.parseDouble(runtimeBinPackHBFProcUncoarsenMatcher.group(1));
			//System.out.println("runtime bin pack HBF Proc uncoarsen: " + d.runtimeBinPackHBFProcUncoarsen);
			return;
		}
		
		Matcher runtimeBinPackHBFRAMUncoarsenMatcher = runtimeBinPackHBFRAMPatternUncoarsen.matcher(content);
		if (runtimeBinPackHBFRAMUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.runtimeBinPackHBFRAMUncoarsen = Double.parseDouble(runtimeBinPackHBFRAMUncoarsenMatcher.group(1));
			//System.out.println("runtime bin pack HBF RAM uncoarsen: " + d.runtimeBinPackHBFRAMUncoarsen);
			return;
		}
		
		Matcher delayBeforePartitionMatcher = delayBeforePartitionPattern.matcher(content);
		if (delayBeforePartitionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.delayBeforePartition = Double.parseDouble(delayBeforePartitionMatcher.group(1));
			//System.out.println("delay before partition: " + d.delayBeforePartition);
			return;
		}
		
		Matcher delayAfterPartitionMatcher = delayAfterPartitionPattern.matcher(content);
		if (delayAfterPartitionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.delayAfterPartition = Double.parseDouble(delayAfterPartitionMatcher.group(1));
			//System.out.println("delay after partition: " + d.delayAfterPartition);
			return;
		}
		
		Matcher powerBeforeInitDeploymentMatcher = powerBeforeInitDeploymentPattern.matcher(content);
		if (powerBeforeInitDeploymentMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBeforeInitDeployment = Double.parseDouble(powerBeforeInitDeploymentMatcher.group(1));
			//System.out.println("power before init deployment: " + d.powerBeforeInitDeployment);
			return;
		}
		
		Matcher powerAfterInitDeploymentMatcher = powerAfterInitDeploymentPattern.matcher(content);
		if (powerAfterInitDeploymentMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerAfterInitDeployment = Double.parseDouble(powerAfterInitDeploymentMatcher.group(1));
			//System.out.println("power after init deployment: " + d.powerAfterInitDeployment);
			return;
		}
		
		Matcher powerBeforePartitionMatcher = powerBeforePartitionPattern.matcher(content);
		if (powerBeforePartitionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBeforePartition = Double.parseDouble(powerBeforePartitionMatcher.group(1));
			//System.out.println("power before partition: " + d.powerBeforePartition);
			return;
		}
		
		Matcher powerAfterPartitionMatcher = powerAfterPartitionPattern.matcher(content);
		if (powerAfterPartitionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerAfterPartition = Double.parseDouble(powerAfterPartitionMatcher.group(1));
			//System.out.println("power after partition: " + d.powerAfterPartition);
			return;
		}
		
		Matcher powerBinPackRUAEECoarsenMatcher = powerBinPackRUAEEPatternCoarsen.matcher(content);
		if (powerBinPackRUAEECoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackRUAEECoarsen = Double.parseDouble(powerBinPackRUAEECoarsenMatcher.group(1));
			//System.out.println("power bin pack RUAEE coarsen: " + d.powerBinPackRUAEECoarsen);
			return;
		}
		
		Matcher powerBinPackHBFProcCoarsenMatcher = powerBinPackHBFProcPatternCoarsen.matcher(content);
		if (powerBinPackHBFProcCoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackHBFProcCoarsen = Double.parseDouble(powerBinPackHBFProcCoarsenMatcher.group(1));
			//System.out.println("power bin pack HBF Proc coarsen: " + d.powerBinPackHBFProcCoarsen);
			return;
		}
		
		Matcher powerBinPackHBFRAMCoarsenMatcher = powerBinPackHBFRAMPatternCoarsen.matcher(content);
		if (powerBinPackHBFRAMCoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackHBFRAMCoarsen = Double.parseDouble(powerBinPackHBFRAMCoarsenMatcher.group(1));
			//System.out.println("power bin pack HBF RAM coarsen: " + d.powerBinPackHBFRAMCoarsen);
			return;
		}
		
		Matcher powerBinPackRUAEEUncoarsenMatcher = powerBinPackRUAEEPatternUncoarsen.matcher(content);
		if (powerBinPackRUAEEUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackRUAEEUncoarsen = Double.parseDouble(powerBinPackRUAEEUncoarsenMatcher.group(1));
			//System.out.println("power bin pack RUAEE uncoarsen: " + d.powerBinPackRUAEEUncoarsen);
			return;
		}
		
		Matcher powerBinPackHBFProcUncoarsenMatcher = powerBinPackHBFProcPatternUncoarsen.matcher(content);
		if (powerBinPackHBFProcUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackHBFProcUncoarsen = Double.parseDouble(powerBinPackHBFProcUncoarsenMatcher.group(1));
			//System.out.println("power bin pack HBF Proc uncoarsen: " + d.powerBinPackHBFProcUncoarsen);
			return;
		}
		
		Matcher powerBinPackHBFRAMUncoarsenMatcher = powerBinPackHBFRAMPatternUncoarsen.matcher(content);
		if (powerBinPackHBFRAMUncoarsenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.powerBinPackHBFRAMUncoarsen = Double.parseDouble(powerBinPackHBFRAMUncoarsenMatcher.group(1));
			//System.out.println("power bin pack HBF RAM uncoarsen: " + d.powerBinPackHBFRAMUncoarsen);
			return;
		}
		
		Matcher stopConditionMatcher = stopConditionPattern.matcher(content);
		if (stopConditionMatcher.matches()) {
			DataSet d = data.get(tag);
			d.stopConditionPartition = stopConditionMatcher.group(1);
//			System.out.println("stop condition: " + d.stopConditionPartition);
			return;
		}
		
		Matcher movesTakenMatcher = movesTakenPattern.matcher(content);
		if (movesTakenMatcher.matches()) {
			DataSet d = data.get(tag);
			d.movesTakenPartition = Long.parseLong(movesTakenMatcher.group(1));
//			System.out.println("moves taken: " + d.movesTakenPartition);
			return;
		}
		
		Matcher attemptedTriesMatcher = attemptedTriesPattern.matcher(content);
		if (attemptedTriesMatcher.matches()) {
			DataSet d = data.get(tag);
			d.attemptedTriesPartition = Long.parseLong(attemptedTriesMatcher.group(1));
//			System.out.println("attempted tries: " + d.attemptedTriesPartition);
			return;
		}
		
		Matcher windowSizeMatcher = windowSizePattern.matcher(content);
		if (windowSizeMatcher.matches()) {
			DataSet d = data.get(tag);
			d.windowSizePartition = Long.parseLong(windowSizeMatcher.group(1));
//			System.out.println("window size: " + d.windowSizePartition);
			return;
		}
		
		Matcher executionDelayMatcher = executionDelayPattern.matcher(content);
		if (executionDelayMatcher.matches()) {
			DataSet d = data.get(tag);
			d.executionDelayVerif = Double.parseDouble(executionDelayMatcher.group(1));
//			System.out.println("execution delay speed up: " + d.executionDelayVerif);
			return;
		}
		
		Matcher executionDelayMatcherNoSpeedUp = executionDelayPatternNoSpeedUp.matcher(content);
		if (executionDelayMatcherNoSpeedUp.matches()) {
			DataSet d = data.get(tag);
			d.executionDelayNoSpeedUp = Double.parseDouble(executionDelayMatcherNoSpeedUp.group(1));
//			System.out.println("execution delay no speed up: " + d.executionDelayNoSpeedUp);
			return;
		}
	}
	
	public void summary() {
		System.out.print("delay" + hemKey + " ");
		DataSet delayDatum = data.get("delay" + hemKey);
		if (delayDatum.delayAfterPartition == -1) {
			System.out.print("bad (-1) ");
			badRuns++;
		} else if ((delayDatum.executionDelayNoSpeedUp + delayDatum.delayAfterPartition) > this.responseTimeConstraint) {
			System.out.print("bad(" + (delayDatum.executionDelayNoSpeedUp + delayDatum.delayAfterPartition) + ") ");
			badRuns++;
		} else {
			System.out.print("good(" + (delayDatum.executionDelayNoSpeedUp + delayDatum.delayAfterPartition) + ") ");
			goodRuns++;
		}
		System.out.println(delayDatum.toString());
		
		System.out.print("power" + hemKey + " ");
		DataSet powerDatum = data.get("power" + hemKey);
		if (powerDatum.delayAfterPartition == -1) {
			System.out.print("bad (-1) ");
			badRuns++;
		} else if ((powerDatum.executionDelayNoSpeedUp + powerDatum.delayAfterPartition) > this.responseTimeConstraint) {
			System.out.print("bad(" + (powerDatum.executionDelayNoSpeedUp + powerDatum.delayAfterPartition) + ") ");
			badRuns++;
		} else {
			System.out.print("good(" + (powerDatum.executionDelayNoSpeedUp + powerDatum.delayAfterPartition) + ") ");
			goodRuns++;
		}
		System.out.println(powerDatum.toString());
		
		for (int i = 1; i <= 50; i++) {
			String key = "random_" + i + hemKey;
			System.out.print(key + " ");
			DataSet datum = data.get(key);
			if (datum.delayAfterPartition == -1) {
				System.out.print("bad (-1) ");
				badRuns++;
			} else if ((datum.executionDelayNoSpeedUp + datum.delayAfterPartition) > this.responseTimeConstraint) {
				System.out.print("bad(" + (datum.executionDelayNoSpeedUp + datum.delayAfterPartition) + ") ");
				badRuns++;
			} else {
				System.out.print("good(" + (datum.executionDelayNoSpeedUp + datum.delayAfterPartition) + ") ");
				goodRuns++;
			}
			System.out.println(datum.toString());
			
		}
		
		System.out.println("\ngood runs = " + goodRuns);
		System.out.println("bad runs = " + badRuns);
	}
	
	
	public void processOutputFile() throws IOException {
		File file = new File(pathToOutputFile);
		Scanner sc = new Scanner(file);

		while (sc.hasNextLine()) {
			processLine(sc.nextLine());
		}
	}
	
	enum PowerType {
		PARTITION,
		RUAEE_COARSEN,
		HBFPROC_COARSEN,
		HBFRAM_COARSEN,
		RUAEE_UNCOARSEN,
		HBFPROC_UNCOARSEN,
		HBFRAM_UNCOARSEN
	}
	
	public void findBestPower() {
		double minPower = Double.MAX_VALUE;
		double responseTime = -1.0;
		String minPowerKey = null;
		PowerType minPowerType = null;
		
		for (String key : data.keySet()) {
			DataSet d = data.get(key);
//			double currentResponseTime = d.executionDelayVerif + d.delayAfterPartition;
			double currentResponseTime = d.executionDelayNoSpeedUp + d.delayAfterPartition;
			
			if (d.powerAfterPartition != -1) {
				if ((d.powerAfterPartition < minPower) || ((d.powerAfterPartition == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerAfterPartition;
					minPowerKey = key;
					minPowerType = PowerType.PARTITION;
				}
			}
			
			if (d.powerBinPackRUAEECoarsen != -1) {
				if ((d.powerBinPackRUAEECoarsen < minPower) || ((d.powerBinPackRUAEECoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackRUAEECoarsen;
					minPowerKey = key;
					minPowerType = PowerType.RUAEE_COARSEN;
				}
			}
			
			if (d.powerBinPackHBFProcCoarsen != -1) {
				if ((d.powerBinPackHBFProcCoarsen < minPower) || ((d.powerBinPackHBFProcCoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackHBFProcCoarsen;
					minPowerKey = key;
					minPowerType = PowerType.HBFPROC_COARSEN;
				}
			}
			
			if (d.powerBinPackHBFRAMCoarsen != -1) {
				if ((d.powerBinPackHBFRAMCoarsen < minPower) || ((d.powerBinPackHBFRAMCoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackHBFRAMCoarsen;
					minPowerKey = key;
					minPowerType = PowerType.HBFRAM_COARSEN;
				}
			}
			
			if (d.powerBinPackRUAEEUncoarsen != -1) {
				if ((d.powerBinPackRUAEEUncoarsen < minPower) || ((d.powerBinPackRUAEEUncoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackRUAEEUncoarsen;
					minPowerKey = key;
					minPowerType = PowerType.RUAEE_UNCOARSEN;
				}
			}
			
			if (d.powerBinPackHBFProcUncoarsen != -1) {
				if ((d.powerBinPackHBFProcUncoarsen < minPower) || ((d.powerBinPackHBFProcUncoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackHBFProcUncoarsen;
					minPowerKey = key;
					minPowerType = PowerType.HBFPROC_UNCOARSEN;
				}
			}
			
			if (d.powerBinPackHBFRAMUncoarsen != -1) {
				if ((d.powerBinPackHBFRAMUncoarsen < minPower) || ((d.powerBinPackHBFRAMUncoarsen == minPower) && (currentResponseTime < responseTime))) {
					minPower = d.powerBinPackHBFRAMUncoarsen;
					minPowerKey = key;
					minPowerType = PowerType.HBFRAM_UNCOARSEN;
				}
			}
			
			if (key.equals(minPowerKey)) {
				responseTime = currentResponseTime;
			}
		}
		
		System.out.println("\n" + data.get(minPowerKey).toString());
		System.out.println("Best power = " + minPower + " W; " + minPowerKey + "; " + minPowerType 
				+ "; response time = " + responseTime + " ms");
	}
	
	public void totalAlgorithmRuntime () {
		/* Scaling and coarsening should only be accounted once since
		 * they are performed once.
		 */
		boolean scalingAccounted = false;
		boolean coarseningAccounted = false;
		
		double scalingTime = 0;
		double coarseningTime = 0;
		double maxInitDeplTime = 0;
		double maxPartitionTime = 0;
		double maxUncoarsenTime = 0;
		double maxBinPackTime = 0;
		
		totalAlgorithmRuntime = 0.0;
		
		for (String key : data.keySet()) {
			DataSet d = data.get(key);
			if (!scalingAccounted) {
				if (d.runtimeScale != -1) {
					totalAlgorithmRuntime += d.runtimeScale;
					scalingTime = d.runtimeScale;
				}
				scalingAccounted = true;
			}
			
			if (!coarseningAccounted) {
				if (d.runtimeCoarsen != -1) {
					totalAlgorithmRuntime += d.runtimeCoarsen;
					coarseningTime = d.runtimeCoarsen;
				}
				coarseningAccounted = true;
			}
			
			if (d.runtimeInitDeployment != -1) {
				totalAlgorithmRuntime += d.runtimeInitDeployment;
				if (maxInitDeplTime < d.runtimeInitDeployment) {
					maxInitDeplTime = d.runtimeInitDeployment;
				}
			}
			
			if (d.runtimePartition != -1) {
				totalAlgorithmRuntime += d.runtimePartition;
				if (maxPartitionTime < d.runtimePartition) {
					maxPartitionTime = d.runtimePartition;
				}
			}
			
			if (d.runtimeUncoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeUncoarsen;
				if (maxUncoarsenTime < d.runtimeUncoarsen) {
					maxUncoarsenTime = d.runtimeUncoarsen;
				}
			}
			
			if (d.runtimeBinPackRUAEECoarsen != -1) {	
				totalAlgorithmRuntime += d.runtimeBinPackRUAEECoarsen;
				if (maxBinPackTime < d.runtimeBinPackRUAEECoarsen) {
					maxBinPackTime = d.runtimeBinPackRUAEECoarsen;
				}
			}
			
			if (d.runtimeBinPackHBFProcCoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeBinPackHBFProcCoarsen;
				if (maxBinPackTime < d.runtimeBinPackHBFProcCoarsen) {
					maxBinPackTime = d.runtimeBinPackHBFProcCoarsen;
				}
			}
			
			if (d.runtimeBinPackHBFRAMCoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeBinPackHBFRAMCoarsen;
				if (maxBinPackTime < d.runtimeBinPackHBFRAMCoarsen) {
					maxBinPackTime = d.runtimeBinPackHBFRAMCoarsen;
				}
			}
			
			if (d.runtimeBinPackRUAEEUncoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeBinPackRUAEEUncoarsen;
				if (maxBinPackTime < d.runtimeBinPackRUAEEUncoarsen) {
					maxBinPackTime = d.runtimeBinPackRUAEEUncoarsen;
				}
			}
			
			if (d.runtimeBinPackHBFProcUncoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeBinPackHBFProcUncoarsen;
				if (maxBinPackTime < d.runtimeBinPackHBFProcUncoarsen) {
					maxBinPackTime = d.runtimeBinPackHBFProcUncoarsen;
				}
			}
			
			if (d.runtimeBinPackHBFRAMUncoarsen != -1) {
				totalAlgorithmRuntime += d.runtimeBinPackHBFRAMUncoarsen;
				if (maxBinPackTime < d.runtimeBinPackHBFRAMUncoarsen) {
					maxBinPackTime = d.runtimeBinPackHBFRAMUncoarsen;
				}
			}
		}
		
		System.out.println("Total algorithm runtime (sequential) = " + totalAlgorithmRuntime + " ms");
		
		double parallelContentionFactor = 6.5;
		double totalAlgorithmTimeParallel = scalingTime + coarseningTime + (parallelContentionFactor * (maxInitDeplTime + maxPartitionTime + maxUncoarsenTime + (maxBinPackTime*4)));
		System.out.println("Total algorithm runtime (parallel) = " + totalAlgorithmTimeParallel + " ms");
	}
	
	public void findBestResponseTime () {
		double minResponseTime = Double.MAX_VALUE;
		double minResponseTimePower = Double.MAX_VALUE;
		PowerType minRTPowerType = null;
		String minDelayKey = null;
		
		for (String key : data.keySet()) {
			DataSet d = data.get(key);
			double power = Double.MAX_VALUE;
			PowerType powerType = null;
			if ((d.executionDelayNoSpeedUp != -1) && (d.delayAfterPartition != -1)) {
				if ((d.powerAfterPartition != -1) && (d.powerAfterPartition < power)) {
					power = d.powerAfterPartition;
					powerType = PowerType.PARTITION;
				}
				
				if ((d.powerBinPackRUAEECoarsen != -1) && (d.powerBinPackRUAEECoarsen < power)) {
					power = d.powerBinPackRUAEECoarsen;
					powerType = PowerType.RUAEE_COARSEN;
				}
				
				if ((d.powerBinPackHBFProcCoarsen != -1) && (d.powerBinPackHBFProcCoarsen < power)) {
					power = d.powerBinPackHBFProcCoarsen;
					powerType = PowerType.HBFPROC_COARSEN;
				}
				
				if ((d.powerBinPackHBFRAMCoarsen != -1) && (d.powerBinPackHBFRAMCoarsen < power)) {
					power = d.powerBinPackHBFRAMCoarsen;
					powerType = PowerType.HBFRAM_COARSEN;
				}
				
				
				if ((d.powerBinPackRUAEEUncoarsen != -1) && (d.powerBinPackRUAEEUncoarsen < power)) {
					power = d.powerBinPackRUAEEUncoarsen;
					powerType = PowerType.RUAEE_UNCOARSEN;
				}
				
				if ((d.powerBinPackHBFProcUncoarsen != -1) && (d.powerBinPackHBFProcUncoarsen < power)) {
					power = d.powerBinPackHBFProcUncoarsen;
					powerType = PowerType.HBFPROC_UNCOARSEN;
				}
				
				if ((d.powerBinPackHBFRAMUncoarsen != -1) && (d.powerBinPackHBFRAMUncoarsen < power)) {
					power = d.powerBinPackHBFRAMUncoarsen;
					powerType = PowerType.HBFRAM_UNCOARSEN;
				}
				
				double responseTime = d.executionDelayNoSpeedUp + d.delayAfterPartition;
				if ((responseTime < minResponseTime) || ((responseTime == minResponseTime) && (power < minResponseTimePower))) {
					minResponseTime = responseTime;
					minDelayKey = key;
					minResponseTimePower = power;
					minRTPowerType = powerType;
				}
			}
		}
		
		System.out.println(data.get(minDelayKey).toString());
		System.out.println("Best response time = " + minResponseTime + " ms; " + minDelayKey + "; power = " + minResponseTimePower + "; " + minRTPowerType);
	}
	
	public static void main(String[] args) throws Exception {
//		String outputDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/output/model_5A/";
//		String outputDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/output/model_A30_case2/vary_window_size_nohem/run6_t0100_wm1_maxm1_h1_v1_n10000/";
		if (args.length != 3) {
			throw new IllegalArgumentException("incorrect number of arguments provided. arguments = " + args.length);
		}
		
		String outputDir = args[0];
		Integer hemInput = Integer.parseInt(args[1]);
		double responTimeConstraint = Double.parseDouble(args[2]);

		String hemSuffix = "_nohem";
		if (hemInput != 0) {
			hemSuffix = "_hem";
		}
		
		System.out.println("output_directory: " + outputDir);
		System.out.println("response_time_constraint: " + responTimeConstraint);
		System.out.println("hem_suffix: " + hemSuffix);
		
		String outputFile = outputDir + "/algorithm.out";
		
		ResultSummary results = new ResultSummary(outputDir, outputFile, responTimeConstraint, hemSuffix);
		
		results.processOutputFile();
		results.summary();
		
		try {
			results.findBestPower();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		try {
			results.findBestResponseTime();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		try {
			results.totalAlgorithmRuntime();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
