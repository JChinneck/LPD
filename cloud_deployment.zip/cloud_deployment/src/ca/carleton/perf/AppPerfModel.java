package ca.carleton.perf;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.SerializationUtils;

import ca.carleton.cloud.Cloud;
import ca.carleton.cloud.ReadCloudConfigs;
import ca.carleton.cloud.ServerInventory;
import ca.carleton.coarsening.HEM;
import ca.carleton.debug.Debug;
import ca.carleton.lqn.LqnGraph;
import ca.carleton.lqn.LqnsResults;
import ca.carleton.lqn.TupleGraphRoot;
import ca.carleton.partioner.BinPackHBFProc;
import ca.carleton.partioner.BinPackHBFRAM;
import ca.carleton.partioner.BinPackRUAEE;
import ca.carleton.partioner.CPlexDeployment;
import ca.carleton.partioner.DelayDeployment;
import ca.carleton.partioner.Deployment;
import ca.carleton.partioner.DeploymentBound;
import ca.carleton.partioner.HBFMemDecDeployment;
import ca.carleton.partioner.HBFMemIncDeployment;
import ca.carleton.partioner.HBFProcDecDeployment;
import ca.carleton.partioner.HBFProcIncDeployment;
import ca.carleton.partioner.PowerBound;
import ca.carleton.partioner.PowerDeployment;
import ca.carleton.partioner.RUAEEMemDecDeployment;
import ca.carleton.partioner.RUAEEMemIncDeployment;
import ca.carleton.partioner.RUAEEProcDecDeployment;
import ca.carleton.partioner.RUAEEProcIncDeployment;
import ca.carleton.partioner.RandomDeployment;
import ca.carleton.partioner.ScaleApp;
import ca.carleton.partioner.Verifier;
import ca.carleton.server.ReadServerConfigs;
import ca.carleton.server.Server;
import ca.carleton.testcases.TestCase;
import ca.carleton.testcases.savi.Arc;
import ca.carleton.testcases.savi.Node;
import ca.carleton.user.ReadUserConfigs;
import ca.carleton.user.User;
import edu.uci.ics.jung.graph.DirectedGraph;

public class AppPerfModel {
	protected boolean onlyGenCPlexData = false;
	
	private Path lqnPath;
	
	private LqnGraph lqnGraph;
	
	private LqnsResults lqnResults;
	
	ArrayList<Cloud> clouds;
	
	ArrayList<Server> servers;
	
	ArrayList<User> users;
	
	private TupleGraphRoot graphInfo;
	
	static String cplexOutputFile;
	
	public double totalTime = 0.0;
	
	static double alpha_wait;
	
	public enum Partition {
		DELAY,
		POWER,
		RANDOM,
		RUAEEPROCINC,
		RUAEEPROCDEC,
		RUAEEMEMINC,
		RUAEEMEMDEC,
		HBFPROCINC,
		HBFPROCDEC,
		HBFMEMINC,
		HBFMEMDEC,
		CPLEX
	}
	
	BufferedWriter cplexBuffer;
	
	public AppPerfModel(String lqn_file) {
		lqnPath = Paths.get(lqn_file);
	}
	
	private static Map<Server, Double> generateSpeedRatios(ArrayList<Server> servers) {
		Map<Server, Double> ratios = new HashMap<>();
		Server baselineServer = null;
		Double baselineServerSpeed = Double.MAX_VALUE;

		for (Server server : servers) {
			double speed = serverSpeed(server);
			if (baselineServerSpeed >= speed) {
				baselineServer = server;
				baselineServerSpeed = speed; 
				
			}
		}
		
		ratios.put(baselineServer, 1.0);

		for (Server server : servers) {
			if (baselineServer != server) {
				Double speedRatio = serverSpeed(server) / baselineServerSpeed;
				ratios.put(server, speedRatio);
			}
		}
		return ratios;
	}

	/* serverSpeed returns ssj_ops per CPU */
	private static Double serverSpeed(Server server) {
		ArrayList<Long> ssjOps = server.getSsjOps();
		Long maxSpeed = ssjOps.get(ssjOps.size() - 1);
		double numCpus = server.getHardwareThreads();
		return (maxSpeed / numCpus);
	}

	public void setupDeloymentAlgorithm() {
		long startTime = System.nanoTime();
		
		lqnGraph = LqnGraph.readLqnModel(lqnPath);

		graphInfo = TestCase.createGraphAggregate(lqnGraph);
		
		servers = ReadServerConfigs.readServerConfigs();
		for (Server server : servers) {
			/* readServerConfigs initializes ssjOps and averageActivePower arrays.
			 * Now, we can generate a regression model between ssjOps (x-axis) and
			 * averageActivePower (y-axis).
			 */
			server.generateLoadtoPowerRegressionModel();
			server.evaluateMaxPerfToPowerProperties();
		}
		
		clouds = ReadCloudConfigs.readCloudConfigs(servers, null);
		
		/* Create delay HashMaps without String keys */
		for (Cloud cloud : clouds) {
			cloud.generateDelayMapWithoutStringKeys(clouds);
			cloud.evaluateCloudStatistics();
		}
		
		users = ReadUserConfigs.readUserConfigs(null);
		for (User user : users) {
			user.generateDelayMapWithoutStringKeys(clouds);
		}
		
		if (users.size() != 1) {
			throw new IllegalArgumentException("Only 1 user profile allowed.");
		}
		
		long endTime = System.nanoTime();
		Debug.log("runtime_setup: " + ((endTime - startTime)/1000000) + " ms");
	}
	
	public void setupFindBounds(String cloudConfigDir, String userConfigDir) {
		long startTime = System.nanoTime();
		
		lqnGraph = LqnGraph.readLqnModel(lqnPath);

		graphInfo = TestCase.createGraphAggregate(lqnGraph);
		
		servers = ReadServerConfigs.readServerConfigs();
		for (Server server : servers) {
			/* readServerConfigs initializes ssjOps and averageActivePower arrays.
			 * Now, we can generate a regression model between ssjOps (x-axis) and
			 * averageActivePower (y-axis).
			 */
			server.generateLoadtoPowerRegressionModel();
			server.evaluateMaxPerfToPowerProperties();
		}
		
		Map<Server, Double> speedFactors = generateSpeedRatios(servers);
		
		for (Server server : servers) {
			server.setSolverData(speedFactors.get(server));
//			Debug.log(server.hostData);
		}
		
		clouds = ReadCloudConfigs.readCloudConfigs(servers, cloudConfigDir);
		
		/* Create delay HashMaps without String keys */
		for (Cloud cloud : clouds) {
			cloud.generateDelayMapWithoutStringKeys(clouds);
			cloud.evaluateCloudStatistics();
		}
		
		users = ReadUserConfigs.readUserConfigs(userConfigDir);
		for (User user : users) {
			user.generateDelayMapWithoutStringKeys(clouds);
		}
		
		if (users.size() != 1) {
			throw new IllegalArgumentException("Only 1 user profile allowed.");
		}
		
		long endTime = System.nanoTime();
		Debug.log("runtime_setup: " + ((endTime - startTime)/1000000) + " ms");
	}
	
	User user = null;
	TupleGraphRoot scaledGraphRoot = null;
	TupleGraphRoot coarsenedGraphRoot = null;
	ScaleApp scaler = null;
	HEM hem = null;
	boolean commonTasksDone = false;
	boolean scalingDone = false;
	boolean hemDone = false;
	AppStatistics scaledAppStatistics = null;
	AppStatistics originalAppStatistics = null;
	
	/* doHEM: true or false - whether to do coarsening phase or not
	 * approach: whether to use delay-based, power-based or random initial deployment
	 * outputDir: directory path where scaled LQN models with and without will be stored
	 */
	public void run(boolean doHEM, Partition approach, String rootDir, String name, long windowSize) throws IOException {
		String outputDir = rootDir + name;
		int result = 0;
		
		if (name != null) {
			Debug.setTag(name);
		}
		
		if (!commonTasksDone) {
			user = users.get(0);
			scaledAppStatistics = new AppStatistics(graphInfo);
			originalAppStatistics = new AppStatistics(graphInfo);
			scaledAppStatistics.adjustAppProperties(graphInfo);
			
//			TestCase.viewGraph(graphInfo.getGraph());
			scaler = new ScaleApp(graphInfo, user.getThroughput());
			
			if (scaler.isScalingNeeded()) {
				scaledGraphRoot = scaler.scale();
				if (scaledGraphRoot == null) {
					return;
				}
			}
			
			if (scaledGraphRoot == null) {
				scaledGraphRoot = graphInfo;
			} else {
				scalingDone = true;
				this.totalTime += scaler.getScaleTime();
//				TestCase.viewGraph(scaledGraphRoot.getGraph());
			}
	
			originalAppStatistics.evaluateAppStatistics(graphInfo);
			scaledAppStatistics.evaluateAppStatistics(scaledGraphRoot);
			
			if (doHEM) {
				hem = new HEM(user.getHemFactor(), user.getHemMinVertexCount());
				coarsenedGraphRoot = hem.coarsen(scaledGraphRoot);
			}
	
			if (coarsenedGraphRoot == null) {
				coarsenedGraphRoot = scaledGraphRoot;
			} else {
				hemDone = true;
				this.totalTime += hem.getCoarsenTime();
//				TestCase.viewGraph(coarsenedGraphRoot.getGraph());
			}
		}
		
		Debug.log("Original App Statistics:");
		if (!onlyGenCPlexData) {
			originalAppStatistics.printAppStatistics(graphInfo, cplexBuffer);
		}
			
		Debug.log("Scaled App Statistics:");
		scaledAppStatistics.printAppStatistics(coarsenedGraphRoot, cplexBuffer);
		
		if (!scalingDone) {
			Debug.log("No scaling done.");
			Debug.log("runtime_scale: 0.0 ms");
		} else {
			Debug.log("runtime_scale: " + scaler.getScaleTime() + " ms");
		}
		
		if (!hemDone) {
			Debug.log("runtime_coarsen: 0.0 ms");
			Debug.log("No coarsening done.");
		} else {
			Debug.log("runtime_coarsen: " + hem.getCoarsenTime() + " ms");
		}
		
		//UNCOMMENT to run the full algorithm
		if (onlyGenCPlexData) {
			//Exit to just get the CPLEX model
			cplexBuffer.close();
			System.exit(0);
		}
		
		commonTasksDone = true;
		
		Deployment mcadDeployment = null;
		
		if (approach == Partition.POWER) {
			mcadDeployment = new PowerDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.RANDOM) {
			mcadDeployment = new RandomDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.DELAY) {
			mcadDeployment = new DelayDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.HBFPROCDEC) {
			mcadDeployment = new HBFProcDecDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.HBFPROCINC) {
			mcadDeployment = new HBFProcIncDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.HBFMEMDEC) {
			mcadDeployment = new HBFMemDecDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.HBFMEMINC) {
			mcadDeployment = new HBFMemIncDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.RUAEEPROCDEC) {
			mcadDeployment = new RUAEEProcDecDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.RUAEEPROCINC) {
			mcadDeployment = new RUAEEProcIncDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.RUAEEMEMDEC) {
			mcadDeployment = new RUAEEMemDecDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.RUAEEMEMINC) {
			mcadDeployment = new RUAEEMemIncDeployment(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);
		} else if (approach == Partition.CPLEX) {
			mcadDeployment = new CPlexDeployment(clouds, servers, user, scaledGraphRoot.getGraph(), scaledGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay, cplexOutputFile);
		} else {
//			throw new RuntimeException("Incorrect partition approach specified");
			Debug.log("Incorrect partition approach specified");
			return;
		}
		
		result = mcadDeployment.initialDeployment();
		if (result != 0) {
			return;
		}
		
		this.totalTime += mcadDeployment.getInitDeploymentTime();
		Debug.log("runtime_initdeployment: " + mcadDeployment.getInitDeploymentTime() + " ms");
		mcadDeployment.printDeployment(null);
		
		/* Clone the deployment after initial deployment for min delay partitioning. */
		Deployment delayDeployment = (Deployment)SerializationUtils.clone(mcadDeployment);
		
		/* Partition using the MCAD algorithm. */
		result = mcadDeployment.partition();
		if (result != 0) {
			Debug.log("mcad_runtime_partition: " + mcadDeployment.getPartitionTime() + " ms");
			return;
		}
		
		this.totalTime += mcadDeployment.getPartitionTime();
		
		Debug.log("mcad deployment after parition: ");
		mcadDeployment.printDeployment(null);
		
		/* Partition to only reduce network delay. */
		result = delayDeployment.partitionMinDelay();
		if (result != 0) {
			Debug.log("delay_runtime_partition: " + delayDeployment.getPartitionTime() + " ms");
			return;
		}
		
		Debug.log("delay deployment after parition: ");
		delayDeployment.printDeployment(null);
		
		result = runBinPackBeforeCoarsening(clouds, servers, mcadDeployment, "mcad_");

		result = runBinPackBeforeCoarsening(clouds, servers, delayDeployment, "delay_");
		
		Debug.log("mcad_runtime_partition: " + mcadDeployment.getPartitionTime() + " ms");
		mcadDeployment.printDeployment(null);
		
		Debug.log("delay_runtime_partition: " + delayDeployment.getPartitionTime() + " ms");
		mcadDeployment.printDeployment(null);
		
		uncoarsen(hem, mcadDeployment, doHEM, "mcad_");
		
		uncoarsen(hem, delayDeployment, doHEM, "delay_");
		
		result = runBinPackAfterCoarsening(clouds, servers, mcadDeployment, hem, doHEM, "mcad_");
		
		result = runBinPackAfterCoarsening(clouds, servers, delayDeployment, hem, doHEM, "delay_");
		
		/* Create a directory to store LQN models with and without delay. */
		createDirectory(outputDir);
		
		lqnVerif(outputDir, servers, user, scaledGraphRoot, mcadDeployment, hem, doHEM, "mcad_");
//		
//		lqnVerif(outputDir, servers, user, scaledGraphRoot, delayDeployment, hem, doHEM, "delay_");
	}
	
	public void uncoarsen(HEM hem, Deployment deployment, boolean doHEM, String prefix) {
		if (doHEM) {
			hem.unCoarsen(deployment.getPartitions(), deployment.getCloudInfoList());
			/* Only account uncoarsening time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += hem.getUncoarsenTime();
			}
			Debug.log(prefix + "runtime_uncoarsen: " + hem.getUncoarsenTime() + " ms");
			deployment.printDeployment(hem.getOldNewMap());
		}
	}
	
	public static void lqnVerif(String outputDir, ArrayList<Server> servers, User user, TupleGraphRoot scaledGraphRoot, Deployment deployment, HEM hem, boolean doHEM, String prefix) {
		Verifier verif = null; 
		if (doHEM) {
			verif = new Verifier(outputDir, servers, user, scaledGraphRoot.getGraph(), scaledGraphRoot.getRoot(),
					deployment.getPartitions(), deployment.getResourceDistribution(), hem.getOldNewMap(), deployment);
		} else {
			verif = new Verifier(outputDir, servers, user, scaledGraphRoot.getGraph(), scaledGraphRoot.getRoot(),
					deployment.getPartitions(), deployment.getResourceDistribution(), null, deployment);
		}
		verif.verify(prefix);
	}
	
	public int runBinPackBeforeCoarsening(ArrayList<Cloud> clouds, ArrayList<Server> servers, Deployment deployment, String prefix) {
		int result = 0;
		
		BinPackRUAEE binPackRUACoarsen = new BinPackRUAEE(clouds, servers, deployment.getPartitions());
		result = binPackRUACoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackRUACoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_ruaee_coarsen: " + binPackRUACoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_ruaee_coarsen: " + binPackRUACoarsen.getPower() + " W");
			binPackRUACoarsen.printBinPackAllocation(null);
		}
		
		BinPackHBFProc binPackHBFProcCoarsen = new BinPackHBFProc(clouds, servers, deployment.getPartitions());
		result = binPackHBFProcCoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackHBFProcCoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_hbfproc_coarsen: " + binPackHBFProcCoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_hbfproc_coarsen: " + binPackHBFProcCoarsen.getPower() + " W");
			binPackHBFProcCoarsen.printBinPackAllocation(null);
		}
		
		
		BinPackHBFRAM binPackHBFRAMCoarsen = new BinPackHBFRAM(clouds, servers, deployment.getPartitions());
		result = binPackHBFRAMCoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackHBFRAMCoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_hbfram_coarsen: " + binPackHBFRAMCoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_hbfram_coarsen: " + binPackHBFRAMCoarsen.getPower() + " W");
			binPackHBFRAMCoarsen.printBinPackAllocation(null);
		}
		
		return result;
	}
	
	public int runBinPackAfterCoarsening(ArrayList<Cloud> clouds, ArrayList<Server> servers, Deployment deployment, HEM hem, boolean doHEM, String prefix) {
		int result = 0;
		
		BinPackRUAEE binPackRUAUncoarsen = new BinPackRUAEE(clouds, servers, deployment.getPartitions());
		result = binPackRUAUncoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackRUAUncoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_ruaee_uncoarsen: " + binPackRUAUncoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_ruaee_uncoarsen: " + binPackRUAUncoarsen.getPower() + " W");
			if (doHEM) {
				binPackRUAUncoarsen.printBinPackAllocation(hem.getOldNewMap());
			} else {
				binPackRUAUncoarsen.printBinPackAllocation(null);
			}
		}
		
		BinPackHBFProc binPackHBFProcUncoarsen = new BinPackHBFProc(clouds, servers, deployment.getPartitions());
		result = binPackHBFProcUncoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackHBFProcUncoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_hbfproc_uncoarsen: " + binPackHBFProcUncoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_hbfproc_uncoarsen: " + binPackHBFProcUncoarsen.getPower() + " W");
			if (doHEM) {
				binPackHBFProcUncoarsen.printBinPackAllocation(hem.getOldNewMap());
			} else {
				binPackHBFProcUncoarsen.printBinPackAllocation(null);
			}
		}
		
		
		BinPackHBFRAM binPackHBFRAMUncoarsen = new BinPackHBFRAM(clouds, servers, deployment.getPartitions());
		result = binPackHBFRAMUncoarsen.binPack();
		if (result == 0) {
			/* Only account bin-pack time for MCAD partitioning and ignore min delay partitioning. */
			if (prefix.equals("mcad_")) {
				this.totalTime += binPackHBFRAMUncoarsen.getBinPackTime();
			}
			Debug.log(prefix + "runtime_binpack_hbfram_uncoarsen: " + binPackHBFRAMUncoarsen.getBinPackTime() + " ms");
			Debug.log(prefix + "power_binpack_hbfram_uncoarsen: " + binPackHBFRAMUncoarsen.getPower() + " W");
			if (doHEM) {
				binPackHBFRAMUncoarsen.printBinPackAllocation(hem.getOldNewMap());
			} else {
				binPackHBFRAMUncoarsen.printBinPackAllocation(null);
			}
		}
		
		return result;
	}
	
	/* find power and delay bounds
	 */
	public void findBounds(boolean doHEM, String name, long windowSize) throws IOException {
		int result = 0;
		
		if (name != null) {
			Debug.setTag(name);
		}
		
		if (!commonTasksDone) {
			user = users.get(0);
			scaledAppStatistics = new AppStatistics(graphInfo);
			originalAppStatistics = new AppStatistics(graphInfo);
			scaledAppStatistics.adjustAppProperties(graphInfo);
			
//			TestCase.viewGraph(graphInfo.getGraph());
			scaler = new ScaleApp(graphInfo, user.getThroughput());
			
			if (scaler.isScalingNeeded()) {
				scaledGraphRoot = scaler.scale();
				if (scaledGraphRoot == null) {
					return;
				}
			}
			
			if (scaledGraphRoot == null) {
				scaledGraphRoot = graphInfo;
			} else {
				scalingDone = true;
//				TestCase.viewGraph(scaledGraphRoot.getGraph());
			}
	
			originalAppStatistics.evaluateAppStatistics(graphInfo);
			scaledAppStatistics.evaluateAppStatistics(scaledGraphRoot);
			
			if (doHEM) {
				hem = new HEM(user.getHemFactor(), user.getHemMinVertexCount());
				coarsenedGraphRoot = hem.coarsen(scaledGraphRoot);
			}
	
			if (coarsenedGraphRoot == null) {
				coarsenedGraphRoot = scaledGraphRoot;
			} else {
				hemDone = true;
//				TestCase.viewGraph(coarsenedGraphRoot.getGraph());
			}
		}
		
		Debug.log("Original App Statistics:");
		originalAppStatistics.printAppStatistics(graphInfo, cplexBuffer);
		
		Debug.log("Scaled App Statistics:");
		scaledAppStatistics.printAppStatistics(coarsenedGraphRoot, cplexBuffer);
		
		if (!scalingDone) {
			Debug.log("No scaling done.");
			Debug.log("runtime_scale: 0.0 ms");
		} else {
			Debug.log("runtime_scale: " + scaler.getScaleTime() + " ms");
		}
		
		if (!hemDone) {
			Debug.log("runtime_coarsen: 0.0 ms");
			Debug.log("No coarsening done.");
		} else {
			Debug.log("runtime_coarsen: " + hem.getCoarsenTime() + " ms");
		}
		
		commonTasksDone = true;
		
		DeploymentBound powerBound = new PowerBound(clouds, servers, user, coarsenedGraphRoot.getGraph(), coarsenedGraphRoot.getRoot(), windowSize, scaledAppStatistics.executionDelay);;
//		result = powerBound.initialDeployment(scaledAppStatistics.appTotalCpuDemand * Cloud.CpuDemandToSsjOpsConversion, scaledAppStatistics.appTotalRam);
//		result = powerBound.initialDeployment();
//		result = powerBound.findBound(scaledAppStatistics.appTotalCpuDemand * Cloud.CpuDemandToSsjOpsConversion, scaledAppStatistics.appTotalRam);
		result = powerBound.findBound1(scaledAppStatistics.appTotalCpuDemand * Cloud.CpuDemandToSsjOpsConversion, scaledAppStatistics.appTotalRam);
		powerBound.printDeployment(null);
	}
	
	public LqnGraph getLqn_graph() {
		return lqnGraph;
	}

	public DirectedGraph<Node, Arc> getGraph() {
		return graphInfo.getGraph();
	}
	
	public Node getRoot() {
		return graphInfo.getRoot();
	}
	
	static class AppStatistics {
		double appTotalRam;
		
		double appTotalCpuDemand;
		
		double appTotalSsjOps;
		
		double appTotalCalls;
		
		double appTotalNodes;
		
		double executionDelay;
		
		double maxCpuDemandPerInvocation;
		
		AppStatistics(TupleGraphRoot originalGraphRoot) {
			findMaxCpuDemandPerInvocation(originalGraphRoot);
		}
		
		private void findMaxCpuDemandPerInvocation(TupleGraphRoot graphRootApp) {
			for (Node node : graphRootApp.getGraph().getVertices()) {
				double cpuDemandPerUserReq = node.getCpuDemandPerInvocation();
				if (cpuDemandPerUserReq > maxCpuDemandPerInvocation) {
					maxCpuDemandPerInvocation = cpuDemandPerUserReq;
				}
			}
		}
		
		private void evaluateAppStatistics(TupleGraphRoot graphRootApp) {
			double utilNorm = Cloud.UtilNorm;
			
			for (Node node : graphRootApp.getGraph().getVertices()) {
				double cpuDemandPerUserReq = node.getCpuDemandPerUserReq();
				executionDelay += (alpha_wait * cpuDemandPerUserReq / (1 - utilNorm));
				appTotalRam += node.getMemory();
				appTotalCpuDemand += node.getCpuDemandPerInvocation();
				appTotalCalls += node.getCallsPerUserReq();
			}
		}
		
		public void adjustAppProperties(TupleGraphRoot graphRootApp) {
			/* Limit RAM assigned to any node 0.25GB <= memory <= 4GB */
			double ramAdjust = 4/maxCpuDemandPerInvocation;
			
			/* One 1 CPU can support to ~50000 ssj_ops 
			 * Limit CPUs assigned to any node <= 4
			 */
			double ssjOpConverter = 10*50000/(4*maxCpuDemandPerInvocation/Cloud.UtilNorm);
			
			for (Node node : graphRootApp.getGraph().getVertices()) {
				/* Re-adjust node memory between 0.25 GB and 4 GB */
				double cpuDemandPerUserReq = node.getCpuDemandPerInvocation();
				double newRam = ramAdjust * cpuDemandPerUserReq;
				if ((newRam >= 0.25) && (newRam <= 4.0)) {
					node.setMemory(newRam);
				} else if (newRam < 0.25) {
					node.setMemory(0.25);
				} else {
					node.setMemory(4.0);
				}
			}
			
			/* Max. limit of CPUs assigned to any node is set to 4 */
			Cloud.setCpuDemandToSsjOpsConversion(ssjOpConverter);
		}
		
		public void printAppStatistics(TupleGraphRoot graphRootApp, BufferedWriter cplexBuffer) throws IOException {
			Debug.log("adjustAppProperties: ramAdjust = " + 4/maxCpuDemandPerInvocation);
			Debug.log("adjustAppProperties: ssjOpConverter = " + Cloud.CpuDemandToSsjOpsConversion);
			
			Debug.log("Application Statistics:" +
					"\n\tcpu demand: " + String.format ("%,.2f", appTotalCpuDemand) + " ms" +
					"\n\tssj ops: " + String.format ("%,.2f", appTotalCpuDemand * Cloud.CpuDemandToSsjOpsConversion) +
					"\n\texecution delay: " + String.format ("%,.2f", executionDelay) + " ms" +
					"\n\tram: " + String.format ("%,.2f", appTotalRam) + " GB" +
					"\n\tcalls: " + String.format ("%,.2f", appTotalCalls));
			
			Debug.log("\nApplication Node Statistics: 1 CPU ~ 50000 ssj_ops");
			DirectedGraph<Node, Arc> graph = graphRootApp.getGraph();
			Node root = graphRootApp.getRoot();
			
			Collection<Node> nodeC = graph.getVertices();
			Node[] nodes = nodeC.toArray(new Node[nodeC.size()]);
			for (Node node : nodes) {
				double ssjOps = Cloud.CpuDemandToSsjOpsConversion * node.getCpuDemandPerInvocation();
				Debug.log("\t" + node.toString() +
						" ssj_ops=" + String.format ("%,.2f", ssjOps) +
						" cpus_approx=" + String.format ("%,.2f", ssjOps/50000));
			}
			
			StringBuilder task_calls = new StringBuilder();
			StringBuilder ssj_ops = new StringBuilder();
			StringBuilder memory = new StringBuilder();
			StringBuilder task_names = new StringBuilder();
			int userTaskIndex = -1;
			
			DecimalFormat df = new DecimalFormat("#.#####");
			System.out.println("r_proc = " + df.format(executionDelay) + ";");
			System.out.println("num_tasks = " + nodes.length + ";");
			task_calls.append("task_calls = [");
			ssj_ops.append("task_ssj_ops = [");
			memory.append("task_memory = [");
			task_names.append("task_names = [");
			int i = 0;
			for (Node node1 : nodes) {
				if (root != node1) {
					ssj_ops.append(df.format(Cloud.CpuDemandToSsjOpsConversion * node1.getCpuDemandPerInvocation()));
					memory.append(df.format(node1.getMemory()));
				} else {
					//ssj_ops.append("root_0.0");
					//memory.append("root_0.0");
					ssj_ops.append("0.0");
					memory.append("0.0");
				}
				task_names.append("\"" + node1.getName() + "\", ");
				
				ssj_ops.append(", ");
				memory.append(", ");
				
				if (node1 == root) {
//					task_calls.append("[root_");
					userTaskIndex = i;
//				} else {
//					task_calls.append("[");
				}
				task_calls.append("[");
				
				for (Node node2 : nodes) {
					Arc arc = graph.findEdge(node1, node2);
					if (arc != null) {
						task_calls.append(df.format(arc.getCallsPerUserReq()) + ", ");
					} else {
						task_calls.append("0.0, ");
					}
				}
				task_calls.delete(task_calls.length() - 2, task_calls.length());
				task_calls.append("], ");
				task_calls.append(System.getProperty("line.separator"));
				i++;
			}
			
			task_calls.delete(task_calls.length() - 3, task_calls.length());
			task_calls.append("];");
			
			ssj_ops.delete(ssj_ops.length() - 2, ssj_ops.length());
			ssj_ops.append("];");
			
			memory.delete(memory.length() - 2, memory.length());
			memory.append("];");
			
			task_names.delete(task_names.length() - 2, task_names.length());
			task_names.append("];");
			
			System.out.println("user_task_index = " + userTaskIndex + ";");
			System.out.println(task_names.toString()); 
			System.out.println(task_calls.toString());
			System.out.println(ssj_ops.toString());
			System.out.println(memory.toString());
			
			if (cplexBuffer != null) {
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write("r_proc = " + df.format(executionDelay) + ";");
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write("num_tasks = " + nodes.length + ";");
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write("user_task_index = " + userTaskIndex + ";");
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write(task_names.toString());
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write(task_calls.toString());
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write(ssj_ops.toString());
				cplexBuffer.newLine(); cplexBuffer.newLine();
				cplexBuffer.write(memory.toString());
				cplexBuffer.newLine(); cplexBuffer.newLine();
			}
			
			Debug.log("");
		}
	}
	
	
	/* Create directory using dirPath. */
	public static boolean createDirectory(String dirPath) {
		File theDir = new File(dirPath);
		boolean result = false;
		
		// if the directory does not exist, create it
		if (!theDir.exists()) {
		    System.out.println("creating directory: " + theDir.getName());

		    try{
		        theDir.mkdir();
		        result = true;
		    } 
		    catch(SecurityException se){
		        //handle it
		    }        
		    if(result) {    
		        System.out.println("DIR created");  
		    }
		}
		
		return result;
	}
	
	String nullHostData = "<\"stub\", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0>";
	
	/* Invoke this method only after invoking the setup() method */
	public void printStatisticsAllClouds(BufferedWriter cplexBuffer) throws IOException {
		int maxServers = Integer.MIN_VALUE;
		Debug.log("\nCloud Statistics:");
		for (Cloud cloud : clouds) {
			if (cloud.totalServers >= maxServers) {
				maxServers = cloud.totalServers;
			}
			cloud.printCloudStatistics();
		}
		
		StringBuilder cloud_hosts = new StringBuilder();
		cloud_hosts.append("cloud_hosts = [");
		cloud_hosts.append("[");
		for (int i = 0; i < maxServers; i++) {
			cloud_hosts.append(nullHostData + ", ");
		}
		cloud_hosts.delete(cloud_hosts.length() - 2, cloud_hosts.length());
		cloud_hosts.append("], ");
		cloud_hosts.append(System.getProperty("line.separator"));
		for (Cloud cloud : clouds) {
			cloud_hosts.append("[");
			int serverIndex = 1;
			for (ServerInventory serverInventory : cloud.getInventory()) {
				for (int i = 0; i < serverInventory.getNumAvailable(); i++) {
					String hostData = "<\"" 
										+ serverInventory.server.getServerName()
										+ "_"
										+ serverIndex
										+ "\", "
										+ serverInventory.server.hostData;
					cloud_hosts.append(hostData + ", ");
					serverIndex += 1;
				}
			}
			for (int i = 0; i < (maxServers - cloud.totalServers); i++) {
				cloud_hosts.append(nullHostData + ", ");
			}
			cloud_hosts.delete(cloud_hosts.length() - 2, cloud_hosts.length());
			cloud_hosts.append("], ");
			cloud_hosts.append(System.getProperty("line.separator"));
		}
		cloud_hosts.delete(cloud_hosts.length() - 3, cloud_hosts.length());
		cloud_hosts.append("];");
		
		StringBuilder cloud_names = new StringBuilder();
		cloud_names.append("cloud_names = [");
		
		StringBuilder cloud_delay = new StringBuilder();
		cloud_delay.append("cloud_delay = [");
		cloud_delay.append("[");
		cloud_delay.append("0.0, ");
		for (Cloud cloud : clouds) {
			cloud_delay.append(users.get(0).getDelay(cloud) + ", ");
		}
		
		cloud_names.append("\"" + users.get(0).getUserGroup() + "\", ");
		
		cloud_delay.delete(cloud_delay.length() - 2, cloud_delay.length());
		cloud_delay.append("], ");
		cloud_delay.append(System.getProperty("line.separator"));	
		for (Cloud cloud1 : clouds) {
			cloud_names.append("\"" + cloud1.getCloudName() + "\", ");
			
			cloud_delay.append("[");
			cloud_delay.append(users.get(0).getDelay(cloud1) + ", ");
			for (Cloud cloud2 : clouds) {
				if (cloud1 != cloud2) {
					cloud_delay.append(cloud1.getDelay(cloud2) + ", ");
				} else {
					cloud_delay.append("0.0, ");
				}
			}
			cloud_delay.delete(cloud_delay.length() - 2, cloud_delay.length());
			cloud_delay.append("], ");
			cloud_delay.append(System.getProperty("line.separator"));	
		}
		
		cloud_delay.delete(cloud_delay.length() - 3, cloud_delay.length());
		cloud_delay.append("];");
		
		cloud_names.delete(cloud_names.length() - 2, cloud_names.length());
		cloud_names.append("];");
		
		System.out.println("max_hosts = " + maxServers + ";");
		System.out.println("num_clouds = " + (clouds.size() + 1) + ";");
		System.out.println(cloud_names.toString());
		System.out.println(cloud_delay.toString());
		System.out.println(cloud_hosts.toString());
		
		if (cplexBuffer != null) {
			cplexBuffer.newLine(); cplexBuffer.newLine();
			cplexBuffer.write("max_hosts = " + maxServers + ";");
			cplexBuffer.newLine(); cplexBuffer.newLine();
			cplexBuffer.write("num_clouds = " + (clouds.size() + 1) + ";");
			cplexBuffer.newLine(); cplexBuffer.newLine();
			cplexBuffer.write(cloud_names.toString());
			cplexBuffer.newLine(); cplexBuffer.newLine();
			cplexBuffer.write(cloud_delay.toString());
			cplexBuffer.newLine(); cplexBuffer.newLine();
			cplexBuffer.write(cloud_hosts.toString());
			cplexBuffer.newLine(); cplexBuffer.newLine();
		}
	}

	public static void setOutputStreams(String filePathOut, String filePathErr) 
			throws FileNotFoundException {
		FileOutputStream fout= new FileOutputStream(filePathOut);
		FileOutputStream ferr= new FileOutputStream(filePathErr);
		
		MultiOutputStream multiOut= new MultiOutputStream(System.out, fout);
		MultiOutputStream multiErr= new MultiOutputStream(System.err, ferr);
		
		PrintStream stdout= new PrintStream(multiOut);
		PrintStream stderr= new PrintStream(multiErr);
		
		System.setOut(stdout);
		System.setErr(stderr);
	}
	
	protected static void copyFolder(String source, String destination) throws IOException {
		File sourceFolder = new File(source);
	    //Target directory where files should be copied
	    File destinationFolder = new File(destination);
	    copyFolder(sourceFolder, destinationFolder);
	}
    
	protected static void copyFolder(File sourceFolder, File destinationFolder) throws IOException {
		// Check if sourceFolder is a directory or file
		// If sourceFolder is file; then copy the file directly to new location
		if (sourceFolder.isDirectory()) {
			// Verify if destinationFolder is already present; If not then
			// create it
			if (!destinationFolder.exists()) {
				destinationFolder.mkdir();
				System.out.println("Directory created :: " + destinationFolder);
			}

			// Get all files from source directory
			String files[] = sourceFolder.list();

			// Iterate over all files and copy them to destinationFolder one by
			// one
			for (String file : files) {
				File srcFile = new File(sourceFolder, file);
				File destFile = new File(destinationFolder, file);

				// Recursive function call
				copyFolder(srcFile, destFile);
			}
		} else {
			// Copy the file content from one place to another
			Files.copy(sourceFolder.toPath(), destinationFolder.toPath(), StandardCopyOption.REPLACE_EXISTING);
			System.out.println("File copied :: " + destinationFolder);
		}
	}

	public static void deleteDirectory(String dirPath) throws IOException {
		File dir = new File(dirPath);
		deleteDirectory(dir);
	}
	
	public static void deleteDirectory(File file) throws IOException {
		if (file.isDirectory()) {
			// directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
				System.out.println("Directory is deleted : " + file.getAbsolutePath());
			} else {
				// list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);
					// recursive delete
					deleteDirectory(fileDelete);
				}
				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
					System.out.println("Directory is deleted : " + file.getAbsolutePath());
				}
			}
		} else {
			// if file, then delete it
			file.delete();
			System.out.println("File is deleted : " + file.getAbsolutePath());
		}
	}
	
	public static void main(String[] args) throws IOException {
		runDeploymentAlgorithm(args);
		
//		findPowerDelayBounds(args);
	}
	
	private static void runDeploymentAlgorithm(String[] args) throws IOException {
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/eclipse_workspace/hasrut/testcases/012.lqn";
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/out_testing/model_5A.lqn";
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/sample_models/model_A30_case2.lqn";
		
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_models/model_A8_case13.lqn";
//		long windowSize = -1;
//		String configDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_configs/model_A8_v3/";
//		Integer hemInput = 1;
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/test_13Jun20/model_A8_case13_v3/";
//		double responseTime = 7500.0;
//		
//		cplexOutputFile = configDir + "/cplex_output.txt";
		
//		if (args.length != 4) {
		if (args.length != 8) {
			throw new IllegalArgumentException("incorrect number of arguments provided.");
		}
		
//		String lqnFile = args[0];
//		String rootDirPrev = args[1];
//		Integer hemInput = Integer.parseInt(args[2]);
//		long windowSize = Long.parseLong(args[3]);
//
//		String rootDir = rootDirPrev + "_ver3/";
//		String userConfigDir = rootDirPrev + "/user_configs";
//		String cloudConfigDir = rootDirPrev + "/cloud_configs";
		
		/* UNCOMMENT to run scripts */
		String lqnFile = args[0];
		String configDir = args[1] + "/";
		Integer hemInput = Integer.parseInt(args[2]);
		long windowSize = Long.parseLong(args[3]);
		String rootDir = args[4] + "/";
		double responseTime = Double.parseDouble(args[5]);
		cplexOutputFile = args[6]; 
		alpha_wait = Double.parseDouble(args[7]);
		System.out.println("alpha_wait = " + alpha_wait + ";");
		
		String userConfigDir = configDir + "/user_configs";
		String cloudConfigDir = configDir + "/cloud_configs";
		
		int randomCount = 50;

		boolean hemBool = false;
		String hemSuffix = "_nohem";
		if (hemInput != 0) {
			hemBool = true;
			hemSuffix = "_hem";
		}
		
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/output/model_5A/";
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/output/model_A30_case2/vary_window_size_nohem/run6_t0100_wm1_maxm1_h1_v1_n10000/";
		
		/* Delete output directory to avoid stale data. */
		deleteDirectory(rootDir);
		
		/* Create a new output directory. */
		createDirectory(rootDir);
		
		/* Store algorithm's System.out in rootDir/algorithm.out and System.err in rootDir/algorithm.err */
		setOutputStreams(rootDir + "algorithm.out", rootDir + "algorithm.err");
		
		AppPerfModel model = new AppPerfModel(lqnFile);
		
//		model.setupDeloymentAlgorithm();
		model.setupFindBounds(cloudConfigDir, userConfigDir);
		model.printStatisticsAllClouds(model.cplexBuffer);
		
		if (responseTime > 0) {
			 /* If response time constraint is provided as a cmdline parameter, override it in the user config. */
			model.users.get(0).setResponseTime(responseTime);
		}
		
		System.out.println("response_time_constraint = " + model.users.get(0).getResponseTime() + ";");
		if (model.cplexBuffer != null) {
			model.cplexBuffer.write("response_time_constraint = " + model.users.get(0).getResponseTime() + ";");
			model.cplexBuffer.newLine(); model.cplexBuffer.newLine();
		}
		
		/* Run algorithm with delay (minimized) focused initial deployment with and without HEM. */
//		model.run(true, Partition.DELAY, rootDir, "delay_hem", windowSize);
		model.run(hemBool, Partition.DELAY, rootDir, "delay" + hemSuffix, windowSize);
		
		/* Run algorithm with power (minimized) focused initial deployment with and without HEM. */
//		model.run(true, Partition.POWER, rootDir, "power_hem", windowSize);
		model.run(hemBool, Partition.POWER, rootDir, "power" + hemSuffix, windowSize);
		
		model.run(hemBool, Partition.HBFMEMDEC, rootDir, "hbfmemdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFMEMINC, rootDir, "hbfmeminc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFPROCDEC, rootDir, "hbfprocdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFPROCINC, rootDir, "hbfprocinc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEMEMDEC, rootDir, "ruaeememdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEMEMINC, rootDir, "ruaeememinc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEPROCDEC, rootDir, "ruaeeprocdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEPROCINC, rootDir, "ruaeeprocinc" + hemSuffix, windowSize);
		
		if (!cplexOutputFile.equals("none")) {
			model.run(hemBool, Partition.CPLEX, rootDir, "cplex" + hemSuffix, windowSize);
		}
		
		/* Run algorithm randomCount times with random initial deployment with and without HEM. */
		for (int i = 1; i <= randomCount; i++) {
//			model.run(true, Partition.RANDOM, rootDir, "random_" + i + "_hem", windowSize);
			model.run(hemBool, Partition.RANDOM, rootDir, "random_" + i + hemSuffix, windowSize);
		}
		
		/* Keep evaluating random initial deployments until total runtime exceeds 10 seconds. */
		for (int i = randomCount + 1; model.totalTime <= 10000; i++) {
			Debug.log("runtime_total: " + model.totalTime + " ms");
			model.run(hemBool, Partition.RANDOM, rootDir, "random_" + i + hemSuffix, windowSize);
		}
		
		Debug.log("runtime_total: " + model.totalTime + " ms");
		
		/* Copy user configs to output directory. */
//		String userConfigs = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/git/babneet_thesis/cloud_deployment/user_configs";
//		copyFolder(userConfigs, rootDir + "user_configs");
		
		/* Copy cloud configs to output directory */
//		String cloudConfigs = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/git/babneet_thesis/cloud_deployment/cloud_configs";
//		copyFolder(cloudConfigs, rootDir + "cloud_configs");
		
		copyFolder(userConfigDir, rootDir + "user_configs");
		copyFolder(cloudConfigDir, rootDir + "cloud_configs");
		
	}
	
	private static void findPowerDelayBounds(String[] args) throws IOException {
		
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_models/model_A8_case13.lqn";
//		long windowSize = -1;
//		String configDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_configs/model_A8_v3/";
//		String userConfigDir = configDir + "/user_configs";
//		String cloudConfigDir = configDir + "/cloud_configs";

		if (args.length != 4) {
			throw new IllegalArgumentException("incorrect number of arguments provided.");
		}
		
		String lqnFile = args[0];
		String userConfigDir = args[1];
		String cloudConfigDir = args[2];
		long windowSize = Long.parseLong(args[3]);
		
		AppPerfModel model = new AppPerfModel(lqnFile);
		
		model.setupFindBounds(cloudConfigDir, userConfigDir);
		model.printStatisticsAllClouds(model.cplexBuffer);
		
		/* Run algorithm with delay (minimized) focused initial deployment with and without HEM. */
		model.findBounds(true, "hem", windowSize);
//		model.findBounds(false, "nohem", windowSize);
	}
}
