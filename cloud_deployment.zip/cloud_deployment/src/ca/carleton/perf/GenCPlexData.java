package ca.carleton.perf;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class GenCPlexData extends AppPerfModel {
	public GenCPlexData(String lqnFile, String cplexDataFile) throws IOException {
		super(lqnFile);
		onlyGenCPlexData = true;
		cplexBuffer = new BufferedWriter(new FileWriter(new File(cplexDataFile)));
	}
	
	private static void generateCPlexData(String[] args) throws IOException {
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/eclipse_workspace/hasrut/testcases/012.lqn";
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/out_testing/model_5A.lqn";
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/sample_models/model_A30_case2.lqn";
		
//		String lqnFile = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_models/model_A8_case13.lqn";
//		long windowSize = -1;
//		String configDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/final100_configs/model_A8_v3/";
//		Integer hemInput = 1;
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/test_13Jun20/model_A8_case13_v3/";
//		double responseTime = 7500.0;
//		
//		cplexOutputFile = configDir + "/cplex_output.txt";
		
//		if (args.length != 4) {
		if (args.length != 7) {
			throw new IllegalArgumentException("incorrect number of arguments provided.");
		}
		
//		String lqnFile = args[0];
//		String rootDirPrev = args[1];
//		Integer hemInput = Integer.parseInt(args[2]);
//		long windowSize = Long.parseLong(args[3]);
//
//		String rootDir = rootDirPrev + "_ver3/";
//		String userConfigDir = rootDirPrev + "/user_configs";
//		String cloudConfigDir = rootDirPrev + "/cloud_configs";
		
		/* UNCOMMENT to run scripts */
		String lqnFile = args[0];
		String configDir = args[1] + "/";
		Integer hemInput = Integer.parseInt(args[2]);
		long windowSize = Long.parseLong(args[3]);
		String rootDir = args[4] + "/";
		double responseTime = Double.parseDouble(args[5]);
		String cplexDataFile = args[6];
		
		String userConfigDir = configDir + "/user_configs";
		String cloudConfigDir = configDir + "/cloud_configs";
		
		int randomCount = 50;

		boolean hemBool = false;
		String hemSuffix = "_nohem";
		if (hemInput != 0) {
			hemBool = true;
			hemSuffix = "_hem";
		}
		
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/output/model_5A/";
//		String rootDir = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/tuning_data/output/model_A30_case2/vary_window_size_nohem/run6_t0100_wm1_maxm1_h1_v1_n10000/";
		
		/* Delete output directory to avoid stale data. */
		deleteDirectory(rootDir);
		
		/* Create a new output directory. */
		createDirectory(rootDir);
		
		/* Store algorithm's System.out in rootDir/algorithm.out and System.err in rootDir/algorithm.err */
		setOutputStreams(rootDir + "algorithm.out", rootDir + "algorithm.err");
		
		GenCPlexData model = new GenCPlexData(lqnFile, cplexDataFile);
		
//		model.setupDeloymentAlgorithm();
		model.setupFindBounds(cloudConfigDir, userConfigDir);
		model.printStatisticsAllClouds(model.cplexBuffer);
		
		if (responseTime > 0) {
			 /* If response time constraint is provided as a cmdline parameter, override it in the user config. */
			model.users.get(0).setResponseTime(responseTime);
		}
		
		System.out.println("response_time_constraint = " + model.users.get(0).getResponseTime() + ";");
		if (model.cplexBuffer != null) {
			model.cplexBuffer.write("response_time_constraint = " + model.users.get(0).getResponseTime() + ";");
			model.cplexBuffer.newLine(); model.cplexBuffer.newLine();
		}
		
		/* Run algorithm with delay (minimized) focused initial deployment with and without HEM. */
//		model.run(true, Partition.DELAY, rootDir, "delay_hem", windowSize);
		model.run(hemBool, Partition.DELAY, rootDir, "delay" + hemSuffix, windowSize);
		
		/* Run algorithm with power (minimized) focused initial deployment with and without HEM. */
//		model.run(true, Partition.POWER, rootDir, "power_hem", windowSize);
		model.run(hemBool, Partition.POWER, rootDir, "power" + hemSuffix, windowSize);
		
		model.run(hemBool, Partition.HBFMEMDEC, rootDir, "hbfmemdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFMEMINC, rootDir, "hbfmeminc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFPROCDEC, rootDir, "hbfprocdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.HBFPROCINC, rootDir, "hbfprocinc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEMEMDEC, rootDir, "ruaeememdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEMEMINC, rootDir, "ruaeememinc" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEPROCDEC, rootDir, "ruaeeprocdec" + hemSuffix, windowSize);
		model.run(hemBool, Partition.RUAEEPROCINC, rootDir, "ruaeeprocinc" + hemSuffix, windowSize);
		
		model.run(hemBool, Partition.CPLEX, rootDir, "cplex" + hemSuffix, windowSize);
		
		/* Run algorithm randomCount times with random initial deployment with and without HEM. */
		for (int i = 1; i <= randomCount; i++) {
//			model.run(true, Partition.RANDOM, rootDir, "random_" + i + "_hem", windowSize);
			model.run(hemBool, Partition.RANDOM, rootDir, "random_" + i + hemSuffix, windowSize);
		}
		
		/* Copy user configs to output directory. */
//		String userConfigs = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/git/babneet_thesis/cloud_deployment/user_configs";
//		copyFolder(userConfigs, rootDir + "user_configs");
		
		/* Copy cloud configs to output directory */
//		String cloudConfigs = "/media/computer/41ab10b4-327c-48ac-a39a-31dfcc633fbc/misc/git/babneet_thesis/cloud_deployment/cloud_configs";
//		copyFolder(cloudConfigs, rootDir + "cloud_configs");
		
		copyFolder(userConfigDir, rootDir + "user_configs");
		copyFolder(cloudConfigDir, rootDir + "cloud_configs");
		
	}
	
	public static void main(String[] args) throws IOException {
		generateCPlexData(args);
	}
}
