package ca.carleton.cloud;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import ca.carleton.debug.Debug;
import ca.carleton.server.Server;
import ca.carleton.testcases.savi.Node;

public class Cloud implements Serializable {
	private String cloudName;
	
	private CloudSize size;
	
	public List<ServerInventory> inventory;
	
	private HashMap<String, Double> delayMap;
	
	public HashMap<Cloud, Double> delayMapNoString;
	
	public double totalSsjOps;
	
	public double totalCpus;
	
	public double totalCpuDemand;
	
	public double totalRam;
	
	public int totalServers;
	
	/* 1ms CPU demand = 1000 ssj_ops */
	public static double CpuDemandToSsjOpsConversion = 1000.0;
	
	public static final double UtilNorm = 0.8;
	
	public static void setCpuDemandToSsjOpsConversion(double factor) {
		CpuDemandToSsjOpsConversion = factor;
	}
	
	public String getCloudName() {
		return cloudName;
	}

	public void setCloudName(String cloudName) {
		this.cloudName = cloudName;
	}

	public CloudSize getSize() {
		return size;
	}

	public void setSize(CloudSize size) {
		this.size = size;
	}

	public List<ServerInventory> getInventory() {
		return inventory;
	}

	public void setInventory(List<ServerInventory> inventory) {
		this.inventory = inventory;
	}

	public static CloudSize determineSize(String in) {
		CloudSize size = CloudSize.UNKNOWN;
		if (in.equals("EDGE")) {
			size = CloudSize.EDGE;
		} else if (in.equals("SMALL")) {
			size = CloudSize.SMALL;
		} else if (in.equals("MEDIUM")) {
			size = CloudSize.MEDIUM;
		} else if (in.equals("LARGE")) {
			size = CloudSize.LARGE;
		}
		return size;
	}

	public HashMap<String, Double> getDelayMap() {
		return delayMap;
	}

	public void setDelayMap(HashMap<String, Double> delayMap) {
		this.delayMap = delayMap;
	}
	
	public double getDelay(Cloud cloud) {
		return delayMapNoString.get(cloud);
	}
	
	/* Generate a new HashMap without String keys since String comparison is expensive */
	public void generateDelayMapWithoutStringKeys(ArrayList<Cloud> clouds) {
		delayMapNoString = new HashMap<>(); 
		for(String cloudName : delayMap.keySet()) {
			for (Cloud cloud : clouds) {
				if (cloudName.equals(cloud.getCloudName())) {
					this.delayMapNoString.put(cloud, delayMap.get(cloudName));
					break;
				}
			}
		}
	}
	
	public void evaluateCloudStatistics() {
		for (ServerInventory item : inventory) {
			long numAvailable = item.getNumAvailable();
			Server server = item.server;
			
			Debug.log("Server name: " + server.getServerName());

			double serverTotalRam = server.getRam();
			double serverTotalCpus = server.getHardwareThreads();
			long serverTotalSsjOps = server.getTotalSsjOps();
			
			totalServers += numAvailable;
			totalSsjOps += (numAvailable * serverTotalSsjOps);
			totalCpus += (numAvailable * serverTotalCpus);
			totalRam += (numAvailable * serverTotalRam);
		}
		totalCpuDemand = totalSsjOps;
	}
	
	public void printCloudStatistics() {
		Debug.log("   cloud name: " + cloudName +
				//"\n\t ssj ops: " + String.format ("%,.2f", totalSsjOps * Cloud.UtilNorm) +
				"\n\t ssj ops: " + String.format ("%,.2f", totalSsjOps) +
				"\n\t ram: " + totalRam + " GB" +
				"\n\t cpu demand: " + String.format ("%,.2f", totalCpuDemand) + " ms" +
				"\n\t cpus: " + totalCpus);
				
	}
}
