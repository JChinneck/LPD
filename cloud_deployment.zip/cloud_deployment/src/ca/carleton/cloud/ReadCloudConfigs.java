package ca.carleton.cloud;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import ca.carleton.cloud.ServerInventory;
import ca.carleton.debug.Debug;
import ca.carleton.server.Server;

public class ReadCloudConfigs {
	public static String cloud_config_dir = "cloud_configs/";
	
	public static void main(String[] args) {
		readCloudConfigs(null, null);
	}

	
	private static ArrayList<String> getCloudConfigs(String cloudConfigDir) {
		File folder = null;
		if (cloudConfigDir == null) {
			folder = new File(cloud_config_dir);
		} else {
			folder = new File(cloudConfigDir);
		}
		File[] cloud_configs = folder.listFiles();
		ArrayList<String> paths = new ArrayList<>();
		
		for (int i = 0; i < cloud_configs.length; i++) {
			if (cloud_configs[i].isFile()) {
				String path = cloud_configs[i].getPath();
				
				//Debug.log("File " + path);
				
				paths.add(path);
			} 
		}
		
		return paths;
	}
	
	private static Cloud generateCloudInstance(JSONObject jsonObject, ArrayList<Server> serverList) {
		Cloud cloud = new Cloud();
		
		String cloudName = (String)jsonObject.get("cloud_name");
		cloud.setCloudName(cloudName);
		//Debug.log("cloud_name: " + cloudName);
		
		String str = (String)jsonObject.get("cloud_size");
		CloudSize size = Cloud.determineSize(str);
		if (size.equals(CloudSize.UNKNOWN)) {
			throw new IllegalArgumentException("unable to parse cloud_size: " + str);
		}
		cloud.setSize(size);
		//Debug.log("cloud_size: " + size.toString());
		
		List<ServerInventory> servers = new ArrayList<>();
		JSONArray inventory = (JSONArray)jsonObject.get("inventory");
		for (int i = 0; i < inventory.size(); i++) {
			JSONObject server = (JSONObject) inventory.get(i);
			ServerInventory si = new ServerInventory();
			
			String serverName = (String) server.get("server_name");
			si.setServer_name(serverName);
//			Debug.log("server_name: " + serverName);
			
			if (serverList != null) {
				for (Server host : serverList) {
					if (host.getServerName().equals(serverName)) {
						si.setServer(host);
						break;
					}
				}
			}
			
			long totalQuantity = (long) server.get("total_quantity");
			si.setTotalQuanity(totalQuantity);
//			Debug.log("total_quantity: " + totalQuantity);
			
			long numAvailable = (long) server.get("num_available");
			si.setNumAvailable(numAvailable);
//			Debug.log("num_available: " + numAvailable);
			
			servers.add(si);
		}
		cloud.setInventory(servers);
		
		HashMap<String, Double> delayMap = new HashMap<>();
		JSONArray delays = (JSONArray)jsonObject.get("delays");
		for (int i = 0; i < delays.size(); i++) {
			JSONObject delay = (JSONObject) delays.get(i);
			
			String name = (String) delay.get("cloud_name");
			Double delayMs = Double.parseDouble((String) delay.get("delay"));

			//Debug.log("cloudName: " + name + ", delay: " + delayMs);
			
			delayMap.put(name, delayMs);
		}
		cloud.setDelayMap(delayMap);
		
		return cloud;
	}
	
	public static ArrayList<Cloud> readCloudConfigs(ArrayList<Server> serverList, String cloudConfigDir) {
		ArrayList<String> configPaths = getCloudConfigs(cloudConfigDir);
		JSONParser parser = new JSONParser();
		ArrayList<Cloud> cloudList = new ArrayList<>();
		
		try {
			for (String configPath : configPaths) {
				Object obj = parser.parse(new FileReader(configPath));

				JSONObject jsonObject = (JSONObject)obj;
				
				if (jsonObject != null) {
					//Debug.log(jsonObject.toString());
					Cloud cloud = generateCloudInstance(jsonObject, serverList);
					cloudList.add(cloud);
				} else {
					throw new NullPointerException("JSON Object is NULL");
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return cloudList;
	}
}
