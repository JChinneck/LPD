package ca.carleton.cloud;

import java.io.Serializable;

import ca.carleton.server.Server;

public class ServerInventory implements Serializable {
	private String serverName;
	
	/* Reference to server's characteristics */
	public Server server;
	
	private long totalQuantity;
	
	private long numAvailable;

	public String getServerName() {
		return serverName;
	}

	public void setServer_name(String serverName) {
		this.serverName = serverName;
	}

	public long getTotalQuanity() {
		return totalQuantity;
	}

	public void setTotalQuanity(long totalQuanity) {
		this.totalQuantity = totalQuanity;
	}

	public long getNumAvailable() {
		return numAvailable;
	}

	public void setNumAvailable(long numAvailable) {
		this.numAvailable = numAvailable;
	}
	
	public void setServer (Server server) {
		this.server = server;
	}
}
