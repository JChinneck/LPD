package ca.carleton.cloud;

import java.io.Serializable;

/**
 * This enum is used to characterize cloud size. 
 */
public enum CloudSize implements Serializable {
	EDGE,		// Edge Cloud
	SMALL,		// SMALL Cloud
	MEDIUM, 	// Middle Cloud
	LARGE,		// Core Cloud
	UNKNOWN,	// Undefined
}
