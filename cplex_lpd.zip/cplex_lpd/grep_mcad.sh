#!/bin/sh

WORK_DIR=$PWD

operation()
{
#	grep response_time_constraint $WORK_DIR/dat_files/$1.dat
#	grep r_proc $WORK_DIR/dat_files/$1.dat
#	grep num_tasks $WORK_DIR/dat_files/$1.dat

#	echo $1 `grep "wall clock" $WORK_DIR/mcad_output/$1_mcad.log`
#	echo $1 `grep "solution.*with objective" $WORK_DIR/mcad_output/$1_mcad.log`
#	echo $1 `grep "MIQCP objective" $WORK_DIR/mcad_output/$1_mcad.log`

#       echo $1 `grep "wall clock" $WORK_DIR/mcad_rt_output/$1_mcad_rt.log`
#       echo $1 `grep "solution.*with objective" $WORK_DIR/mcad_rt_output/$1_mcad_rt.log`
#	echo $1 `grep "MIQ.*P objective" $WORK_DIR/mcad_rt_output/$1_mcad_rt.log`

#	echo "gtime -v gtimeout 300 ./oplrun -v -profile $WORK_DIR/mcad.mod $WORK_DIR/dat_files/$1.dat |& tee $WORK_DIR/mcad_output/$1_mcad.log"
#	gtime -v gtimeout 300 ./oplrun -v -profile $WORK_DIR/mcad.mod $WORK_DIR/dat_files/$1.dat |& tee $WORK_DIR/mcad_output/$1_mcad.log

#	echo $1 `grep "solution.*with objective" $WORK_DIR/mcad_alpha_wait_output/$1_mcad.log`
	echo $1 `grep "wall clock" $WORK_DIR/mcad_alpha_wait_output/$1_mcad.log`
}

operation model_A12_case01_model_A12_v2_-1
operation model_A12_case02_model_A12_v2_-1
operation model_A12_case03_model_A12_v3_-1
operation model_A12_case04_model_A12_v2_-1
operation model_A12_case05_model_A12_v1_-1
operation model_A12_case06_model_A12_v1_-1
operation model_A12_case07_model_A12_v3_-1
operation model_A12_case08_model_A12_v3_-1
operation model_A12_case09_model_A12_v2_-1
operation model_A12_case10_model_A12_v3_-1
operation model_A12_case11_model_A12_v2_-1
operation model_A12_case12_model_A12_v2_-1
operation model_A12_case13_model_A12_v1_-1
operation model_A12_case14_model_A12_v1_-1
operation model_A12_case15_model_A12_v1_-1
operation model_A18_case01_model_A18_v3_-1
operation model_A18_case02_model_A18_v3_-1
operation model_A18_case03_model_A18_v3_-1
operation model_A18_case05_model_A18_v4_-1
operation model_A18_case07_model_A18_v1_-1
operation model_A18_case08_model_A18_v4_-1
operation model_A18_case09_model_A18_v4_-1
operation model_A18_case10_model_A18_v4_-1
operation model_A18_case11_model_A18_v4_-1
operation model_A18_case12_model_A18_v1_-1
operation model_A18_case13_model_A18_v2_-1
operation model_A18_case14_model_A18_v2_-1
operation model_A18_case15_model_A18_v4_-1
operation model_A18_case16_model_A18_v3_-1
operation model_A18_case17_model_A18_v4_-1
operation model_A18_case18_model_A18_v3_-1
operation model_A18_case19_model_A18_v3_-1
operation model_A18_case21_model_A18_v3_-1
operation model_A24_case01_model_A24_v2_-1
operation model_A24_case02_model_A24_v3_-1
operation model_A24_case03_model_A24_v3_-1
operation model_A24_case05_model_A24_v1_-1
operation model_A24_case06_model_A24_v1_-1
operation model_A24_case07_model_A24_v3_-1
operation model_A24_case08_model_A24_v1_-1
operation model_A24_case09_model_A24_v4_-1
operation model_A24_case12_model_A24_v1_-1
operation model_A24_case13_model_A24_v5_-1
operation model_A24_case14_model_A24_v5_-1
operation model_A24_case15_model_A24_v2_-1
operation model_A24_case17_model_A24_v4_-1
operation model_A24_case18_model_A24_v1_-1
operation model_A24_case19_model_A24_v4_-1
operation model_A24_case20_model_A24_v3_-1
operation model_A24_case21_model_A24_v1_-1
operation model_A30_case01_model_A30_v3_-1
operation model_A30_case03_model_A30_v3_-1
operation model_A30_case04_model_A30_v3_-1
operation model_A30_case05_model_A30_v3_-1
operation model_A30_case06_model_A30_v4_-1
operation model_A30_case08_model_A30_v5_-1
operation model_A30_case09_model_A30_v3_-1
operation model_A30_case10_model_A30_v2_-1
operation model_A30_case11_model_A30_v3_-1
operation model_A30_case13_model_A30_v3_-1
operation model_A30_case15_model_A30_v3_-1
operation model_A30_case16_model_A30_v3_-1
operation model_A30_case18_model_A30_v5_-1
operation model_A30_case20_model_A30_v2_-1
operation model_A4_case01_model_A4_v1_-1
#operation model_A4_case01_model_A4_v1_115000.0
#operation model_A4_case01_model_A4_v1_125000.0
#operation model_A4_case01_model_A4_v1_145000.0
#operation model_A4_case01_model_A4_v1_165000.0
#operation model_A4_case01_model_A4_v1_185000.0
operation model_A4_case02_model_A4_v1_-1
operation model_A4_case04_model_A4_v1_-1
#operation model_A4_case04_model_A4_v1_105000.0
#operation model_A4_case04_model_A4_v1_125000.0
#operation model_A4_case04_model_A4_v1_650000.0
#operation model_A4_case04_model_A4_v1_750000.0
#operation model_A4_case04_model_A4_v1_850000.0
operation model_A4_case05_model_A4_v3_-1
operation model_A4_case06_model_A4_v1_-1
operation model_A4_case07_model_A4_v1_-1
operation model_A4_case08_model_A4_v1_-1
operation model_A4_case09_model_A4_v3_-1
operation model_A4_case10_model_A4_v3_-1
operation model_A4_case11_model_A4_v2_-1
operation model_A4_case12_model_A4_v4_-1
#operation model_A4_case12_model_A4_v4_240000.0
#operation model_A4_case12_model_A4_v4_255000.0
#operation model_A4_case12_model_A4_v4_270000.0
#operation model_A4_case12_model_A4_v4_285000.0
#operation model_A4_case12_model_A4_v4_300000.0
operation model_A4_case13_model_A4_v3_-1
operation model_A4_case14_model_A4_v2_-1
operation model_A4_case15_model_A4_v4_-1
operation model_A4_case16_model_A4_v5_-1
#operation model_A4_case16_model_A4_v5_100000.0
#operation model_A4_case16_model_A4_v5_400000.0
#operation model_A4_case16_model_A4_v5_550000.0
#operation model_A4_case16_model_A4_v5_700000.0
#operation model_A4_case16_model_A4_v5_850000.0
operation model_A4_case17_model_A4_v4_-1
#operation model_A4_case17_model_A4_v4_150000.0
#operation model_A4_case17_model_A4_v4_170000.0
#operation model_A4_case17_model_A4_v4_190000.0
#operation model_A4_case17_model_A4_v4_210000.0
#operation model_A4_case17_model_A4_v4_230000.0
operation model_A4_case18_model_A4_v4_-1
operation model_A4_case19_model_A4_v5_-1
operation model_A4_case20_model_A4_v5_-1
operation model_A4_case21_model_A4_v3_-1
operation model_A8_case02_model_A8_v1_-1
operation model_A8_case03_model_A8_v1_-1
operation model_A8_case04_model_A8_v1_-1
operation model_A8_case05_model_A8_v4_-1
operation model_A8_case06_model_A8_v2_-1
operation model_A8_case07_model_A8_v2_-1
operation model_A8_case08_model_A8_v3_-1
operation model_A8_case09_model_A8_v3_-1
operation model_A8_case10_model_A8_v3_-1
operation model_A8_case11_model_A8_v3_-1
operation model_A8_case12_model_A8_v3_-1
operation model_A8_case13_model_A8_v3_-1
operation model_A8_case14_model_A8_v4_-1
operation model_A8_case15_model_A8_v1_-1
operation model_A8_case16_model_A8_v4_-1
operation model_A8_case17_model_A8_v4_-1
operation model_A8_case18_model_A8_v3_-1
operation model_A8_case19_model_A8_v4_-1
operation model_A8_case20_model_A8_v1_-1
operation model_A8_case21_model_A8_v4_-1

cd $WORK_DIR
